import cs3500.set.model.hw02.SetThreeGameModel;
import cs3500.set.view.SetGameTextView;
import cs3500.set.view.SetGameView;


/**
 * Class for Runner.
 */
public class Runner {

  static SetGameView view;
  static SetThreeGameModel model;

  /**
   * Main method, represents objects and 2D argument for model and view.
   *
   * @param args represents arguments
   */
  public static void main(String[] args) {
    model = new SetThreeGameModel();
    view = new SetGameTextView(model, System.out);
  }
}
