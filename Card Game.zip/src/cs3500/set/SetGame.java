package cs3500.set;

import java.io.InputStreamReader;

import cs3500.set.controller.SetGameController;
import cs3500.set.controller.SetGameControllerImpl;
import cs3500.set.model.hw02.SetGameModel;
import cs3500.set.model.hw02.SetThreeGameModel;
import cs3500.set.model.hw03.GeneralSetGameModel;
import cs3500.set.view.SetGameTextView;


/**
 * Represents class SetGame.
 */
public final class SetGame {


  /**
   * Represents the main methode.
   *
   * @param args the argument for the toString array
   */
  public static void main(String[] args) {
    SetGameController controller;
    SetGameModel model;
    Readable rd = new InputStreamReader(System.in);
    if (args.length > 0) {
      if (args[0].equals("three")) {
        model = new SetThreeGameModel();
        controller = new SetGameControllerImpl(model, new SetGameTextView(model, System.out), rd);
        controller.playGame();
      }
      if (args[0].equals("general")) {
        model = new GeneralSetGameModel();
        controller = new SetGameControllerImpl(model, new SetGameTextView(model, System.out), rd);
        controller.playGame();
      }
    }
  }
}