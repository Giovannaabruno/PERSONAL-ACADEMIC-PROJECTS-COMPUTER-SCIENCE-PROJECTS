package cs3500.set.controller;

import cs3500.set.model.hw02.Card;

/**
 * Interface for SetGameController.
 */
public interface SetGameController {


  /**
   * Represents playGame method.
   *
   * @throws IllegalStateException there is an error in the input or output
   */
  public void playGame() throws IllegalStateException;

  /**
   * Getter method to find the height of the grid.
   *
   * @return height
   */
  public int getHeight();

  /**
   * Getter method to find the width of the grid.
   *
   * @return width
   */
  public int getWidth();

  /**
   * method getCardAtCoord finds the coordinates.
   *
   * @param r row
   * @param c colum
   * @return row and colum
   */
  public Card getCardAtCoord(int r, int c);

  public void setupBoard();
}
