package cs3500.set.controller;

import java.io.IOException;
import java.util.Scanner;

import cs3500.set.model.hw02.Card;
import cs3500.set.model.hw02.Coord;
import cs3500.set.model.hw02.SetGameModel;
import cs3500.set.view.SetGameView;

/**
 * Class for SetGameControllerImpl which implements SetGameController.
 */
public class SetGameControllerImpl implements SetGameController {
  private SetGameModel model;
  private SetGameView view;
  private Scanner scanner;

  /**
   * Constructor for SetGameControllerImp.
   *
   * @param model       model
   * @param setGameView view
   * @param in          input/appendable
   */
  public SetGameControllerImpl(SetGameModel<?> model, SetGameView setGameView, Readable in) {
    if (model == null || setGameView == null || in == null) {
      throw new IllegalArgumentException("one of the fields are null");
    }
    this.model = model;
    this.view = setGameView;
    this.scanner = new Scanner(in);
  }

  /**
   * Getter method to find the height of the grid.
   *
   * @return height
   */
  public int getHeight() {
    return this.model.getHeight();
  }

  /**
   * Getter method to find the width of the grid.
   *
   * @return width
   */
  public int getWidth() {
    return this.model.getWidth();
  }

  /**
   * Getter method for CardAtCoord.
   *
   * @param r row
   * @param c colum
   * @return coord, row and columns to select the card
   */
  public Card getCardAtCoord(int r, int c) {
    return (Card) this.model.getCardAtCoord(r, c);
  }


  /**
   * Getter method for Model.
   *
   * @return model object
   */
  public SetGameModel getModel() {
    return this.model;
  }

  /**
   * Method playGame, represent information for the controller to play the game.
   *
   * @throws IllegalStateException there is an error in the input or output
   */

  public void setupBoard() {
    try {
      this.view.renderMessage("Enter board height");
      String sheight = this.scanner.next();
      if (sheight.equals("Q") || sheight.equals("q")) {
        this.view.renderMessage("Game quit!");
        this.view.renderMessage("State of game when quit:");
        this.view.renderGrid();
        this.view.renderMessage(this.model.isGameOver() + "");
        this.view.renderMessage("Score: " + this.model.getScore());
        System.exit(0);
      }
      int height = Integer.parseInt(sheight);

      this.view.renderMessage("Enter board width");
      String swidth = this.scanner.next();
      if (swidth.equals("Q") || swidth.equals("q")) {
        this.view.renderMessage("Game quit!");
        this.view.renderMessage("State of game when quit:");
        this.view.renderGrid();
        this.view.renderMessage(this.model.isGameOver() + "");
        this.view.renderMessage("Score: " + this.model.getScore());
        System.exit(0);
      }
      int width = Integer.parseInt(swidth);
      this.model.startGameWithDeck(model.getCompleteDeck(), width, height);
    } catch (IOException e) {
      System.err.println("IO exception");

    }
  }
  // set the game bored sized befor playing the game for play game.
  // i can quite the game befor setting up the game board.
  // for the controller anmy posive numer is a input
  //npositve numbers are vailer for the controler.
  ////model says its invads.

  /**
   * play game.
   *
   * @throws IllegalStateException Please enter the row and colum of the third card
   */
  public void playGame() throws IllegalStateException {
    this.setupBoard();
    try {
      while (!this.model.isGameOver()) {
        this.view.renderMessage(this.model.toString());
        //this.view.renderMessage("Score: " + this.model.getScore());
        this.view.renderMessage("Pleas enter the row and colum of the first card");
        int card1row = getNext(scanner.next());
        if (card1row == -2) {
          return;
        }
        int card1colum = getNext(scanner.next());
        if (card1colum == -2) {
          return;
        }
        this.view.renderMessage("Pleas enter the row and colum of the second card");
        int card2row = getNext(scanner.next());
        if (card2row == -2) {
          return;
        }
        int card2colum = getNext(scanner.next());
        if (card2colum == -2) {
          return;
        }
        this.view.renderMessage("Please enter the row and colum of the third card");
        int card3row = getNext(scanner.next());
        if (card3row == -2) {
          return;
        }
        int card3colum = getNext(scanner.next());
        if (card3colum == -2) {
          return;
        }

        if (card1row == -1 || card1colum == -1 || card2row == -1 || card2colum == -1 ||
                card3row == -1 || card3colum == -1 || card1row > this.getHeight()
                || card1colum > this.getWidth()
                || card2row > this.getHeight() || card2colum > this.getWidth()
                || card3row > this.getHeight() || card3colum > this.getWidth()) {
          this.view.renderMessage("Invalid input");
          continue;
        }

        // Indexing starts from 1
        Coord c1 = new Coord(card1row - 1, card1colum - 1);
        Coord c2 = new Coord(card2row - 1, card2colum - 1);
        Coord c3 = new Coord(card3row - 1, card3colum - 1);
        this.model.claimSet(c1, c2, c3);

      }

      // don't expect to run.
      this.view.renderMessage("Game over!");
      this.view.renderMessage("Score: " + this.model.getScore());

    } catch (IOException e) {
      throw new IllegalStateException("IO error");
    }

  }

  private int getNext(String x) {
    try {
      if (x.equals("Q") || x.equals("q")) {
        this.view.renderMessage("Game quit!");
        this.view.renderMessage("State of game when quit:");
        this.view.renderGrid();
        // this.view.renderMessage(this.model.isGameOver() + "");
        this.view.renderMessage("Score: " + this.model.getScore());
        return -2;
      } else {
        Scanner scan = new Scanner(x);
        if (scan.hasNextInt()) {
          int val = scan.nextInt();
          return val;
        } else {
          return -1;
        }
      }


    } catch (IOException e) {
      System.out.println("bad error message");
      return -1;
    }
  }


}
