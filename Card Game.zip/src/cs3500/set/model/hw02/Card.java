package cs3500.set.model.hw02;

// number, a filling, and a shape
//Count has the values one, two, and three
//
//Filling has the values empty, striped, and full
//
//Shape has the values oval, squiggle, and diamond

/**
 * public class that represents the aspects, fields of Cards.
 */
public class Card {
  private String count;
  private String shape;
  private String fill;


  /**
   * Constructor for Cards, creates and represents the different fields and aspects
   * that make up a card.
   *
   * @param count represents the number value of symbolizes on the card
   * @param fill  represents the filling of symbolizes on the card
   * @param shape represents the shape of symbolizes on the card
   */
  public Card(String count, String fill, String shape) {
    if (count == null || (!count.equals("one") && !count.equals("two") && !count.equals("three"))) {
      throw new IllegalArgumentException("Wrong argument");
    } else {
      this.count = count;
    }
    if (fill == null || (!fill.equals("empty") && !fill.equals("striped")
            && !fill.equals("full"))) {
      throw new IllegalArgumentException("Wrong argument");
    } else {
      this.fill = fill;
    }
    if (shape == null || (!shape.equals("oval") && !shape.equals("squiggle") &&
            !shape.equals("diamond"))) {
      throw new IllegalArgumentException("Wrong argument");
    } else {
      this.shape = shape;
    }
  }
  //Counts are represented as 1, 2, or 3

  /**
   * String Method for toString, represents the factors for what count, fill, and shape will
   * represent when for there input and output.
   *
   * @return the structure of the card with cardnum, fillings, shapes
   */
  @Override
  public String toString() {
    int cardnum = 0;
    switch (this.count) {
      case "one":
        cardnum = 1;
        break;
      case "two":
        cardnum = 2;
        break;
      case "three":
        cardnum = 3;
        break;
      default:
        System.out.println("no match");


    }
    // //Shapes are represented as O for oval, Q for squiggle, and D for diamond
    String fillings = "";

    switch (this.fill) {
      case "empty":
        fillings = "E";
        break;
      case "striped":
        fillings = "S";
        break;
      case "full":
        fillings = "F";
        break;
      default:
        System.out.println("no match");

    }
    //Fillings are represented as E for empty, S for striped, and F for full
    String shapes = "";

    switch (this.shape) {
      case "oval":
        shapes = "O";
        break;
      case "squiggle":
        shapes = "Q";
        break;
      case "diamond":
        shapes = "D";
        break;
      default:
        System.out.println("no match");

    }
    return cardnum + fillings + shapes;
  }

  @Override
  public boolean equals(Object other) {
    Card otherCard = (Card) other;
    return this.shape.equals(otherCard.shape) && this.fill.equals(otherCard.fill)
            && this.count.equals(otherCard.count);
  }

  @Override
  public int hashCode() {
    return this.shape.hashCode() + this.fill.hashCode() + this.count.hashCode();
  }


}
