package cs3500.set.model.hw02;


/**
 * Class Set, represent the aspects and fields of Set.
 */
public class Set {
  public Coord one;
  public Coord two;
  public Coord three;

  /**
   * Constructor for Set, represent the three parameters that make up a completed set of cards.
   *
   * @param one   card one
   * @param two   card two
   * @param three card three
   */
  public Set(Coord one, Coord two, Coord three) {
    this.one = one;
    this.two = two;
    this.three = three;
  }

  /**
   * Boolean method for equals, represents the equation to find a completed set.
   *
   * @param o equals set
   * @return a Completed set of 3 cards
   */
  @Override
  public boolean equals(Object o) {
    if (!(o instanceof Set)) {
      return false;
    }
    Set other = (Set) o;
    int same = 0;

    if (one.equals(other.one) || one.equals(other.two) || one.equals(other.three)) {
      same++;
    }
    if (two.equals(other.one) || two.equals(other.two) || two.equals(other.three)) {
      same++;
    }
    if (three.equals(other.one) || three.equals(other.two) || three.equals(other.three)) {
      same++;
    }
    return same == 3;
  }

  /**
   * integer method for HashCode, computes the hash values of given input objects.
   *
   * @return Object
   */
  @Override
  public int hashCode() {
    return one.hashCode() + two.hashCode() + three.hashCode();
  }
}
