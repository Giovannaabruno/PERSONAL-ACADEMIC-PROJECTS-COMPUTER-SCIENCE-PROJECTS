package cs3500.set.model.hw02;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;

/**
 * Public class for SetThreeGameModel which implements array SetGameModel for Card.
 */
public class SetThreeGameModel implements SetGameModel<Card> {
  private final List<Set> foundSets;
  private Card[][] gameBoard;
  private int score;
  private List<Card> deck;
  //implemt get completed deck first before the start.
  private int index;
  private boolean deckEmpty;
  private int width;
  private int height;
  private boolean isRunning;


  /**
   * Constructor for SetThreeGameModel.
   */
  public SetThreeGameModel() {
    this.isRunning = false;
    this.deck = createDeck();
    //deck =   [FILL IN LATER]
    foundSets = new ArrayList<>();
  }

  /**
   * Public static method for array list Card for createDeck.
   *
   * @return aspects for the cards, count, fill, and shape, to make up a deck.
   */
  public static List<Card> createDeck() {

    String[] counts = new String[]{"one", "two", "three"};
    String[] fills = new String[]{"empty", "striped", "full"};
    String[] shapes = new String[]{"oval", "squiggle", "diamond"};
    List<Card> cards = new ArrayList<Card>();
    for (String count : counts) {
      for (String fill : fills) {
        for (String shape : shapes) {
          Card card = new Card(count, fill, shape);
          cards.add(card);
        }
      }
    }

    //Collections.shuffle(cards);
    return cards;
  }

  private static boolean allOnes(Collection<Integer> ls) {
    boolean flag = true;
    for (int k : ls) {
      if (k != 1) {
        flag = false;
        break;
      }
    }
    return flag;
  }

  /**
   * public void methode for claimSet, represents a total cards to claim a set.
   *
   * @param coord1 the coordinates of the first card
   * @param coord2 the coordinates of the second card
   * @param coord3 the coordinates of the third card
   */
  @Override
  public void claimSet(Coord coord1, Coord coord2, Coord coord3) throws IllegalArgumentException {
    if (coord1.row >= 0 && coord1.row < 3 && coord1.col >= 0 && coord1.col < 3
            && coord2.row >= 0 && coord2.row < 3 && coord2.col >= 0 && coord3.col < 3
            && coord3.row >= 0 && coord3.row < 3 && coord3.col >= 0 && coord3.col < 3) {
      if (!isValidSet(coord1, coord2, coord3)) {
        //return;
        throw new IllegalArgumentException(" claiming cards that are not a set");
      }
      if (coord1.equals(coord2) || coord2.equals(coord3) || coord1.equals(coord3)) {
        //return;
        throw new IllegalArgumentException(" claiming cards that are not a set");
      }
      Set s = new Set(coord1, coord2, coord3);
      score++;
      try {
        gameBoard[coord1.row][coord1.col] = deck.get(index);
        index++;
        gameBoard[coord2.row][coord2.col] = deck.get(index);
        index++;
        gameBoard[coord3.row][coord3.col] = deck.get(index);
        index++;
      } catch (IndexOutOfBoundsException e) {
        deckEmpty = true;

      }
    } else {
      throw new IllegalArgumentException("invalid index");
    }
    //if (!foundSets.contains(s)) {
    // foundSets.add(s);


    //  }
    //    } else {
    //      throw new IllegalArgumentException("Incorrect SetClaim");
    //    }
    //
  }

  /**
   * Public void Method startGameWithDeck, represent aspects for the game.
   * Any attempt to create a grid that is not exactly 3 cards high and 3 cards wide.
   * Any attempt to start a game without enough cards to fill the grid.
   * null is given as the value of the deck.
   *
   * @param deck   the list of cards in the order they will be played
   * @param height the height of the board for this game
   * @param width  the width of the board for this game
   * @throws IllegalArgumentException if it finds error in the grid
   */
  @Override
  public void startGameWithDeck(List<Card> deck, int height, int width)
          throws IllegalArgumentException {
    if (deck == null) {
      throw new IllegalArgumentException("Deck is null");
    }
    if (height != 3 || width != 3) {
      throw new IllegalArgumentException("Width and height not equal to 3.");
    }
    this.isRunning = true;
    //    /**
    //    if (!isValidDeck(deck)) {
    //      throw new IllegalArgumentException();
    //    }*/
    this.gameBoard = new Card[height][width];
    boolean hasWon = false;
    this.deck = deck;
    this.width = width;
    this.height = height;
    this.index = 0;
    this.deckEmpty = false;
    for (int r = 0; r < height; r++) {
      for (int c = 0; c < width; c++) {
        try {
          this.gameBoard[r][c] = this.deck.get(index);
          index++;
        } catch (IndexOutOfBoundsException e) {
          throw new IllegalArgumentException("Not enough cards to fill grid.");
        }

      }

    }


  }

  /**
   * method getWidth, represent integer method for getting the width.
   *
   * @return width
   * @throws IllegalStateException incorrect width
   */
  @Override
  public int getWidth() throws IllegalStateException {
    if (!isRunning) {
      throw new IllegalStateException("Game is not running");
    }
    return this.width;
  }

  /**
   * method getHeight, represents integer method for getting the height.
   *
   * @return height
   * @throws IllegalStateException incorrect height
   */
  @Override
  public int getHeight() throws IllegalStateException {
    if (!isRunning) {
      throw new IllegalStateException("Game is not running");
    }
    return this.height;
  }

  /**
   * method for getScore, represents integer method for getting the Score.
   *
   * @return total score
   * @throws IllegalStateException invalid score for game
   */
  @Override
  public int getScore() throws IllegalStateException {
    return score;
  }

  /**
   * Boolean method for anySetsPresent.
   *
   * @return TRUE IF THERE ARE ANY SETS NOT FOUND/CLAIMED BY THE USER
   * @throws IllegalStateException if game is not running correctly
   */
  @Override
  public boolean anySetsPresent() throws IllegalStateException {
    if (!isRunning) {
      throw new IllegalStateException("Game is not running");
    }
    Coord one = new Coord(0, 0);
    Coord two = new Coord(0, 0);
    Coord three = new Coord(0, 0);
    for (int r1 = 0; r1 < height; r1++) { //possible rows of first coord
      for (int c1 = 0; c1 < width; c1++) { //possible cols of first coord
        for (int r2 = 0; r2 < height; r2++) {
          for (int c2 = 0; c2 < width; c2++) {
            for (int r3 = 0; r3 < height; r3++) {
              for (int c3 = 0; c3 < width; c3++) {
                one = new Coord(r1, c1);
                two = new Coord(r2, c2);
                three = new Coord(r3, c3);

                if (!one.equals(two) && !two.equals(three)) {
                  //make sure they're not the same card
                  if (isValidSet(one, two, three)) {
                    Set s = new Set(one, two, three);
                    if (!foundSets.contains(s)) {
                      return true;
                    }
                  }
                }
              }
            }
          }
        }

      }
    }


    return false;
  }

  /**
   * Boolean method for isValidSet, represent the equation to find a valid set of 3 cards.
   *
   * @param coord1 the coordinates of the first card
   * @param coord2 the coordinates of the second card
   * @param coord3 the coordinates of the third card
   * @return a valid set
   * @throws IllegalArgumentException is not running
   */
  @Override
  public boolean isValidSet(Coord coord1, Coord coord2, Coord coord3)
          throws IllegalArgumentException {
    if (!isRunning) {
      throw new IllegalStateException("Game is not running");
    }
    Card c1 = this.gameBoard[coord1.row][coord1.col];
    Card c2 = this.gameBoard[coord2.row][coord2.col];
    Card c3 = this.gameBoard[coord3.row][coord3.col];
    Card[] cards = {c1, c2, c3};
    if (this.getDeck().isEmpty()) {
      isRunning = false;
    }

    //new


    //the first letter of the toString() is the count of each card
    //combine each count into a single String
    String counts = "" + c1.toString().charAt(0) + c2.toString().charAt(0)
            + c3.toString().charAt(0);
    //the second letter of the toString() is the shape of each card
    //combine each shape into a single String
    String shapes = "" + c1.toString().charAt(1) + c2.toString().charAt(1)
            + c3.toString().charAt(1);
    //the third letter of the toString() is the fill of each card
    //combine each fill into a single String
    String fills = "" + c1.toString().charAt(2) + c2.toString().charAt(2)
            + c3.toString().charAt(2);

    boolean isValidCounts = true;
    // 3SL  3SE  3SF
    //333   SSS  LEF

    HashMap<Character, Integer> countMap = new HashMap<>();
    for (int i = 0; i < counts.length(); i++) {
      char c = counts.charAt(i);
      if (!countMap.containsKey(c)) {
        countMap.put(c, 1);
      } else {
        countMap.put(c, countMap.get(c) + 1);
      }
    }


    HashMap<Character, Integer> shapeMap = new HashMap<>();
    for (int i = 0; i < shapes.length(); i++) {
      char c = shapes.charAt(i);
      if (!shapeMap.containsKey(c)) {
        shapeMap.put(c, 1);
      } else {
        shapeMap.put(c, shapeMap.get(c) + 1);
      }
    }


    HashMap<Character, Integer> fillMap = new HashMap<>();
    for (int i = 0; i < fills.length(); i++) {
      char c = fills.charAt(i);
      if (!fillMap.containsKey(c)) {
        fillMap.put(c, 1);
      } else {
        fillMap.put(c, fillMap.get(c) + 1);
      }
    }

    if (!(fillMap.containsValue(3) || allOnes(fillMap.values()))) {
      return false;
    }
    if (!(shapeMap.containsValue(3) || allOnes(shapeMap.values()))) {
      return false;
    }
    return countMap.containsValue(3) || allOnes(countMap.values());
    //    /**
    //     //if the count of every card is not the same, we must check that they are all different
    //     if (counts.charAt(0) != counts.charAt(1) || counts.charAt(1) != counts.charAt(2)) {
    //     for (int c = 0; c < counts.length(); c++) { //go through every count
    //     int matches = 0;
    //     for (int d = 0; d < counts.length(); d++) {
    //     //count the number of times the count appears
    //     if (counts.charAt(c) == counts.charAt(d)) {
    //     matches++;
    //     }
    //     }
    //     if (matches == 2) { //if only 2 elements share this count, it's invalid
    //     return false;
    //     }
    //     //if three shared the count, this if statement wouldn't have run
    //     //if one shared the count (aka it was unique), then it's valid
    //     }
    //     }
    //     //if this if statement is false, it means every count is the same, which is fine
    //
    //     //221
    //     //121
    //     //122
    //
    //     //if the shape of every card is not the same, we must check that they are all different
    //     if (shapes.charAt(0) != shapes.charAt(1) || shapes.charAt(1) != shapes.charAt(2)) {
    //     for (int c = 0; c < shapes.length(); c++) { //go through every shape
    //     int matches = 0;
    //
    //     for (int d = 0; d < shapes.length(); d++) {
    //     //count the number of times the shape appears
    //     if (shapes.charAt(c) == shapes.charAt(d)) {
    //     matches++;
    //     }
    //     }
    //     if (matches == 2) { //if only 2 elements share this shape, it's invalid
    //     return false;
    //     }
    //     //if three shared the shape, this if statement wouldn't have run
    //     //if one shared the shape (aka it was unique), then it's valid
    //     }
    //     }
    //     //if this if statement is false, it means every shape is the same, which is fine
    //
    //     //if the fill of every card is not the same, we must check that they are all different
    //     if (fills.charAt(0) != fills.charAt(1) || fills.charAt(1) != fills.charAt(2)) {
    //     for (int c = 0; c < fills.length(); c++) { //go through every fill
    //     int matches = 0;
    //     for (int d = 0; d < fills.length(); d++) {
    //     //count the number of times the fill appears
    //     if (fills.charAt(c) == fills.charAt(d)) {
    //     matches++;
    //     }
    //     }
    //     if (matches == 2) { //if only 2 elements share this fill, it's invalid
    //     return false;
    //     }
    //     //if three shared the fill, this if statement wouldn't have run
    //     //if one shared the fill (aka it was unique), then it's valid
    //     }
    //     }
    //     //if this if statement is false, it means every fill is the same, which is same
    //
    //     //if nothign returns false, it means every element (count, shape, fill)
    //     //are all either unique or all the same
    //     return true;*/
  }
  //  /**
  //   * Helper for isValid Deck.
  //   *
  //   * @param deck completed cards
  //   * @return valid deck
  //   * @throws IllegalStateException if it's a invalid deck
  //   */
  //  public boolean isValidDeck(List<Card> deck) throws IllegalArgumentException {
  //    if (!isRunning) {
  //      throw new IllegalStateException("Game is not running");
  //    }
  //    if (deck == null) {
  //      return false;
  //    }
  //    for (int i = 0; i < deck.size(); i++) {
  //      for (int j = i + 1; j < deck.size(); j++) {
  //        if (deck.get(i).equals(deck.get(j))) {
  //          return false;
  //        }
  //      }
  //    }
  //    return true;
  //
  //  }

  /**
   * Method for getting the CardAtCoord, for row and column.
   *
   * @param row the row of the desired card
   * @param col the column of the desired card
   * @return 2D array for row and col
   */
  @Override
  public Card getCardAtCoord(int row, int col) {
    return gameBoard[row][col];
  }

  /**
   * Method for getting the CardAtCoord, for coordinate.
   *
   * @param coord the coordinates of the desired card
   * @return 2D array for coordinate with objects row and col
   */
  @Override
  public Card getCardAtCoord(Coord coord) {
    return gameBoard[coord.row][coord.col];
  }

  /**
   * Boolean method for finding if game is over.
   *
   * @return game is over.
   */
  @Override
  public boolean isGameOver() {
    return deckEmpty || !anySetsPresent();
  }

  /**
   * Method for getting the CompleteDeck.
   *
   * @return deck
   */
  @Override
  public List getCompleteDeck() {
    List<Card> deck = createDeck();
    return deck;
  }

  /**
   * Method for getting the getDeck.
   *
   * @return object deck
   */
  public List<Card> getDeck() {
    return this.deck;
  }

  @Override
  public String toString() {

    String result = "";
    for (int r = 0; r < this.getHeight(); r++) {
      for (int c = 0; c < this.getWidth(); c++) {
        result += this.getCardAtCoord(r, c).toString() + " ";
      }
      result = result.substring(0, result.length() - 1);
      result += "\n";
    }
    return result.substring(0, result.length() - 1);
  }
}
