package cs3500.set.model.hw03;


import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;

import cs3500.set.model.hw02.Card;
import cs3500.set.model.hw02.Coord;
import cs3500.set.model.hw02.Set;
import cs3500.set.model.hw02.SetGameModel;

/**
 * Represents the GeneralSetGameModel which implements SetGameModel.
 */
public class GeneralSetGameModel implements SetGameModel {
  private final List<Set> foundSets;
  private Card[][] gameBoard;
  private int score;
  private List<Card> deck;
  //implemt get completed deck first before the start.
  private int index;
  private int width;
  private int height;
  private boolean isRunning;

  /**
   * Constructor for GeneralSetGameModel.
   */
  public GeneralSetGameModel() {
    this.isRunning = false;
    this.deck = createDeck();
    //deck =   [FILL IN LATER]
    foundSets = new ArrayList<>();
  }

  /**
   * Represents static method createDeck,creates deck of random cards.
   *
   * @return Random and different factor that goes into a cards creating a deck
   */
  public static List<Card> createDeck() {

    String[] counts = new String[]{"one", "two", "three"};
    String[] fills = new String[]{"empty", "striped", "full"};
    String[] shapes = new String[]{"oval", "squiggle", "diamond"};
    List<Card> cards = new ArrayList<Card>();
    for (String count : counts) {
      for (String fill : fills) {
        for (String shape : shapes) {
          Card card = new Card(count, fill, shape);
          cards.add(card);
        }
      }
    }

    //Collections.shuffle(cards);
    return cards;
  }

  /**
   * Boolean method allOnes, checks if list contains all ones.
   *
   * @param ls List to check
   * @return whether it contains all ones
   */
  private static boolean allOnes(Collection<Integer> ls) {
    for (int k : ls) {
      if (k != 1) {
        return false;
      }
    }
    return true;
  }


  /**
   * Methode addRowIfNoSets,adds new row if no sets present.
   */
  private boolean addRowIfNoSets() {
    while (deck.size() >= getWidth() && !anySetsPresent()) {
      // adding new row if no sets present
      Card[][] newGameBoard = new Card[getHeight() + 1][getWidth()];
      for (int i = 0; i < getHeight(); i++) {
        newGameBoard[i] = gameBoard[i].clone();
      }
      Card[] newRow = new Card[getWidth()];
      for (int j = 0; j < getWidth(); j++) {
        newRow[j] = deck.remove(0);
      }
      newGameBoard[getHeight()] = newRow;
      this.height++;
    }
    return anySetsPresent();
  }

  /**
   * Methode claimSet, As long as there are enough cards in the deck to add a row and
   * there is no set present on the grid, the method should add an extra row to the
   * grid. We add a row by using cards from the top of the deck and placing them left to
   * right on the new row. For instance, if we are playing on a 5 row by 4 column grid,
   * the new row would need 5 cards. If we run out of cards in the process, the game ends.
   *
   * @param coord1 the coordinates of the first card
   * @param coord2 the coordinates of the second card
   * @param coord3 the coordinates of the third card
   */
  @Override
  public void claimSet(Coord coord1, Coord coord2, Coord coord3) {
    if (coord1.row >= 0 && coord1.row < this.getHeight() && coord1.col >= 0 && coord1.col
            < this.getWidth()
            && coord2.row >= 0 && coord2.row < this.getHeight() && coord2.col >= 0 && coord3.col
            < this.getWidth()
            && coord3.row >= 0 && coord3.row < this.getHeight() && coord3.col >= 0 && coord3.col
            < this.getWidth()) {
      if (!isValidSet(coord1, coord2, coord3)) {
        //return;
        throw new IllegalArgumentException(" claiming cards that are not a set");
      }
      if (coord1.equals(coord2) || coord2.equals(coord3) || coord1.equals(coord3)) {
        //return;
        throw new IllegalArgumentException(" claiming cards that are not a set");
      }
      Set s = new Set(coord1, coord2, coord3);
      score++;
      try {
        if (deck.size() >= 3) {
          //System.out.println("Inside replacing cards");
          gameBoard[coord1.row][coord1.col] = deck.remove(0);
          index++;
          gameBoard[coord2.row][coord2.col] = deck.remove(0);
          index++;
          gameBoard[coord3.row][coord3.col] = deck.remove(0);
          index++;
          // checks if we add a new row
          if (!addRowIfNoSets()) {
            System.out.println("out of cards");
          }
        }

      } catch (IndexOutOfBoundsException e) {
        System.out.print("out of cards");

      }
    } else {
      throw new IllegalArgumentException("invalid index");
    }
  }


  /**
   * Method for startGameWithDeck, represent aspects for the game.
   * Any attempt to create a starting grid for the game bored that can add in new row.
   * Any attempt to start a game without enough cards to fill the grid.
   * null is given as the value of the deck.
   *
   * @param deck the list of cards in the order they will be played
   * @param m    the width of the game board
   * @param n    the height of the game board
   * @throws IllegalArgumentException there are not enough cards to fill grid
   */
  @Override
  public void startGameWithDeck(List deck, int m, int n) throws IllegalArgumentException {
    if (deck == null) {
      throw new IllegalArgumentException("Deck is null");
    }
    if (m < 0 || n < 0) {
      throw new IllegalArgumentException("Width or height not positive.");
    }
    // check dimensions
    if (m * n < 3) {
      throw new IllegalArgumentException("Width and height too small, must have area " +
              "greater than 3");
    }
    if (deck.size() < m * n ) {
      throw new IllegalArgumentException("deck does not have enough cards for the game");
    }
    this.isRunning = true;
    //    /**
    //    if (!isValidDeck(deck)) {
    //      throw new IllegalArgumentException();
    //    }*/
    this.gameBoard = new Card[n][m];
    boolean hasWon = false;
    this.deck = deck;
    this.width = m;
    this.height = n;
    this.index = 0;
    for (int r = 0; r < n; r++) {
      for (int c = 0; c < m; c++) {
        try {
          this.gameBoard[r][c] = this.deck.remove(0);
          index++;
        } catch (IndexOutOfBoundsException e) {
          throw new IllegalArgumentException("Not enough cards to fill grid.");
        }
      }
    }
    addRowIfNoSets();
  }


  /**
   * Method getWidth, represents the width of the grid.
   *
   * @return the width of the grid
   * @throws IllegalStateException Game is not running
   */
  @Override
  public int getWidth() throws IllegalStateException {
    if (!isRunning) {
      throw new IllegalStateException("Game is not running");
    }
    return this.width;
  }

  /**
   * Method getHeight, represents the height of the grid.
   *
   * @return the height of the grid
   * @throws IllegalStateException Game is not running
   */
  @Override
  public int getHeight() throws IllegalStateException {
    if (!isRunning) {
      throw new IllegalStateException("Game is not running");
    }
    return this.height;
  }


  /**
   * Method getScore, represents the width of the score.
   *
   * @return score for game.
   * @throws IllegalStateException if score is not running correctly.
   */
  @Override
  public int getScore() throws IllegalStateException {
    return score;
  }

  /**
   * Boolean method anySetsPresent, represents the calculations to find if and vaild sets are found
   * along with the invalid set.
   *
   * @return TRUE IF THERE ARE ANY SETS NOT FOUND/CLAIMED BY THE USER
   */
  @Override
  public boolean anySetsPresent() {
    if (!isRunning) {
      throw new IllegalStateException("Game is not running");
    }
    Coord one = new Coord(0, 0);
    Coord two = new Coord(0, 0);
    Coord three = new Coord(0, 0);
    for (int r1 = 0; r1 < height; r1++) { //possible rows of first coord
      for (int c1 = 0; c1 < width; c1++) { //possible cols of first coord
        for (int r2 = 0; r2 < height; r2++) {
          for (int c2 = 0; c2 < width; c2++) {
            for (int r3 = 0; r3 < height; r3++) {
              for (int c3 = 0; c3 < width; c3++) {
                one = new Coord(r1, c1);
                two = new Coord(r2, c2);
                three = new Coord(r3, c3);

                if (!one.equals(two) && !two.equals(three)) {
                  //make sure they're not the same card
                  if (isValidSet(one, two, three)) {
                    Set s = new Set(one, two, three);
                    if (!foundSets.contains(s)) {
                      return true;
                    }
                  }
                }
              }
            }
          }
        }

      }
    }
    return false;
  }

  /**
   * Boolean method for isValidSet, represent the equation to find a valid set of 3 cards.
   *
   * @param coord1 the coordinates of the first card
   * @param coord2 the coordinates of the second card
   * @param coord3 the coordinates of the third card
   * @return a valid set
   * @throws IllegalArgumentException is not running correctlyy
   */
  @Override
  public boolean isValidSet(Coord coord1, Coord coord2, Coord coord3)
          throws IllegalArgumentException {
    if (!isRunning) {
      throw new IllegalStateException("Game is not running");
    }
    Card c1 = this.gameBoard[coord1.row][coord1.col];
    Card c2 = this.gameBoard[coord2.row][coord2.col];
    Card c3 = this.gameBoard[coord3.row][coord3.col];
    Card[] cards = {c1, c2, c3};
    if (this.getDeck().isEmpty()) {
      //System.out.println("out of cards");
      //isRunning = false;
    }

    //new


    //the first letter of the toString() is the count of each card
    //combine each count into a single String
    String counts = "" + c1.toString().charAt(0) + c2.toString().charAt(0)
            + c3.toString().charAt(0);
    //the second letter of the toString() is the shape of each card
    //combine each shape into a single String
    String shapes = "" + c1.toString().charAt(1) + c2.toString().charAt(1)
            + c3.toString().charAt(1);
    //the third letter of the toString() is the fill of each card
    //combine each fill into a single String
    String fills = "" + c1.toString().charAt(2) + c2.toString().charAt(2)
            + c3.toString().charAt(2);

    boolean isValidCounts = true;
    // 3SL  3SE  3SF
    //333   SSS  LEF

    HashMap<Character, Integer> countMap = new HashMap<>();
    for (int i = 0; i < counts.length(); i++) {
      char c = counts.charAt(i);
      if (!countMap.containsKey(c)) {
        countMap.put(c, 1);
      } else {
        countMap.put(c, countMap.get(c) + 1);
      }
    }


    HashMap<Character, Integer> shapeMap = new HashMap<>();
    for (int i = 0; i < shapes.length(); i++) {
      char c = shapes.charAt(i);
      if (!shapeMap.containsKey(c)) {
        shapeMap.put(c, 1);
      } else {
        shapeMap.put(c, shapeMap.get(c) + 1);
      }
    }


    HashMap<Character, Integer> fillMap = new HashMap<>();
    for (int i = 0; i < fills.length(); i++) {
      char c = fills.charAt(i);
      if (!fillMap.containsKey(c)) {
        fillMap.put(c, 1);
      } else {
        fillMap.put(c, fillMap.get(c) + 1);
      }
    }
    //can you claim more than 3 cards for row
    // got to fix later.

    System.out.print(this.getCardAtCoord(coord1) + " ");
    System.out.print(this.getCardAtCoord(coord2) + " ");
    System.out.print(this.getCardAtCoord(coord3));

    System.out.println("fillMap " + fillMap);
    System.out.println("shapeMap " + shapeMap);
    System.out.println("countMap " + countMap);

    if (!(fillMap.containsValue(3) || allOnes(fillMap.values()))) {
      return false;
    }
    if (!(shapeMap.containsValue(3) || allOnes(shapeMap.values()))) {
      return false;
    }
    return countMap.containsValue(3) || allOnes(countMap.values());

  }

  /**
   * Method getCardAtCoord, represents finding the correct coordinates
   * for row and colum to find the card.
   *
   * @param row the row of the desired card
   * @param col the column of the desired card
   * @return row and columns coordinates, 2D array for row and col
   */
  @Override
  public Card getCardAtCoord(int row, int col) {
    return gameBoard[row][col];
  }

  /**
   * Method for getting the CardAtCoord, for coordinate.
   *
   * @param coord the coordinates of the desired card
   * @return 2D array for coordinate with objects row and col
   */
  @Override
  public Object getCardAtCoord(Coord coord) {
    return gameBoard[coord.row][coord.col];
  }
  // consider  change the first statement to be less than elements we need.
  //for a row.

  /**
   * Boolean method isGameOver, represents the finding of if game is over.
   * @return boolean, is game is over
   */
  @Override
  public boolean isGameOver() {
    return (deck.size() < 3 && !anySetsPresent()) || deck.size() < getWidth();
  }

  /**
   * Method for getting the CompleteDeck, represents a completed deck for, the GeneralSetGameModel.
   *
   * @return a completed deck
   */
  @Override
  public List getCompleteDeck() {
    return GeneralSetGameModel.createDeck();
  }

  /**
   * Method for getting the getDeck.
   *
   * @return object deck
   */
  public List<Card> getDeck() {
    return this.deck;
  }

  /**
   * Method for toString, represents the setup of the grid.
   *
   * @return the setup of the grid
   */
  @Override
  public String toString() {

    String result = "";
    for (int r = 0; r < this.getHeight(); r++) {
      for (int c = 0; c < this.getWidth(); c++) {
        result += this.getCardAtCoord(r, c).toString() + " ";
      }
      result = result.substring(0, result.length() - 1);
      result += "\n";
    }
    return result.substring(0, result.length() - 1);
  }

}
