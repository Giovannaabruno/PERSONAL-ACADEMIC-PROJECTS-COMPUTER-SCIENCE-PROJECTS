package cs3500.set.view;

import java.io.IOException;

import cs3500.set.controller.SetGameController;
import cs3500.set.model.hw02.SetGameModelState;

/**
 * Public class for SetGameTextView which implements SetGameView.
 */
public class SetGameTextView implements SetGameView {
  private SetGameController controller;
  private Appendable out;

  private SetGameModelState state;


  /**
   * Constructor for SetGameTextView.
   *
   * @param controller controller
   * @param out        output
   */
  public SetGameTextView(SetGameController controller, Appendable out) {
    if (controller == null || out == null) {
      throw new IllegalArgumentException("controller or the appendable is null");
    }
    this.controller = controller;
    this.out = out;
  }

  /**
   * Constructor for SetGameTextView, takes in fields controller and output.
   *
   * @param controller represents the format model for the game.
   */
  public SetGameTextView(SetGameController controller) {
    this.controller = controller;
    this.out = System.out;
  }

  /**
   * Constructor for SetGameTextView, takes in feilds state and output.
   *
   * @param state state of game
   * @param out   output
   */
  public SetGameTextView(SetGameModelState state, Appendable out) {
    if (state == null || out == null) {
      throw new IllegalArgumentException("controller or the appendable is null");
    }
    this.state = state;
    this.out = out;
  }

  /**
   * Constructor SetGameTextView, takes in feilds state and output.
   *
   * @param state state of game
   */
  public SetGameTextView(SetGameModelState state) {
    if (state == null) {
      throw new IllegalArgumentException("controller or the appendable is null");
    }
    this.state = state;
    this.out = System.out;

  }


  /**
   * String method for toString, for row and colum.
   *
   * @return model for get card at the cornet on the game bored
   */
  public String toString() {
    if (state != null) {
      String result = "";
      for (int r = 0; r < this.state.getHeight(); r++) {
        for (int c = 0; c < this.state.getWidth(); c++) {
          result += this.state.getCardAtCoord(r, c).toString() + " ";
          //result = result.strip();
        }
        result = result.substring(0, result.length() - 1);
        result += "\n";
      }
      return result.substring(0, result.length() - 1);
    } else if (controller != null) {
      String result = " ";
      for (int r = 0; r < this.controller.getHeight(); r++) {
        for (int c = 0; c < this.controller.getWidth(); c++) {
          result += this.controller.getCardAtCoord(r, c).toString() + " ";
          //result = result.strip();
        }
        result = result.substring(0, result.length() - 1);
        result += "\n";
      }
      return result.substring(0, result.length() - 1);
    } else {
      return "error";
    }
  }
  //new

  /**
   * Method renderGrid,this method takes no arguments. It transmits the state of the
   * game to a specified destination (dependent on the implementation of
   * this interface).
   *
   * @throws IOException error in renderGrid
   */
  @Override
  public void renderGrid() throws IOException {
    this.out.append(this.toString() + "\n");
  }

  /**
   * Method renderMessage, this method can be used to show an
   * arbitrary message, allowing this view to show messages determined
   * by whoever uses it.
   *
   * @param message the message to be printed
   * @throws IOException error in renderMessage
   */
  @Override
  public void renderMessage(String message) throws IOException {
    this.out.append(message + "\n");
  }
}
