import java.io.InputStreamReader;

import cs3500.set.controller.SetGameControllerImpl;
import cs3500.set.model.hw02.SetGameModel;
import cs3500.set.model.hw02.SetThreeGameModel;
import cs3500.set.view.SetGameTextView;

/**
 * Do not modify this file. This file should compile correctly with your code.
 */
public class Hw03TypeChecks {
  /**
   * Runs the program, but this method should NEVER be run.
   * It does nothing of import.
   *
   * @param args The command line arguments
   */
  public static void main(String[] args) {
    Readable rd = new InputStreamReader(System.in);
    Appendable out = System.out;

    helper(new SetThreeGameModel(), rd, out);
  }

  /**
   * Helper Method for Hw03TypeChecks.
   *
   * @param model model
   * @param in    input
   * @param out   output
   */
  private static void helper(SetGameModel<?> model, Readable in, Appendable out) {
    SetGameControllerImpl controller = new SetGameControllerImpl(model, new
            SetGameTextView(model, out), in);
    controller.playGame();
  }
}
