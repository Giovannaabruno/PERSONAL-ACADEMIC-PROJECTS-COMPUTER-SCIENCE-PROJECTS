package cs3500.set.controller;


import org.junit.Before;
import org.junit.Test;

import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import cs3500.set.model.hw02.Card;
import cs3500.set.model.hw02.SetThreeGameModel;
import cs3500.set.view.SetGameTextView;


import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertThrows;

/**
 * Tester for SetGameControllerImpl.
 */
public class SetGameControllerImplTest {
  SetGameControllerImpl controller;
  Card firstCard;
  Card twoCard;
  Card threeCard;
  StringBuilder sb;
  SetGameTextView view;
  SetThreeGameModel model;
  Readable vr;

  /**
   * Setup for SetGameControllerImpl.
   */
  @Before
  public void setUp() {
    sb = new StringBuilder();
    model = new SetThreeGameModel();
    view = new SetGameTextView(model, sb);
    vr = new InputStreamReader(System.in);
    controller = new SetGameControllerImpl(model, view, vr);
    List<Card> deck = SetThreeGameModel.createDeck();
    firstCard = deck.get(0);
    twoCard = deck.get(1);
    threeCard = deck.get(2);
    controller.setupBoard();
  }
  // 3x3

  /**
   * Tester for GetHeight, test the correct and incorrect heights for the game.
   */
  @Test
  public void testGetHeight() {
    assertEquals(controller.getHeight(), 3);
    assertNotEquals(controller.getHeight(), 1);
    assertNotEquals(controller.getHeight(), 5);
    assertNotEquals(controller.getHeight(), -1);
    assertNotEquals(controller.getHeight(), 0);
  }

  /**
   * Tester for GetWidth, test the correct and incorrect width for the game.
   */
  @Test
  public void testGetWidth() {
    assertEquals(controller.getWidth(), 3);
    assertNotEquals(controller.getWidth(), 1);
    assertNotEquals(controller.getWidth(), 5);
    assertNotEquals(controller.getWidth(), -1);
    assertNotEquals(controller.getWidth(), 0);
  }

  /**
   * Tester for GetCardAtCoord, test the correct and incorrect coordinates for the game.
   */
  @Test
  public void testGetCardAtCoord() {
    assertEquals(firstCard, controller.getCardAtCoord(0, 0));
    assertEquals(twoCard, controller.getCardAtCoord(0, 1));
    assertEquals(threeCard, controller.getCardAtCoord(0, 2));
    assertNotEquals(firstCard, controller.getCardAtCoord(1, 0));
    assertNotEquals(firstCard, controller.getCardAtCoord(2, 0));
  }
  // fix controler
  // should the view contain the contoler bcause it causes the controller to become null.
  // should the controlor or the view become first when lounding the game for game play.
  //SHOULD MAKE A DEFAULT.

  /**
   * Tester for PlayGame, play game.
   *
   * @throws IOException error found from input or output
   */
  @Test
  public void testPlayGame() throws IOException {
    sb = new StringBuilder();
    model = new SetThreeGameModel();
    controller = new SetGameControllerImpl(model, view, vr);
    view = new SetGameTextView(controller, sb);
    Readable vr = new InputStreamReader(System.in);

    controller.setupBoard();

    List<Card> deck = new ArrayList<>();

    deck.add(new Card("one", "full", "diamond"));
    deck.add(new Card("two", "full", "oval"));
    deck.add(new Card("three", "full", "squiggle"));
    //comb 2
    deck.add(new Card("three", "striped", "squiggle"));
    deck.add(new Card("two", "empty", "squiggle"));
    deck.add(new Card("one", "full", "squiggle"));
    //comb3
    deck.add(new Card("three", "full", "oval"));
    deck.add(new Card("two", "full", "oval"));
    deck.add(new Card("one", "full", "oval"));

    model.startGameWithDeck(deck, 3, 3);
    view.renderGrid();
    String grid = "1FD 2FO 3FQ\n" +
            "3SQ 2EQ 1FQ\n" +
            "3FO 2FO 1FO";
    assertEquals(view.toString(), grid);
  }

  @Test
  public void testControllerConstructorNull() {
    // test view is null
    assertThrows(IllegalArgumentException.class, () -> {
      SetGameControllerImpl controller = new SetGameControllerImpl(model, null, vr);
    });

    // test readable is null
    assertThrows(IllegalArgumentException.class, () -> {
      SetThreeGameModel model = new SetThreeGameModel();
      SetGameTextView view = new SetGameTextView(model, System.out);
      SetGameControllerImpl controller = new SetGameControllerImpl(model, view, null);
    });

  }
}