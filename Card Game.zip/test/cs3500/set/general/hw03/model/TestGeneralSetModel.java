package cs3500.set.general.hw03.model;


import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import cs3500.set.model.hw02.Card;
import cs3500.set.model.hw02.Coord;
import cs3500.set.model.hw02.SetThreeGameModel;
import cs3500.set.model.hw03.GeneralSetGameModel;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertTrue;

/**
 * Tester for class GeneralSetModel.
 */
public class TestGeneralSetModel {

  GeneralSetGameModel m = new GeneralSetGameModel();


  /**
   * SetUp represents for SetThreeGameModel, a 3X3 grid.
   */
  @Before
  public void testSetUp() {
    List<Card> deck = new ArrayList<>();
    deck.add(new Card("one", "full", "diamond"));
    deck.add(new Card("two", "full", "oval"));
    deck.add(new Card("three", "full", "squiggle"));
    deck.add(new Card("one", "striped", "oval"));
    deck.add(new Card("three", "striped", "squiggle"));

    //comb 2
    deck.add(new Card("three", "striped", "squiggle"));
    deck.add(new Card("two", "empty", "squiggle"));
    deck.add(new Card("one", "full", "squiggle"));
    deck.add(new Card("one", "full", "oval"));
    deck.add(new Card("two", "empty", "diamond"));

    //comb3
    deck.add(new Card("three", "full", "oval"));
    deck.add(new Card("two", "full", "oval"));
    deck.add(new Card("one", "full", "oval"));
    deck.add(new Card("one", "full", "diamond"));
    deck.add(new Card("two", "empty", "oval"));

    // fourth row
    deck.add(new Card("three", "full", "oval"));
    deck.add(new Card("two", "full", "oval"));
    deck.add(new Card("one", "full", "oval"));
    deck.add(new Card("two", "full", "oval"));
    deck.add(new Card("one", "striped", "squiggle"));

    m.startGameWithDeck(deck, 4, 5);

  }

  /**
   * Tester for claimSet, a claim a correct completed set.
   */
  @Test
  public void claimSet() {
    List<Card> deck = new ArrayList<Card>();
    deck.add(new Card("one", "full", "diamond")); //0,0
    deck.add(new Card("two", "full", "oval")); //0,1
    deck.add(new Card("three", "full", "squiggle"));//0,2
    deck.add(new Card("one", "striped", "oval"));//0,3

    //comb 2
    deck.add(new Card("three", "striped", "squiggle"));//1,0
    deck.add(new Card("two", "empty", "squiggle"));//1,1
    deck.add(new Card("one", "full", "squiggle")); //1,2
    deck.add(new Card("one", "full", "oval"));//1,3

    //comb3
    deck.add(new Card("three", "full", "oval"));//2,0
    deck.add(new Card("two", "full", "oval"));//2,1
    deck.add(new Card("one", "full", "oval"));//2,2
    deck.add(new Card("one", "full", "diamond"));//2,3

    // fourth row
    deck.add(new Card("three", "empty", "oval"));//3,0
    deck.add(new Card("two", "full", "oval"));//3,1
    deck.add(new Card("one", "full", "oval"));//3,2
    deck.add(new Card("two", "full", "oval"));//3,3

    // fifth row
    deck.add(new Card("three", "full", "oval"));//3,0
    deck.add(new Card("two", "full", "oval"));//3,1
    deck.add(new Card("one", "full", "oval"));//3,2
    deck.add(new Card("two", "full", "oval"));//3,3

    // sixth row
    deck.add(new Card("three", "full", "oval"));//3,0
    deck.add(new Card("one", "full", "squiggle"));//3,1
    deck.add(new Card("one", "full", "oval"));//3,2
    deck.add(new Card("two", "full", "oval"));//3,3

    m.startGameWithDeck(deck, 4, 5);
    assertTrue(m.anySetsPresent());
    Card c1 = m.getCardAtCoord(0, 0);
    Card c2 = m.getCardAtCoord(0, 1);
    Card c3 = m.getCardAtCoord(0, 2);
    m.claimSet(new Coord(0, 0), new Coord(0, 1), new Coord(0, 2));
    assertNotEquals(c1, m.getCardAtCoord(0, 0));
    assertNotEquals(c2, m.getCardAtCoord(0, 1));
    assertNotEquals(c3, m.getCardAtCoord(0, 2));


    Assert.assertThrows(IllegalArgumentException.class, () -> {
      m.claimSet(new Coord(0, 0), new Coord(1, 0), new Coord(0, 2));
      m.claimSet(new Coord(0, 2), new Coord(1, 2), new Coord(2, 2));
    });
    Assert.assertThrows(IllegalArgumentException.class, () -> {
      m.claimSet(new Coord(4, 7), new Coord(5, 9), new Coord(11, 8));
    });

  }

  /**
   * Tester for startGameWithDeck.
   */
  @Test
  public void startGameWithDeck() {
    List<Card> deck = SetThreeGameModel.createDeck();
    m.startGameWithDeck(deck, 4, 5);
    assertEquals(m.getDeck(), deck);
  }

  /**
   * Tester for width getter.
   */
  @Test
  public void getWidth() {
    assertEquals(m.getWidth(), 4);

  }

  /**
   * Tester for height getter.
   */
  @Test
  public void getHeight() {
    assertEquals(m.getHeight(), 5);
  }

  /**
   * Tester for score getter.
   */
  @Test
  public void getScore() {
    assertEquals(m.getScore(), 0);
  }

  /**
   * Tester for anySetsPresent.
   */
  @Test
  public void anySetsPresent() {
    List<Card> deck = new ArrayList<Card>();
    deck.add(new Card("one", "full", "diamond")); //0,0
    deck.add(new Card("two", "full", "oval")); //0,1
    deck.add(new Card("three", "full", "squiggle"));//0,2
    deck.add(new Card("one", "striped", "oval"));//0,3

    //comb 2
    deck.add(new Card("three", "striped", "squiggle"));//1,0
    deck.add(new Card("two", "empty", "squiggle"));//1,1
    deck.add(new Card("one", "full", "squiggle")); //1,2
    deck.add(new Card("one", "full", "oval"));//1,3

    //comb3
    deck.add(new Card("three", "full", "oval"));//2,0
    deck.add(new Card("two", "full", "oval"));//2,1
    deck.add(new Card("one", "full", "oval"));//2,2
    deck.add(new Card("one", "full", "diamond"));//2,3

    // fourth row
    deck.add(new Card("three", "empty", "oval"));//3,0
    deck.add(new Card("two", "full", "oval"));//3,1
    deck.add(new Card("one", "full", "oval"));//3,2
    deck.add(new Card("two", "full", "oval"));//3,3

    // fifth row
    deck.add(new Card("three", "full", "oval"));//3,0
    deck.add(new Card("two", "full", "oval"));//3,1
    deck.add(new Card("one", "full", "oval"));//3,2
    deck.add(new Card("two", "full", "oval"));//3,3

    // sixth row
    deck.add(new Card("three", "full", "oval"));//3,0
    deck.add(new Card("two", "full", "oval"));//3,1
    deck.add(new Card("one", "full", "oval"));//3,2
    deck.add(new Card("two", "full", "oval"));//3,3

    m.startGameWithDeck(deck, 4, 5);
    Assert.assertTrue(m.anySetsPresent());
  }

  /**
   * Tester for isValidSet.
   */
  @Test
  public void isValidSet() {
    List<Card> deck = new ArrayList<Card>();
    deck.add(new Card("one", "full", "diamond")); //0,0
    deck.add(new Card("two", "full", "oval")); //0,1
    deck.add(new Card("three", "full", "squiggle"));//0,2
    deck.add(new Card("one", "striped", "oval"));//0,3

    //comb 2
    deck.add(new Card("three", "striped", "squiggle"));//1,0
    deck.add(new Card("two", "empty", "squiggle"));//1,1
    deck.add(new Card("one", "full", "squiggle")); //1,2
    deck.add(new Card("one", "full", "oval"));//1,3

    //comb3
    deck.add(new Card("three", "full", "oval"));//2,0
    deck.add(new Card("two", "full", "oval"));//2,1
    deck.add(new Card("one", "full", "oval"));//2,2
    deck.add(new Card("one", "full", "diamond"));//2,3

    // fourth row
    deck.add(new Card("three", "empty", "oval"));//3,0
    deck.add(new Card("two", "full", "oval"));//3,1
    deck.add(new Card("one", "full", "oval"));//3,2
    deck.add(new Card("two", "full", "oval"));//3,3

    // fifth row
    deck.add(new Card("three", "full", "oval"));//3,0
    deck.add(new Card("two", "full", "oval"));//3,1
    deck.add(new Card("one", "full", "oval"));//3,2
    deck.add(new Card("two", "full", "oval"));//3,3

    // sixth row
    deck.add(new Card("three", "full", "oval"));//3,0
    deck.add(new Card("two", "full", "oval"));//3,1
    deck.add(new Card("one", "full", "oval"));//3,2
    deck.add(new Card("two", "full", "oval"));//3,3

    m.startGameWithDeck(deck, 4, 5);
    System.out.println(m.getWidth());
    // combo
    Coord c1 = new Coord(0, 0);
    Coord c2 = new Coord(0, 1);
    Coord c3 = new Coord(0, 2);
    //combo
    Coord c4 = new Coord(0, 3);
    Coord c5 = new Coord(2, 1);
    Coord c6 = new Coord(3, 0);

    Coord c7 = new Coord(1, 0);
    Coord c8 = new Coord(1, 1);
    Coord c9 = new Coord(1, 2);

    Assert.assertTrue(m.isValidSet(c1, c2, c3));
    Assert.assertTrue(m.isValidSet(c4, c5, c6));
  }

  /**
   * Tester forGetCardAtRowCol.
   */
  @Test
  public void testGetCardAtRowCol() {
    List<Card> deck = new ArrayList<Card>();
    deck.add(new Card("one", "full", "diamond")); //0,0
    deck.add(new Card("two", "full", "oval")); //0,1
    deck.add(new Card("three", "full", "squiggle"));//0,2
    deck.add(new Card("one", "striped", "oval"));//0,3

    //comb 2
    deck.add(new Card("three", "striped", "squiggle"));//1,0
    deck.add(new Card("two", "empty", "squiggle"));//1,1
    deck.add(new Card("one", "full", "squiggle")); //1,2
    deck.add(new Card("one", "full", "oval"));//1,3

    //comb3
    deck.add(new Card("three", "full", "oval"));//2,0
    deck.add(new Card("two", "full", "oval"));//2,1
    deck.add(new Card("one", "full", "oval"));//2,2
    deck.add(new Card("one", "full", "diamond"));//2,3

    // fourth row
    deck.add(new Card("three", "empty", "oval"));//3,0
    deck.add(new Card("two", "full", "oval"));//3,1
    deck.add(new Card("one", "full", "oval"));//3,2
    deck.add(new Card("two", "full", "oval"));//3,3

    // fifth row
    deck.add(new Card("three", "full", "oval"));//3,0
    deck.add(new Card("two", "full", "oval"));//3,1
    deck.add(new Card("one", "full", "oval"));//3,2
    deck.add(new Card("two", "full", "oval"));//3,3

    // sixth row
    deck.add(new Card("three", "full", "oval"));//3,0
    deck.add(new Card("two", "full", "oval"));//3,1
    deck.add(new Card("one", "full", "oval"));//3,2
    deck.add(new Card("two", "full", "oval"));//3,3

    Card c = deck.get(0);
    m.startGameWithDeck(deck, 4, 5);
    assertEquals(m.getCardAtCoord(0, 0), c);
    assertEquals(m.getCardAtCoord(new Coord(1, 0)).toString(), "3SQ");
  }

  /**
   * Tester forGetCardAtCoord.
   */
  @Test
  public void testGetCardAtCoord() {
    List<Card> deck = new ArrayList<Card>();
    deck.add(new Card("one", "full", "diamond")); //0,0
    deck.add(new Card("two", "full", "oval")); //0,1
    deck.add(new Card("three", "full", "squiggle"));//0,2
    deck.add(new Card("one", "striped", "oval"));//0,3

    //comb 2
    deck.add(new Card("three", "striped", "squiggle"));//1,0
    deck.add(new Card("two", "empty", "squiggle"));//1,1
    deck.add(new Card("one", "full", "squiggle")); //1,2
    deck.add(new Card("one", "full", "oval"));//1,3

    //comb3
    deck.add(new Card("three", "full", "oval"));//2,0
    deck.add(new Card("two", "full", "oval"));//2,1
    deck.add(new Card("one", "full", "oval"));//2,2
    deck.add(new Card("one", "full", "diamond"));//2,3

    // fourth row
    deck.add(new Card("three", "empty", "oval"));//3,0
    deck.add(new Card("two", "full", "oval"));//3,1
    deck.add(new Card("one", "full", "oval"));//3,2
    deck.add(new Card("two", "full", "oval"));//3,3

    // fifth row
    deck.add(new Card("three", "full", "oval"));//3,0
    deck.add(new Card("two", "full", "oval"));//3,1
    deck.add(new Card("one", "full", "oval"));//3,2
    deck.add(new Card("two", "full", "oval"));//3,3

    // sixth row
    deck.add(new Card("three", "full", "oval"));//3,0
    deck.add(new Card("two", "full", "oval"));//3,1
    deck.add(new Card("one", "full", "oval"));//3,2
    deck.add(new Card("two", "full", "oval"));//3,3
    Card c = deck.get(0);
    m.startGameWithDeck(deck, 4, 5);

    assertEquals(m.getCardAtCoord(new Coord(0, 0)), c);
    System.out.println(deck);
    assertEquals(m.getCardAtCoord(new Coord(1, 0)).toString(), "3SQ");
    assertEquals(m.getCardAtCoord(new Coord(2, 0)).toString(), "3FO");
    assertEquals(m.getCardAtCoord(new Coord(1, 1)).toString(), "2EQ");


  }

  /**
   * Tester for IsGameOver, find if game is over.
   */
  @Test
  public void testIsGameOver() {
    List<Card> deck = m.getCompleteDeck();
    m.startGameWithDeck(deck, 4, 5);
    Assert.assertTrue(!m.isGameOver());
  }

  /**
   * Tester for GetCompleteDeck finds a completed deck.
   */
  @Test
  public void testGetCompleteDeck() {
    List<Card> deck = m.getCompleteDeck();
    m.startGameWithDeck(deck, 4, 5);
    assertEquals(m.getDeck(), deck);

  }


  /**
   * Tester for ValidStartingBoard.
   */
  @Test
  public void testValidStartingBoard() {
    List<Card> deck = new ArrayList<Card>();
    deck.add(new Card("one", "full", "diamond")); //0,0
    deck.add(new Card("two", "full", "oval")); //0,1
    deck.add(new Card("three", "full", "squiggle"));//0,2
    deck.add(new Card("one", "striped", "oval"));//0,3

    //comb 2
    deck.add(new Card("three", "striped", "squiggle"));//1,0
    deck.add(new Card("two", "empty", "squiggle"));//1,1
    deck.add(new Card("one", "full", "squiggle")); //1,2
    deck.add(new Card("one", "full", "oval"));//1,3

    //comb3
    deck.add(new Card("three", "full", "oval"));//2,0
    deck.add(new Card("two", "full", "oval"));//2,1
    deck.add(new Card("one", "full", "oval"));//2,2
    deck.add(new Card("one", "full", "diamond"));//2,3

    // fourth row
    deck.add(new Card("three", "empty", "oval"));//3,0
    deck.add(new Card("two", "full", "oval"));//3,1
    deck.add(new Card("one", "full", "oval"));//3,2
    deck.add(new Card("two", "full", "oval"));//3,3

    // fifth row
    deck.add(new Card("three", "full", "oval"));//3,0
    deck.add(new Card("two", "full", "oval"));//3,1
    deck.add(new Card("one", "full", "oval"));//3,2
    deck.add(new Card("two", "full", "oval"));//3,3

    // sixth row
    deck.add(new Card("three", "full", "oval"));//3,0
    deck.add(new Card("two", "full", "oval"));//3,1
    deck.add(new Card("one", "full", "oval"));//3,2
    deck.add(new Card("two", "full", "oval"));//3,3

    m.startGameWithDeck(deck, 4, 5);
    assertEquals(m.getDeck(), deck);
  }

  /**
   * Tester for CorrectScoreAfterGame.
   */
  @Test
  public void testCorrectScoreAfterGame() {
    List<Card> deck = new ArrayList<Card>();
    deck.add(new Card("one", "full", "diamond")); //0,0
    deck.add(new Card("two", "full", "oval")); //0,1
    deck.add(new Card("three", "full", "squiggle"));//0,2
    deck.add(new Card("one", "striped", "oval"));//0,3

    //comb 2
    deck.add(new Card("three", "striped", "squiggle"));//1,0
    deck.add(new Card("two", "empty", "squiggle"));//1,1
    deck.add(new Card("one", "full", "squiggle")); //1,2
    deck.add(new Card("one", "full", "oval"));//1,3

    //comb3
    deck.add(new Card("three", "full", "oval"));//2,0
    deck.add(new Card("two", "full", "oval"));//2,1
    deck.add(new Card("one", "full", "oval"));//2,2
    deck.add(new Card("one", "full", "diamond"));//2,3

    // fourth row
    deck.add(new Card("three", "empty", "oval"));//3,0
    deck.add(new Card("two", "full", "oval"));//3,1
    deck.add(new Card("one", "full", "oval"));//3,2
    deck.add(new Card("two", "full", "oval"));//3,3

    // fifth row
    deck.add(new Card("three", "full", "oval"));//4,0
    deck.add(new Card("two", "full", "oval"));//3,1
    deck.add(new Card("one", "full", "oval"));//3,2
    deck.add(new Card("two", "full", "oval"));//3,3

    // sixth row
    deck.add(new Card("three", "full", "oval"));//3,0
    deck.add(new Card("two", "full", "oval"));//3,1
    deck.add(new Card("one", "full", "oval"));//3,2
    deck.add(new Card("two", "full", "oval"));//3,3

    m.startGameWithDeck(deck, 4, 5);
    m.claimSet(new Coord(0, 0), new Coord(0, 1), new Coord(0, 2));
    assertEquals(1, m.getScore());
    m.claimSet(new Coord(1, 0), new Coord(1, 1), new Coord(1, 2));
    assertEquals(2, m.getScore());
    m.claimSet(new Coord(2, 0), new Coord(2, 1), new Coord(2, 2));
    assertEquals(3, m.getScore());
    m.claimSet(new Coord(4, 0), new Coord(4, 1), new Coord(4, 2));
    assertEquals(4, m.getScore());
    assertEquals(true, m.isGameOver());

  }

  /**
   * tester for BoardChangeAfterSet.
   */
  @Test
  public void testBoardChangeAfterSet() {
    List<Card> deck = new ArrayList<Card>();
    deck.add(new Card("one", "full", "diamond")); //0,0
    deck.add(new Card("two", "full", "oval")); //0,1
    deck.add(new Card("three", "full", "squiggle"));//0,2
    deck.add(new Card("one", "striped", "oval"));//0,3

    //comb 2
    deck.add(new Card("three", "striped", "squiggle"));//1,0
    deck.add(new Card("two", "empty", "squiggle"));//1,1
    deck.add(new Card("one", "full", "squiggle")); //1,2
    deck.add(new Card("one", "full", "oval"));//1,3

    //comb3
    deck.add(new Card("three", "full", "oval"));//2,0
    deck.add(new Card("two", "full", "oval"));//2,1
    deck.add(new Card("one", "full", "oval"));//2,2
    deck.add(new Card("one", "full", "diamond"));//2,3

    // fourth row
    deck.add(new Card("three", "empty", "oval"));//3,0
    deck.add(new Card("two", "full", "oval"));//3,1
    deck.add(new Card("one", "full", "oval"));//3,2
    deck.add(new Card("two", "full", "oval"));//3,3

    // fifth row
    deck.add(new Card("three", "full", "oval"));//4,0
    deck.add(new Card("two", "full", "oval"));//3,1
    deck.add(new Card("one", "full", "oval"));//3,2
    deck.add(new Card("two", "full", "oval"));//3,3

    // sixth row
    deck.add(new Card("three", "full", "oval"));//3,0
    deck.add(new Card("two", "full", "oval"));//3,1
    deck.add(new Card("one", "full", "oval"));//3,2
    deck.add(new Card("two", "full", "oval"));//3,3
    m.startGameWithDeck(deck, 4, 5);
    assertEquals(m.getDeck(), deck);
  }


  /**
   * Tester for BoardChangeAfterSet.
   */
  @Test
  public void testBoardChangeAfterSetNonSortedOrder() {
    List<Card> deck = new ArrayList<Card>();
    deck.add(new Card("one", "full", "diamond")); //0,0
    deck.add(new Card("two", "full", "oval")); //0,1
    deck.add(new Card("three", "full", "squiggle"));//0,2
    deck.add(new Card("one", "striped", "oval"));//0,3

    //comb 2
    deck.add(new Card("three", "striped", "squiggle"));//1,0
    deck.add(new Card("two", "empty", "squiggle"));//1,1
    deck.add(new Card("one", "full", "squiggle")); //1,2
    deck.add(new Card("one", "full", "oval"));//1,3

    //comb3
    deck.add(new Card("three", "full", "oval"));//2,0
    deck.add(new Card("two", "full", "oval"));//2,1
    deck.add(new Card("one", "full", "oval"));//2,2
    deck.add(new Card("one", "full", "diamond"));//2,3

    // fourth row
    deck.add(new Card("three", "empty", "oval"));//3,0
    deck.add(new Card("two", "full", "oval"));//3,1
    deck.add(new Card("one", "full", "oval"));//3,2
    deck.add(new Card("two", "full", "oval"));//3,3

    // fifth row
    deck.add(new Card("three", "full", "oval"));//4,0
    deck.add(new Card("two", "full", "oval"));//3,1
    deck.add(new Card("one", "full", "oval"));//3,2
    deck.add(new Card("two", "full", "oval"));//3,3

    // sixth row
    deck.add(new Card("three", "full", "oval"));//3,0
    deck.add(new Card("two", "full", "oval"));//3,1
    deck.add(new Card("one", "full", "oval"));//3,2
    deck.add(new Card("two", "full", "oval"));//3,3
    m.startGameWithDeck(deck, 4, 5);
    assertEquals(m.getDeck(), deck);
  }


  /**
   * Tester for IncorrectSetClaim.
   */
  @Test
  public void testIncorrectSetClaim() {
    List<Card> deck = m.createDeck();
    m.startGameWithDeck(deck, 4, 5);
    assertEquals(false, m.isGameOver());
    Assert.assertThrows(IllegalArgumentException.class, () -> {
      m.claimSet(new Coord(1, 2), new Coord(1, 2), new Coord(1, 2));
    });
    assertEquals(0, m.getScore());
    // null
  }
  //  /**
  //   * Tester for GetCardIsValid.
  //   */
  //  @Test
  //  public void testGetCardIsValid() {
  //
  //  }


  /**
   * Tester for BoardChangeAfterNoSet.
   */
  @Test
  public void testBoardChangeAfterNoSet() {
    GeneralSetGameModel m = new GeneralSetGameModel();
    List<Card> deck = m.createDeck();
    m.startGameWithDeck(deck, 4, 5);
    assertEquals(false, m.isGameOver());
    Assert.assertThrows(IllegalArgumentException.class, () -> {
      m.claimSet(new Coord(1, 2), new Coord(1, 2), new Coord(1, 2));
    });


  }
  //
  //  /**
  //   * Tester for BoardChangeAfterNoSet.
  //   */
  //  @Test
  //  public void testBoardChangeAfterNoSet() {
  //    // null
  //
  //  }

  /**
   * Tester for GameIsOverWhenNoCardsInDeck.
   */
  @Test
  public void testGameIsOverWhenNoCardsInDeck() {
    List<Card> deck = new ArrayList<Card>();
    deck.add(new Card("one", "full", "diamond")); //0,0
    deck.add(new Card("two", "full", "oval")); //0,1
    deck.add(new Card("three", "full", "squiggle"));//0,2
    deck.add(new Card("one", "striped", "oval"));//0,3

    //comb 2
    deck.add(new Card("three", "striped", "squiggle"));//1,0
    deck.add(new Card("two", "empty", "squiggle"));//1,1
    deck.add(new Card("one", "full", "squiggle")); //1,2
    deck.add(new Card("one", "full", "oval"));//1,3

    //comb3
    deck.add(new Card("three", "full", "oval"));//2,0
    deck.add(new Card("two", "full", "oval"));//2,1
    deck.add(new Card("one", "full", "oval"));//2,2
    deck.add(new Card("one", "full", "diamond"));//2,3

    // fourth row
    deck.add(new Card("three", "empty", "oval"));//3,0
    deck.add(new Card("two", "full", "oval"));//3,1
    deck.add(new Card("one", "full", "oval"));//3,2
    deck.add(new Card("two", "full", "oval"));//3,3

    // fifth row
    deck.add(new Card("three", "full", "oval"));//4,0
    deck.add(new Card("two", "full", "oval"));//4,1
    deck.add(new Card("one", "full", "oval"));//4,2
    deck.add(new Card("two", "full", "oval"));//4,3

    // sixth row
    deck.add(new Card("three", "full", "oval"));//3,0
    deck.add(new Card("two", "full", "oval"));//3,1
    deck.add(new Card("one", "full", "oval"));//3,2
    deck.add(new Card("two", "full", "oval"));//3,3
    GeneralSetGameModel m = new GeneralSetGameModel();
    m.startGameWithDeck(deck, 4, 5);
    m.claimSet(new Coord(0, 0), new Coord(0, 1), new Coord(0, 2));
    assertEquals(1, m.getScore());
    m.claimSet(new Coord(1, 0), new Coord(1, 1), new Coord(1, 2));
    assertEquals(2, m.getScore());
    m.claimSet(new Coord(2, 0), new Coord(2, 1), new Coord(2, 2));
    assertEquals(3, m.getScore());
    m.claimSet(new Coord(4, 0), new Coord(4, 1), new Coord(4, 2));
    assertEquals(4, m.getScore());
    assertEquals(true, m.isGameOver());

  }
  //null

  /**
   * Tester for Game.
   */
  @Test
  public void testGame() {
    List<Card> deck = new ArrayList<Card>();
    //combo 1
    deck.add(new Card("one", "full", "diamond")); //0,0
    deck.add(new Card("two", "full", "oval")); //0,1
    deck.add(new Card("three", "full", "squiggle"));//0,2
    deck.add(new Card("one", "striped", "oval"));//0,3

    //comb 2
    deck.add(new Card("three", "striped", "squiggle"));//1,0
    deck.add(new Card("two", "empty", "squiggle"));//1,1
    deck.add(new Card("one", "full", "squiggle")); //1,2
    deck.add(new Card("one", "full", "oval"));//1,3

    //comb3
    deck.add(new Card("three", "full", "oval"));//2,0
    deck.add(new Card("two", "full", "oval"));//2,1
    deck.add(new Card("one", "full", "oval"));//2,2
    deck.add(new Card("one", "full", "diamond"));//2,3

    // fourth row
    deck.add(new Card("three", "empty", "oval"));//3,0
    deck.add(new Card("two", "full", "oval"));//3,1
    deck.add(new Card("one", "full", "oval"));//3,2
    deck.add(new Card("two", "full", "oval"));//3,3

    // fifth row
    deck.add(new Card("three", "full", "oval"));//4,0
    deck.add(new Card("two", "full", "oval"));//4,1
    deck.add(new Card("one", "full", "oval"));//4,2
    deck.add(new Card("two", "full", "oval"));//4,3

    // sixth row
    deck.add(new Card("three", "full", "oval"));//3,0
    deck.add(new Card("two", "full", "oval"));//3,1
    deck.add(new Card("one", "full", "oval"));//3,2
    deck.add(new Card("two", "full", "oval"));//3,3
    GeneralSetGameModel m = new GeneralSetGameModel();
    m.startGameWithDeck(deck, 4, 5);
    m.claimSet(new Coord(0, 0), new Coord(0, 1), new Coord(0, 2));
    assertEquals(1, m.getScore());
    m.claimSet(new Coord(2, 0), new Coord(2, 1), new Coord(2, 2));
    assertEquals(2, m.getScore());
    //    gameModel.claimSet(new Coord(0, 2), new Coord(2, 1), new Coord(2, 2));
    //    Assert.assertNull(3, gameModel.getScore());
    //    assertEquals(true,gameModel.isGameOver());

  }
  //  @Test
  //  public void TesttoString() {
  //    System.out.println(m.toString());
  //
  //  }

  //  /**
  //   * Tester for ClaimOnLargerBoard.
  //   */
  //  @Test
  //  public void testClaimOnLargerBoard() {
  //    List<Card> deck = new ArrayList<Card>();
  //    //row 3
  //    // 1ED 2FD 3ED 2SD 3SO
  //    deck.add(new Card("one", "empty", "diamond")); //0,0
  //    deck.add(new Card("two", "full", "diamond")); //0,1
  //    deck.add(new Card("three", "empty", "diamond"));//0,2
  //    deck.add(new Card("two", "striped", "diamond"));//0,3
  //    deck.add(new Card("three", "striped", "oval"));//0,3
  //    //row 2
  //    // 2FO 1FQ 2EQ 1EQ 2FQ
  //    deck.add(new Card("two", "full", "oval")); //0,0
  //    deck.add(new Card("one", "full", "squiggle")); //0,1
  //    deck.add(new Card("two", "empty", "squiggle"));//0,2
  //    deck.add(new Card("one", "empty", "squiggle"));//0,3
  //    deck.add(new Card("two", "full", "squiggle"));//0,3
  //    //row 3
  //    //3SQ 2EO 3EQ 1SD 3FD
  //    deck.add(new Card("three", "striped", "squiggle")); //0,0
  //    deck.add(new Card("two", "empty", "oval")); //0,1
  //    deck.add(new Card("three", "empty", "squiggle"));//0,2
  //    deck.add(new Card("one", "striped", "diamond"));//0,3
  //    deck.add(new Card("three", "full", "diamond"));//0,3
  //    //row4
  //    // 3EO 1EO 2SO 2ED 1SO
  //    deck.add(new Card("three", "empty", "oval")); //0,0
  //    deck.add(new Card("one", "empty", "oval")); //0,1
  //    deck.add(new Card("two", "empty", "oval"));//0,2
  //    deck.add(new Card("two", "empty", "diamond"));//0,3
  //    deck.add(new Card("one", "striped", "oval"));//0,3
  //    GeneralSetGameModel m = new GeneralSetGameModel();
  //    m.startGameWithDeck(deck, 4, 5);
  //    m.claimSet(new Coord(0, 0), new Coord(1, 3), new Coord(3, 1));
  //    assertEquals(1, m.getScore());
  //
  //
  //  }


}
