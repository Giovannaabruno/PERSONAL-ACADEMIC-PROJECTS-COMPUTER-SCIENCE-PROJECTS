package cs3500.set.model.hw02;

//Counts are represented as 1, 2, or 3
//
//Fillings are represented as E for empty, S for striped, and F for full
//
//Shapes are represented as O for oval, Q for squiggle, and D for diamond

//Count with values 1, 2, and 3

// Filling with values empty, striped, and full

// Shape with values oval, squiggle, and diamond



import org.junit.Test;

import static org.junit.Assert.assertEquals;


/**
 * Testers class for Card for class.
 */
public class CardTest {

  /**
   * tester for ToString for Card, test the correct input and output for card.
   */
  @Test
  public void testToString() {
    Card card1 = new Card("one", "striped", "diamond");
    assertEquals(card1.toString(), "1SD");

    Card card2 = new Card("two", "empty", "oval");
    assertEquals(card2.toString(), "2EO");

    Card card3 = new Card("three", "full", "squiggle");
    assertEquals(card3.toString(), "3FQ");

    Card card4 = new Card("two", "striped", "oval");
    assertEquals(card4.toString(), "2SO");

    Card card5 = new Card("one", "full", "diamond");
    assertEquals(card5.toString(), "1FD");
  }
}