package cs3500.set.model.hw02;

import org.junit.Test;
import org.junit.Assert;

import java.util.Objects;


/**
 * Testers for Coord class.
 */
public class CoordTest {
  // 3 x 3 = 0-1 in cordinaties.

  /**
   * Tester for ToString for Coord, test correct formatting with examples of correct coordinator.
   */
  @Test
  public void testToString() {
    Coord c1 = new Coord(0, 1);
    Assert.assertEquals(c1.toString(), "(r0,c1)");

    Coord c2 = new Coord(1, 2);
    Assert.assertEquals(c2.toString(), "(r1,c2)");

    Coord c3 = new Coord(2, 2);
    Assert.assertEquals(c3.toString(), "(r2,c2)");

    Coord c4 = new Coord(3, 1);
    Assert.assertEquals(c4.toString(), "(r3,c1)");

    Coord c5 = new Coord(-1, -3);
    Assert.assertFalse(c5.toString(), false);
  }

  /**
   * Tester for Equals for Coord.
   */
  @Test
  public void testEquals() {
    Coord equals1 = new Coord(0, 0);
    Assert.assertEquals(equals1, equals1);
    Coord equals2 = new Coord(0, 1);
    Assert.assertNotEquals(equals1, equals2);
    Coord equals3 = new Coord(0, 0);
    Assert.assertEquals(equals1, equals3);
    Coord equals4 = new Coord(2, 2);
    Assert.assertNotEquals(equals1, equals4);
  }

  /**
   * Tester for HashCode for Coord.
   */
  @Test
  public void testHashCode() {
    Coord c1 = new Coord(0, 0);
    Assert.assertEquals(c1.hashCode(), Objects.hash(c1.row, c1.col));

    Coord c2 = new Coord(1, 0);
    Assert.assertEquals(c2.hashCode(), Objects.hash(c2.row, c2.col));


    Coord c3 = new Coord(1, 1);
    Assert.assertEquals(c3.hashCode(), Objects.hash(c3.row, c3.col));


    Coord c4 = new Coord(2, 3);
    Assert.assertEquals(c4.hashCode(), Objects.hash(c4.row, c4.col));


    Coord c5 = new Coord(3, 0);
    Assert.assertEquals(c5.hashCode(), Objects.hash(c5.row, c5.col));
  }
}