
package cs3500.set.model.hw02;

import org.junit.Assert;
import org.junit.Test;
// TO DO:
// If have two separate Set objects with the same three coordinates in different orders, for
// example[(1,3), (2,2), (3,1)] and [(3,1), (2,2), (1,3)], it will correctly say they
// are equal to each other

// need to be finsihed

/**
 * Tester for Set class.
 */
public class SetTest {
  // 2 set opptions
  // several cordiat option.
  // test for stuff that is not equal, one that is equal and others are not

  /**
   * Tester for Equals for Set.
   */
  @Test
  public void testEquals() {
    Coord c1 = new Coord(0, 0);
    Coord c2 = new Coord(2, 2);
    Coord c3 = new Coord(0, 0);
    Coord c4 = new Coord(2, 2);
    Coord c5 = new Coord(0, 1);
    Coord c6 = new Coord(1, 0);
    Coord c7 = new Coord(1, 1);
    Coord c8 = new Coord(0, 1);
    Coord c9 = new Coord(1, 0);
    Coord c10 = new Coord(2, 1);
    Coord c11 = new Coord(2, 0);
    //Equals
    Set set1 = new Set(c1, c2, c7);
    Set set2 = new Set(c7, c1, c2);

    Set set3 = new Set(c3, c5, c8);
    Set set4 = new Set(c5, c8, c3);

    Set set5 = new Set(c9, c3, c11);
    Set set6 = new Set(c11, c9, c3);
    // not equals
    Set set7 = new Set(c4, c6, c10);
    Set set8 = new Set(c7, c1, c2);

    Assert.assertTrue(set1.equals(set2));
    Assert.assertTrue(set3.equals(set4));
    Assert.assertTrue(set5.equals(set6));
    Assert.assertTrue(!set7.equals(set8));

  }
}