package cs3500.set.model.hw02;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;


/**
 * Testers for SetThreeGameModel class.
 */
public class SetThreeGameModelTest {

  SetThreeGameModel m = new SetThreeGameModel();


  /**
   * SetUp represents for SetThreeGameModel, a 3X3 grid.
   */
  @Before
  public void testSetUp() {
    List<Card> deck = SetThreeGameModel.createDeck();
    m.startGameWithDeck(deck, 3, 3);

  }

  /**
   * Tester for claimSet, a claim a correct completed set.
   */
  @Test
  public void claimSet() {
    List<Card> deck = SetThreeGameModel.createDeck();
    System.out.println(deck);
    m.startGameWithDeck(deck, 3, 3);
    Assert.assertThrows(IllegalArgumentException.class, () -> {
      m.claimSet(new Coord(0, 0), new Coord(1, 0), new Coord(0, 2));
      m.claimSet(new Coord(0, 2), new Coord(1, 2), new Coord(2, 2));
    });
    Assert.assertThrows(IllegalArgumentException.class, () -> {
      m.claimSet(new Coord(4, 7), new Coord(5, 9), new Coord(11, 8));
    });

  }

  /**
   * Tester for startGameWithDeck.
   */
  @Test
  public void startGameWithDeck() {
    List<Card> deck = SetThreeGameModel.createDeck();
    m.startGameWithDeck(deck, 3, 3);
    assertEquals(m.getDeck(), deck);
  }

  /**
   * Tester for width getter.
   */
  @Test
  public void getWidth() {
    assertEquals(m.getWidth(), 3);

  }

  /**
   * Tester for height getter.
   */
  @Test
  public void getHeight() {
    assertEquals(m.getHeight(), 3);
  }

  /**
   * Tester for score getter.
   */
  @Test
  public void getScore() {
    assertEquals(m.getScore(), 0);
  }

  /**
   * Tester for anySetsPresent.
   */
  @Test
  public void anySetsPresent() {
    Assert.assertTrue(m.anySetsPresent());
  }

  /**
   * Tester for isValidSet.
   */
  @Test
  public void isValidSet() {

    List<Card> deck = new ArrayList<Card>();
    deck.add(new Card("one", "full", "diamond"));
    deck.add(new Card("two", "full", "oval"));
    deck.add(new Card("three", "full", "squiggle"));
    //comb 2
    deck.add(new Card("three", "striped", "squiggle"));
    deck.add(new Card("two", "empty", "squiggle"));
    deck.add(new Card("one", "full", "squiggle"));
    //comb3
    deck.add(new Card("three", "striped", "oval"));
    deck.add(new Card("two", "striped", "oval"));
    deck.add(new Card("one", "striped", "oval"));
    m.startGameWithDeck(deck, 3, 3);

    Coord c1 = new Coord(0, 0);
    Coord c2 = new Coord(0, 1);
    Coord c3 = new Coord(0, 2);

    Coord c4 = new Coord(0, 0);
    Coord c5 = new Coord(1, 0);
    Coord c6 = new Coord(2, 0);
    Assert.assertTrue(m.isValidSet(c1, c2, c3));
    Assert.assertFalse(m.isValidSet(c4, c5, c5));
  }

  /**
   * Tester forGetCardAtRowCol.
   */
  @Test
  public void testGetCardAtRowCol() {
    List<Card> deck = new ArrayList<Card>();
    deck.add(new Card("one", "full", "diamond"));
    deck.add(new Card("two", "full", "oval"));
    deck.add(new Card("three", "full", "squiggle"));
    //comb 2
    deck.add(new Card("three", "striped", "squiggle"));
    deck.add(new Card("two", "empty", "squiggle"));
    deck.add(new Card("one", "full", "squiggle"));
    //comb3
    deck.add(new Card("three", "striped", "oval"));
    deck.add(new Card("two", "striped", "oval"));
    deck.add(new Card("one", "striped", "oval"));

    Card c = deck.get(0);
    m.startGameWithDeck(deck, 3, 3);
    assertEquals(m.getCardAtCoord(0, 0), c);
    assertEquals(m.getCardAtCoord(new Coord(1, 0)).toString(), "3SQ");
  }

  /**
   * Tester forGetCardAtCoord.
   */
  @Test
  public void testGetCardAtCoord() {
    List<Card> deck = new ArrayList<Card>();
    deck.add(new Card("one", "full", "diamond"));
    deck.add(new Card("two", "full", "oval"));
    deck.add(new Card("three", "full", "squiggle"));
    //comb 2
    deck.add(new Card("three", "striped", "squiggle"));
    deck.add(new Card("two", "empty", "squiggle"));
    deck.add(new Card("one", "full", "squiggle"));
    //comb3
    deck.add(new Card("three", "striped", "oval"));
    deck.add(new Card("two", "striped", "oval"));
    deck.add(new Card("one", "striped", "oval"));

    Card c = deck.get(0);
    m.startGameWithDeck(deck, 3, 3);

    assertEquals(m.getCardAtCoord(new Coord(0, 0)), c);
    System.out.println(deck);
    assertEquals(m.getCardAtCoord(new Coord(1, 0)).toString(), "3SQ");
    assertEquals(m.getCardAtCoord(new Coord(2, 0)).toString(), "3SO");
    assertEquals(m.getCardAtCoord(new Coord(1, 1)).toString(), "2EQ");


  }

  /**
   * Tester for IsGameOver, find if game is over.
   */
  @Test
  public void testIsGameOver() {
    Assert.assertTrue(!m.isGameOver());

  }

  /**
   * Tester for GetCompleteDeck finds a completed deck.
   */
  @Test
  public void testGetCompleteDeck() {
    List<Card> deck = SetThreeGameModel.createDeck();
    m.startGameWithDeck(deck, 3, 3);
    assertEquals(m.getDeck(), deck);

  }


  /**
   * Tester for ValidStartingBoard.
   */
  @Test
  public void testValidStartingBoard() {
    List<Card> deck = new ArrayList<Card>();
    deck.add(new Card("one", "empty", "squiggle"));
    deck.add(new Card("two", "full", "oval"));
    deck.add(new Card("one", "empty", "diamond"));

    deck.add(new Card("two", "striped", "diamond"));
    deck.add(new Card("three", "striped", "oval"));
    deck.add(new Card("two", "empty", "diamond"));
    //comb 2
    deck.add(new Card("one", "full", "squiggle"));
    deck.add(new Card("two", "empty", "squiggle"));
    deck.add(new Card("three", "empty", "diamond"));
    //comb3
    deck.add(new Card("two", "striped", "diamond"));
    deck.add(new Card("three", "striped", "oval"));
    deck.add(new Card("two", "empty", "diamond"));
    //comb4
    deck.add(new Card("one", "full", "squiggle"));
    deck.add(new Card("two", "empty", "squiggle"));
    deck.add(new Card("three", "empty", "diamond"));
    m.startGameWithDeck(deck, 3, 3);
    assertEquals(m.getDeck(), deck);
  }

  /**
   * Tester for CorrectScoreAfterGame.
   */
  @Test
  public void testCorrectScoreAfterGame() {
    List<Card> deck = new ArrayList<Card>();
    //combo 1
    deck.add(new Card("one", "full", "diamond"));
    deck.add(new Card("two", "full", "oval"));
    deck.add(new Card("three", "full", "squiggle"));
    //comb 2
    deck.add(new Card("three", "striped", "squiggle"));
    deck.add(new Card("two", "empty", "squiggle"));
    deck.add(new Card("one", "full", "squiggle"));
    //comb3
    deck.add(new Card("three", "striped", "oval"));
    deck.add(new Card("two", "striped", "oval"));
    deck.add(new Card("one", "striped", "oval"));
    SetThreeGameModel gameModel = new SetThreeGameModel();
    gameModel.startGameWithDeck(deck, 3, 3);
    gameModel.claimSet(new Coord(0, 0), new Coord(0, 1), new Coord(0, 2));
    assertEquals(1, gameModel.getScore());
    gameModel.claimSet(new Coord(1, 0), new Coord(1, 1), new Coord(1, 2));
    assertEquals(2, gameModel.getScore());
    gameModel.claimSet(new Coord(2, 0), new Coord(2, 1), new Coord(2, 2));
    assertEquals(3, gameModel.getScore());
    gameModel.claimSet(new Coord(0, 0), new Coord(1, 1), new Coord(2, 0));
    assertEquals(4, gameModel.getScore());
    assertEquals(true, gameModel.isGameOver());

  }

  /**
   * tester for BoardChangeAfterSet.
   */
  @Test
  public void testBoardChangeAfterSet() {
    List<Card> deck = new ArrayList<Card>();
    deck.add(new Card("one", "empty", "squiggle"));
    deck.add(new Card("two", "full", "oval"));
    deck.add(new Card("two", "striped", "squiggle"));
    //comb 2
    deck.add(new Card("two", "striped", "diamond"));
    deck.add(new Card("three", "striped", "oval"));
    deck.add(new Card("one", "full", "diamond"));
    //comb3
    deck.add(new Card("one", "full", "squiggle"));
    deck.add(new Card("two", "empty", "squiggle"));
    deck.add(new Card("three", "full", "diamond"));
    //comb4
    deck.add(new Card("two", "striped", "diamond"));
    deck.add(new Card("three", "striped", "oval"));
    deck.add(new Card("three", "empty", "diamond"));

    //comb5
    deck.add(new Card("one", "full", "squiggle"));
    deck.add(new Card("two", "empty", "squiggle"));
    deck.add(new Card("three", "empty", "diamond"));
    m.startGameWithDeck(deck, 3, 3);
    assertEquals(m.getDeck(), deck);
  }


  /**
   * Tester for BoardChangeAfterSet.
   */
  @Test
  public void testBoardChangeAfterSetNonSortedOrder() {
    List<Card> deck = new ArrayList<Card>();
    deck.add(new Card("two", "striped", "diamond"));
    deck.add(new Card("three", "striped", "oval"));
    deck.add(new Card("three", "full", "diamond"));
    //comb 2
    deck.add(new Card("one", "full", "squiggle"));
    deck.add(new Card("two", "empty", "squiggle"));
    deck.add(new Card("one", "full", "diamond"));
    //comb3
    deck.add(new Card("two", "striped", "diamond"));
    deck.add(new Card("three", "striped", "oval"));
    deck.add(new Card("two", "empty", "diamond"));
    //comb4
    deck.add(new Card("one", "full", "squiggle"));
    deck.add(new Card("two", "empty", "squiggle"));
    deck.add(new Card("three", "empty", "diamond"));

    //comb5
    deck.add(new Card("one", "full", "squiggle"));
    deck.add(new Card("two", "empty", "squiggle"));
    deck.add(new Card("three", "empty", "diamond"));
    m.startGameWithDeck(deck, 3, 3);
    assertEquals(m.getDeck(), deck);
  }


  /**
   * Tester for IncorrectSetClaim(.
   */
  @Test
  public void testIncorrectSetClaim() {
    SetThreeGameModel board = new SetThreeGameModel();
    List<Card> deck = board.createDeck();
    board.startGameWithDeck(deck, 3, 3);
    assertEquals(false, board.isGameOver());
    Assert.assertThrows(IllegalArgumentException.class, () -> {
      board.claimSet(new Coord(1, 2), new Coord(1, 2), new Coord(1, 2));
    });
    assertEquals(0, board.getScore());
    // null
  }
  //  /**
  //   * Tester for GetCardIsValid.
  //   */
  //  @Test
  //  public void testGetCardIsValid() {
  //
  //  }


  /**
   * Tester for BoardChangeAfterNoSet.
   */
  @Test
  public void testBoardChangeAfterNoSet() {
    SetThreeGameModel board = new SetThreeGameModel();
    List<Card> deck = board.createDeck();
    board.startGameWithDeck(deck, 3, 3);
    assertEquals(false, board.isGameOver());
    Assert.assertThrows(IllegalArgumentException.class, () -> {
      board.claimSet(new Coord(1, 2), new Coord(1, 2), new Coord(1, 2));
    });


  }
  //
  //  /**
  //   * Tester for BoardChangeAfterNoSet.
  //   */
  //  @Test
  //  public void testBoardChangeAfterNoSet() {
  //    // null
  //
  //  }

  /**
   * Tester for GameIsOverWhenNoCardsInDeck.
   */
  @Test
  public void testGameIsOverWhenNoCardsInDeck() {
    List<Card> deck = new ArrayList<Card>();
    //combo 1
    deck.add(new Card("one", "full", "diamond"));
    deck.add(new Card("two", "full", "oval"));
    deck.add(new Card("three", "full", "squiggle"));
    //comb 2
    deck.add(new Card("three", "striped", "squiggle"));
    deck.add(new Card("two", "empty", "squiggle"));
    deck.add(new Card("one", "full", "squiggle"));
    //comb3
    deck.add(new Card("three", "striped", "oval"));
    deck.add(new Card("two", "striped", "oval"));
    deck.add(new Card("one", "striped", "oval"));
    SetThreeGameModel gameModel = new SetThreeGameModel();
    gameModel.startGameWithDeck(deck, 3, 3);
    gameModel.claimSet(new Coord(0, 0), new Coord(0, 1), new Coord(0, 2));
    assertEquals(1, gameModel.getScore());
    gameModel.claimSet(new Coord(1, 0), new Coord(1, 1), new Coord(1, 2));
    assertEquals(2, gameModel.getScore());
    gameModel.claimSet(new Coord(2, 0), new Coord(2, 1), new Coord(2, 2));
    assertEquals(3, gameModel.getScore());
    gameModel.claimSet(new Coord(0, 0), new Coord(1, 1), new Coord(2, 0));
    assertEquals(4, gameModel.getScore());
    assertEquals(true, gameModel.isGameOver());

  }
  //null

  /**
   * Tester for Game.
   */
  @Test
  public void testGame() {
    List<Card> deck = new ArrayList<Card>();
    //combo 1
    deck.add(new Card("one", "full", "diamond"));
    deck.add(new Card("two", "full", "oval"));
    deck.add(new Card("three", "full", "squiggle"));
    //comb 2
    deck.add(new Card("three", "striped", "squiggle"));
    deck.add(new Card("two", "empty", "squiggle"));
    deck.add(new Card("one", "full", "squiggle"));
    //comb3
    deck.add(new Card("three", "full", "oval"));
    deck.add(new Card("two", "full", "oval"));
    deck.add(new Card("one", "full", "oval"));
    SetThreeGameModel gameModel = new SetThreeGameModel();
    gameModel.startGameWithDeck(deck, 3, 3);
    gameModel.claimSet(new Coord(0, 0), new Coord(0, 1), new Coord(0, 2));
    assertEquals(1, gameModel.getScore());
    gameModel.claimSet(new Coord(2, 0), new Coord(2, 1), new Coord(2, 2));
    assertEquals(2, gameModel.getScore());
    //    gameModel.claimSet(new Coord(0, 2), new Coord(2, 1), new Coord(2, 2));
    //    Assert.assertNull(3, gameModel.getScore());
    //    assertEquals(true,gameModel.isGameOver());

  }


}
