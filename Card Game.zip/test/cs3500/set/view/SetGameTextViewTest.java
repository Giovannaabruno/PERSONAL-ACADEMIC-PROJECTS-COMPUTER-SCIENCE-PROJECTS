package cs3500.set.view;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.util.List;

import cs3500.set.model.hw02.Card;
import cs3500.set.model.hw02.SetThreeGameModel;

import static java.lang.System.out;


/**
 * Testers for SetGameTextViewTest class.
 */
public class SetGameTextViewTest {
  SetThreeGameModel m = new SetThreeGameModel();
  SetGameTextView v = new SetGameTextView(m, out);

  /**
   * SetUp represents for SetGameTextView, a 3X3 grid.
   */
  @Before
  public void setUp() {
    List<Card> deck = SetThreeGameModel.createDeck();
    m.startGameWithDeck(
            deck,
            3,
            3
    );

  }


  /**
   * Tester for ToString represents the illustrated format for the game-board.
   */
  @Test
  public void testToString() {
    out.println(v.toString());
    Assert.assertNotNull(v.toString());

  }
}
