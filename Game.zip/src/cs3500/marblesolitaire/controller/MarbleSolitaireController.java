package cs3500.marblesolitaire.controller;

import java.io.IOException;

/**
 * Represent the interface for MarbleSolitaire which sett up the objects and methods
 * for the Controller and game.
 */
public interface MarbleSolitaireController {


  /**
   * This method is used to play a new game of Marble Solitaire.
   * When used it will throw an IllegalStateException
   * only if the controller is unable to successfully
   * read the input or the transmit output.
   * @throws IOException if there is an error in the input or output
   */
  void playGame()
          throws IOException;
}