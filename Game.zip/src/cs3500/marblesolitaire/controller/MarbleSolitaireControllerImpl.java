package cs3500.marblesolitaire.controller;

import cs3500.marblesolitaire.model.hw02.EnglishSolitaireModel;
import cs3500.marblesolitaire.model.hw02.MarbleSolitaireModel;
import cs3500.marblesolitaire.view.MarbleSolitaireTextView;
import cs3500.marblesolitaire.view.MarbleSolitaireView;

import java.io.IOException;
import java.io.StringReader;
import java.util.Scanner;

/**
 * Class for MarbleSolitaireControllerImpl which implements MarbleSolitaireController.
 * Hold the objects and methods that are located in it.
 */
public class MarbleSolitaireControllerImpl implements MarbleSolitaireController {
  /**
   * MarbleSolitaireModel equals mSM.
   */
  private MarbleSolitaireModel mSM;

  /**
   * MarbleSolitaireView equals mSV.
   */
  private MarbleSolitaireView mSV;

  /**
   * Readable equals read.
   */
  private Readable read;
  int score;
  /**
   * int object startRow.
   */
  private int startRow;

  /**
   * int object endRow.
   */
  private int endRow;

  /**
   * int object startCol.
   */
  private int startCol;

  /**
   * int object endCol.
   */
  private int endCol;


  /**
   * MarbleSolitaireControllerImpl it takes in MarbleSolitaireModel, MarbleSolitaireView, and
   * Read.
   * Constructor for MarbleSolitaireControllerImpl.
   *
   * @param mSM  equals MarbleSolitaireModel
   * @param mSV  equals MarbleSolitaireView
   * @param read equals Readable
   * @throws IOException if there is an error in the input or output
   */
  public MarbleSolitaireControllerImpl(MarbleSolitaireModel mSM, MarbleSolitaireView mSV,
                                       Readable read) {
    if (mSM != null || mSV != null || read != null) {
      this.mSM = mSM;
      this.mSV = mSV;
      this.read = read;
    } else {
      throw new IllegalArgumentException("null");
    }
  }


  /**
   * There are two ways to end a game quite, to get gameOver or naturally end the game.
   * Method should play a game. It should "run" the game in the following sequence until
   * the game ends. (There are two ways to end a game quite get is gameOver)
   *
   * @throws IOException It should throw an IllegalStateException only if
   *                     the controller is unable to successfully read input or transmit output.
   */
  @Override
  public void playGame() throws IOException {
    Scanner scan = new Scanner(this.read);
    try {
      this.mSV.renderBoard();
      this.score = mSM.getScore();
      this.mSV.renderMessage("Score:" + this.score);
    } catch (IOException e) {
      throw new IllegalStateException(" Error ");
    }
    while (scan.hasNext()) {
      String x = scan.next();
      //System.out.print("is Game Over ");
      System.out.println(this.mSM.isGameOver());
      if ((x.equalsIgnoreCase("Q") || this.mSM.isGameOver())) {
        try {
          this.mSV.renderMessage("Game over!");
          this.mSV.renderBoard();
          this.mSV.renderMessage("Score:" + mSM.getScore());
          break;
        } catch (IOException e) {
          throw new IllegalStateException(" Error ");
        }
      } else if (x.matches("[1-9]")) {
        this.startRow = Integer.parseInt(x);
        this.startCol = Integer.parseInt(x);
        this.endRow = Integer.parseInt(x);
        this.endCol = Integer.parseInt(x);
        try {
          this.mSM.move(this.startRow, this.startCol, this.endRow, this.endCol);
          System.out.print("move");
        } catch (Exception e) {
          System.out.print("Invalid move. Play again X");
        }
      }
      try {
        this.mSV.renderBoard();
        this.score = mSM.getScore();
        this.mSV.renderMessage("Score:" + this.score);
      } catch (IOException e) {
        throw new IllegalStateException(" Error ");
      }
    }
  }


  /**
   * This is an array list  method that is used to test for errors in the controller.
   * @param args is what the string array list is called
   * @throws IOException if there is an error in the input of output
   */
  public static void main(String[] args) throws IOException {
    EnglishSolitaireModel model1 = new EnglishSolitaireModel();
    MarbleSolitaireTextView view1 = new MarbleSolitaireTextView(model1);
    StringReader reader1 = new StringReader("3 1 3 3");
    MarbleSolitaireControllerImpl controller1
            = new MarbleSolitaireControllerImpl(model1, view1, reader1);
    controller1.playGame();

  }
}