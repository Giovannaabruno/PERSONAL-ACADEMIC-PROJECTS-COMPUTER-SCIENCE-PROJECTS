package cs3500.marblesolitaire.model;


import java.io.IOException;
import java.io.StringReader;

import cs3500.marblesolitaire.controller.MarbleSolitaireControllerImpl;
import cs3500.marblesolitaire.model.hw02.EnglishSolitaireModel;
import cs3500.marblesolitaire.model.hw02.MarbleSolitaireModel;
import cs3500.marblesolitaire.model.hw04.EuropeanSolitaireModel;
import cs3500.marblesolitaire.model.hw04.TriangleSolitaireModel;
import cs3500.marblesolitaire.view.MarbleSolitaireTextView;


/**
 * Class for MarbleSolitaire.
 */
public final class MarbleSolitaire {
  /**
   * the constructor for MarbleSolitaire, it creates the working game boards, creates
   * multiple controllers.
   *
   * @param args represents the number of arguments.
   * @throws IOException if there is an error in the output or the input
   */
  public static void main(String[] args) throws IOException {
    String boardType = args[0];
    Integer size = null;
    Integer r = null;
    Integer c = null;

    for (int i = 0; i < args.length; i++) {
      if (args[i].equals("-size")) {
        size = Integer.parseInt(args[i + 1]);

      } else if (args[i].equals("-hole")) {
        r = Integer.parseInt(args[i + 1]);
        c = Integer.parseInt(args[i + 2]);
      }

    }
    MarbleSolitaireModel board = null;
    if (boardType.equals("english")) {
      if (size != null && r != null && c != null) {
        board = new EnglishSolitaireModel(size, r, c);
      } else if (size != null) {
        board = new EnglishSolitaireModel(size);

      } else if (r != null && c != null) {
        board = new EnglishSolitaireModel(r, c);


      } else {
        board = new EnglishSolitaireModel();
      }

    }
    if (boardType.equals("european")) {
      if (size != null && r != null && c != null) {
        board = new EuropeanSolitaireModel(size, r, c);
      } else if (size != null) {
        board = new EuropeanSolitaireModel(size);

      } else if (r != null && c != null) {
        board = new EuropeanSolitaireModel(r, c);
      } else {
        board = new EuropeanSolitaireModel();
      }
    }
    if (boardType.equals("triangular")) {
      if (size != null && r != null && c != null) {
        board = new TriangleSolitaireModel(size, r, c);
      } else if (size != null) {
        board = new TriangleSolitaireModel(size);

      } else if (r != null && c != null) {
        board = new TriangleSolitaireModel(r, c);

      } else {
        board = new TriangleSolitaireModel();
      }
    }

    MarbleSolitaireTextView view1 = new MarbleSolitaireTextView(board);
    StringReader reader1 = new StringReader("2 4 4 4");
    MarbleSolitaireControllerImpl controller1
            = new MarbleSolitaireControllerImpl(board, view1, reader1);
    controller1.playGame();


  }


}

