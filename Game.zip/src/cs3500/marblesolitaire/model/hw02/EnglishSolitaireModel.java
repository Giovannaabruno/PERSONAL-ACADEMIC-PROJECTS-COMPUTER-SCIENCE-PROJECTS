package cs3500.marblesolitaire.model.hw02;

/**
 * Creating the class EnglishSolitaireModel and its constructor.
 */
public class EnglishSolitaireModel implements MarbleSolitaireModel {

  /**
   * int object equals armThickness.
   */
  private int armThickness;

  /**
   * Array list SlotState for game board.
   */
  private SlotState[][] gameBoard;

  /**
   * int object for emptyRow.
   */
  private int emptyRow;
  /**
   * int object emptyColumn.
   */
  private int emptyColumn;


  /**
   * int object for score.
   */
  private int score;


  /**
   * EnglishSolitaireModel and its constructor creates the characteristics of the game board.
   * If it doesn't follow then the characteristics it throws a IllegalArgumentException.
   * It is not a positive odd number, or the empty cell position it is invalid.
   *
   * @param armThickness represents the amount the number calculated to find the amount of sections
   *                     on a game board.
   * @param row          represents the number of rows in the game board.
   * @param column       represents the number of column in the game board.
   */
  public EnglishSolitaireModel(int armThickness, int row, int column) {
    if (armThickness > 0 && armThickness % 2 == 1) {
      this.armThickness = armThickness;
      this.emptyRow = row / 2;
      this.emptyColumn = column / 2;
      this.score = 0;
      int length = armThickness * 2 + 1;
      this.gameBoard = new SlotState[length][length];
      int start = (armThickness - (armThickness / 2));
      int end = (armThickness + (armThickness / 2));
      for (int r = 0; r < length; r++) {
        for (int c = 0; c < length; c++) {
          if ((r < start && c < start) || (r > end && c < start) || (r < start && c > end)
                  || (r > end && c > end)) {
            gameBoard[r][c] = SlotState.Invalid;

          } else {
            gameBoard[r][c] = SlotState.Marble;
            this.score++;

          }


        }
      }

      gameBoard[emptyRow][emptyColumn] = SlotState.Empty;

    } else {
      throw new IllegalArgumentException(" Needs to be corrected ");


    }

  }

  /**
   * Methode for creating the set amount for the game board,
   * armThickness, row, column.
   */
  public EnglishSolitaireModel() {
    this(3, 3, 3);

  }

  /**
   * Methode for creating the game board,
   * specifically the objects row and column on the board. If it fails it throws a
   * IllegalArgumentException.
   *
   * @param row    is the int that represents the amount of horizontal sections on the game board.
   * @param column is the int that represents the amount of horizontal sections on the game board.
   */
  public EnglishSolitaireModel(int row, int column) {
    this.armThickness = 3;
    this.emptyRow = row;
    this.emptyColumn = column;
    this.score = 0;
    int length = armThickness * 2 + 1;
    this.gameBoard = new SlotState[length][length];
    int start = (armThickness - (armThickness / 2));
    int end = (armThickness + (armThickness / 2));
    for (int r = 0; r < length; r++) {
      for (int c = 0; c < length; c++) {
        if ((r < start && c < start) || (r > end && c < start) || (r < start && c > end)
                || (r > end && c > end)) {
          gameBoard[r][c] = SlotState.Invalid;

        } else {
          gameBoard[r][c] = SlotState.Marble;
          this.score++;

        }


      }


      gameBoard[emptyRow][emptyColumn] = SlotState.Empty;

    }
  }

  /**
   * Methode for creating the game board,
   * specifically armThickness on the board.
   *
   * @param armThickness represents the number used in the self-made
   *                     calculation to find the amount of sections on a game board.
   */
  public EnglishSolitaireModel(int armThickness) {
    this(armThickness, armThickness * 2 + 1, armThickness * 2 + 1);
  }

  /**
   * Getter method to find the data field for armThickness.
   *
   * @return armThickness.
   */
  public int getArmThickness() {
    return this.armThickness;
  }


  /**
   * Getter method to find the data field for EmptyRow.
   *
   * @return EmptyRow.
   */
  public int getEmptyRow() {
    return this.emptyRow;
  }

  /**
   * Getter method to find the data field for EmptyColumn.
   *
   * @return EmptyColumn for getter.
   */
  public int getEmptyColumn() {
    return this.emptyColumn;
  }

  /**
   * getter for BoardSize.
   *
   * @return 0
   */
  @Override
  public int getBoardSize() {
    return armThickness * 2 + 1;
  }

  /**
   * Getter for method for getSlotAt.
   *
   * @param row the row of the position sought, starting at 0.
   * @param col the column of the position sought, starting at 0.
   * @return null or the slot for row and col
   * @throws IllegalArgumentException if it is in correct
   */
  @Override
  public SlotState getSlotAt(int row, int col) throws IllegalArgumentException {
    return getGameBoard()[row][col];
  }

  /**
   * Getter method to find the data field for Score.
   *
   * @return Score for getter.
   */
  public int getScore() {
    return this.score;
  }


  /**
   * Getter method to find the data field for GameBoard.
   *
   * @return GameBoard for getter.
   */
  public SlotState[][] getGameBoard() {
    return this.gameBoard;
  }


  /**
   * Methode for main has a string array list.
   *
   * @param args represents the array list
   */
  public static void main(String[] args) {
    System.out.print(new EnglishSolitaireModel(-4, 6, 6).getScore());
  }


  /**
   * Setter for boolean method to take action for the data field of gameBoard.
   *
   * @param gameBoard sets the amount of game pieces
   * @return set gameBoard
   */
  public boolean setGameBoard(SlotState[][] gameBoard) {
    this.gameBoard = gameBoard;
    return true;


  }


  /**
   * Methode allows player to move the game pieces forward and backwards
   * and backwards and forwards. The "from" and "to" positions are valid. There is
   * a marble at the specified "from" position. The "to" position is empty. The "to" and
   * "from" positions are exactly two positions away (horizontally or vertically). There is a
   * marble in the slot between the "to" and "from" positions. One is then able to move thr marble.
   * If not it will throw IllegalArgumentException. Overall, with the uses of helper methods helps
   * clarify if a move is valid or not.
   *
   * @param startX the starting spot for rows.
   * @param startY the starting spot for columns.
   * @param endX   the ending spot for rows.
   * @param endY   the ending spot for columns.
   */
  public void move(int startX, int startY, int endX, int endY) {
    if (validHelper(startX, startY, endX, endY)) {
      gameBoard[startX][startY] = SlotState.Empty;
      gameBoard[middleXHelper(startX, startY, endX, endY)]
              [middleYHelper(startX, startY, endX, endY)] = SlotState.Empty;
      gameBoard[endX][endY] = SlotState.Marble;
      this.score--;

    } else {
      throw new IllegalArgumentException("Unset");
    }
  }

  /**
   * MoveHelper Methode to help support the mover methode.
   *
   * @param x int for rows
   * @param y int for columns
   * @return true if the position is Marble or is empty
   */
  // turn back
  public boolean moveHelper(int x, int y) {
    boolean result = (getGameBoard()[x][y] == SlotState.Marble
            || getGameBoard()[x][y] == SlotState.Empty);
    return result;


  }

  /**
   * Boolean helper Methode for the ValidHelper in which detect if it rows and columns
   * will be valid to have marble. if not then its false.
   *
   * @param startX the starting spot for rows.
   * @param startY the starting spot for column.
   * @param endX   the ending spot of for row.
   * @param endY   the ending spot for column.
   * @return true or false boolean values.
   */
  public boolean startEndHelper(int startX, int startY, int endX, int endY) {
    return (startX == endX && gameBoard[startX][startY + 1] == SlotState.Marble
            || (startY == endY && gameBoard[startX + 1][startY] == SlotState.Marble));


  }


  /**
   * Boolean helper Methode for the ValidHelper to detect if the space is clear to play.
   *
   * @param startX the starting spot for rows.
   * @param startY the starting spot for columns.
   * @param endX   the ending spot for the rows.
   * @param endY   the ending spot for the columns.
   * @return boolean function uses to detect if the game move is valid to take action to.
   */
  public boolean detectHelper(int startX, int startY, int endX, int endY) {
    return ((startX == (endX) && Math.abs(startY - endY) == 2)
            || (startY == endY && Math.abs(startX - endX) == 2));


  }


  /**
   * This helper methode is used to detect if the middle marble between and in row is
   * filled marble chosen
   * and the empty "the player" is planning on moving to have a marble game piece in the middle.
   *
   * @param startX the starting spot for rows
   * @param startY the starting spot for column
   * @param endX   the ending spot for rows
   * @param endY   the ending spot for column
   * @return an int value which determines if there will be a marble in the middle or not in row.
   */
  public int middleXHelper(int startX, int startY, int endX, int endY) {
    if (startX == endX && gameBoard[endX][endY + 1] == SlotState.Marble) {
      return endX;

    } else if (startY == endY && gameBoard[endX + 1][endY] == SlotState.Marble) {
      return endX + 1;
    } else {
      return 0;
    }

  }

  /**
   * This helper methode is used to detect if the middle marble between and in column is
   * filled marble chosen
   * and the empty "the player" is planning on moving to have a marble game piece in the middle.
   *
   * @param startX the starting spot for rows.
   * @param startY the starting spot for column.
   * @param endX   the ending spot for rows.
   * @param endY   the ending spot for column.
   * @return an int value which determines if there will be a marble in the middle or not
   *     in columns
   */
  public int middleYHelper(int startX, int startY, int endX, int endY) {
    if (startX == (endX) && gameBoard[endX][endY + 1] == SlotState.Marble) {
      return endY + 1;

    } else if (startY == (endY) && gameBoard[endX + 1][endY] == SlotState.Marble) {
      return endY;
    } else {
      return 0;
    }

  }


  /**
   * Boolean methode for isGameOver detects if there is anymore moves to play. It will
   * keep going until there are no more pieces left to play.
   *
   * @return boolean respond of after playing rounds of the move see if there still valid
   *     moves to keep going
   */
  public boolean isGameOver() {
    int start = (armThickness - (armThickness / 2));
    int end = (armThickness + (armThickness / 2));
    int length = armThickness * 2 + 1;
    for (int r = 0; r < length; r++) {
      for (int c = 0; c < length; c++) {
        // it only checking invalied spots, and look at spots that not a marble
        if ((r < start && c < start) || (r > end && c < start) || (r < start && c > end)
                || (r > end && c > end)) {
          if ((validHelper(r, c, (r + 2), c)) || (validHelper(r, c, (r - 2), c))
                  || (validHelper(r, c, r, (c + 2))) || (validHelper(r, c, r, (c - 2)))) {
            return true;


          }


        }
      }

    }
    return false;


  }


  /**
   * Helper methode used to see if the move is valid by checking the fill marble spots and empty
   * spots.
   *
   * @param startX the starting spot for rows
   * @param startY the starting spot for columns
   * @param endX   the endings spot for rows
   * @param endY   the endings spot for columns
   * @return boolean methode will find if the space on the game board is valid to make a move
   *     Rather true or false
   */
  public boolean validHelper(int startX, int startY, int endX, int endY) {
    return (moveHelper(startX, startY) && moveHelper(endX, endY)
            && gameBoard[startX][startY] == SlotState.Marble
            && gameBoard[endX][endY] == SlotState.Empty
            && startEndHelper(startX, startY, endX, endY)
            && detectHelper(startX, startY, endX, endY));


  }
}








