package cs3500.marblesolitaire.model.hw04;


/**
 * Class for EuropeanSolitaireModel (creates an octagonal)
 * which indirectly implements the MarbleSolitaireModel interface.
 */

public class EuropeanSolitaireModel extends MarbleSolitaireTwo {
  private int sideLength;
  private int row;
  private int col;

  /**
   * Default constructor (no parameters) that creates an octagonal
   * board whose sides have length 3,
   * with the empty slot in the center of the board.
   */
  public EuropeanSolitaireModel() {
    this(3, 3, 3);

  }

  /**
   * A constructor with a single parameter (the side length) that creates a game
   * with the specified side length, and the empty slot in the center of the board.
   *
   * @param sideLength is the "armThickness" of the octagonal board.
   */
  public EuropeanSolitaireModel(int sideLength) {
    this(sideLength, sideLength, sideLength);

  }

  /**
   * A constructor with two parameters (row, col), to specify the
   * initial position of the empty slot, in a board of default size 3.
   *
   * @param row is the rows of the game board
   * @param col is the columns of the game board
   */
  public EuropeanSolitaireModel(int row, int col) {
    this(3, row, col);


  }

  /**
   * A constructor with three parameters (side length, row, col), to specify
   * the size of the board and the initial position of the empty slot.
   *
   * @param sideLength equals sideLength in the octagonal board
   * @param row        equals row in the octagonal board
   * @param col        equals col in the octagonal board
   */
  public EuropeanSolitaireModel(int sideLength, int row, int col) {
    super(sideLength, row, col);

  }


  /**
   * method for creating the specific shape of the pieces on the game board.
   */
  @Override
  public void fillBoard() {
    gameBoard = new SlotState[getBoardSize()][getBoardSize()];
    for (int r = 0; r < gameBoard.length; r++) {
      for (int c = 0; c < gameBoard[r].length; c++) {
        gameBoard[r][c] = SlotState.Invalid;

      }
    }
    for (int r = 0; r < gameBoard.length; r++) {
      int emptyBefore = 0;
      if (r == 0 || r == gameBoard.length - 1) {
        emptyBefore = (gameBoard.length - armThickness) / 2;
      } else if (r == 1 || r == gameBoard.length - 2) {
        emptyBefore = (gameBoard.length - armThickness) / 2 - 1;
      }
      for (int c = emptyBefore; c < gameBoard.length - emptyBefore; c++) {
        gameBoard[r][c] = SlotState.Marble;


      }

    }
    gameBoard[emptyRow][emptyColumn] = SlotState.Empty;

  }

  /**
   *  getter method for SideLength, get the object sid length.
   * @return the object sideLength
   */
  public int getSideLength() {
    return this.sideLength;
  }

  /**
   * Getter method to find the data field for EmptyRow.
   * @return the object EmptyRow
   */
   public int getEmptyRow() {
    return this.emptyRow;
  }

  /**
   * Getter method to find the data field for EmptyColumn.
   *
   * @return EmptyColumn for getter.
   */
  public int getEmptyColumn() {
    return this.emptyColumn;
  }

}
