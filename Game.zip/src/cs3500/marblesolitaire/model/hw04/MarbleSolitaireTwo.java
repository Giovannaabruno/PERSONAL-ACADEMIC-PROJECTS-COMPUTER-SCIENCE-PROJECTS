package cs3500.marblesolitaire.model.hw04;

import cs3500.marblesolitaire.model.hw02.MarbleSolitaireModel;

/**
 * Will be used an abstract class that will implement MarbleSolitaireModel,
 * by doing this it creates an indirect implement for TriangleSolitaireModel and
 * EuropeanSolitaireModel to  MarbleSolitaireModel. It will contain what they have in common.
 */
public abstract class MarbleSolitaireTwo implements MarbleSolitaireModel {

  /**
   * int object equals armThickness.
   */
  protected int armThickness;

  /**
   * Array list SlotState for game board.
   */
  protected SlotState[][] gameBoard;

  /**
   * int object for emptyRow.
   */
  protected int emptyRow;
  /**
   * int object emptyColumn.
   */
  protected int emptyColumn;


  /**
   * int object for score.
   */
  private int score;


  /**
   * contractor for MarbleSolitaireTwo, takes in used objects armThickness, emptyRow,
   * emptyColumn.
   *
   * @param armThickness equals armThickness of the game-board
   * @param row          equals row of the game-board
   * @param column       equals column of the game-board
   */
  public MarbleSolitaireTwo(int armThickness, int row, int column) {
    if (armThickness > 0 && armThickness % 2 == 1) {
      this.armThickness = armThickness;
      this.emptyRow = row;
      this.emptyColumn = column;
      this.score = 0;
      fillBoard();
      gameBoard[emptyRow][emptyColumn] = SlotState.Empty;

    } else {
      throw new IllegalArgumentException(" Needs to be corrected ");
    }
  }

  /**
   * Methode allows player to move the game pieces forward and backwards
   * and backwards and forwards. The "from" and "to" positions are valid. There is
   * a marble at the specified "from" position. The "to" position is empty. The "to" and
   * "from" positions are exactly two positions away (horizontally or vertically). There is a
   * marble in the slot between the "to" and "from" positions. One is then able to move thr marble.
   * If not it will throw IllegalArgumentException. Overall, with the uses of helper methods helps
   * clarify if a move is valid or not.
   *
   * @param fromRow the row number of the position to be moved from
   *                (starts at 0).
   * @param fromCol the column number of the position to be moved from
   *                (starts at 0).
   * @param toRow   the row number of the position to be moved to
   *                (starts at 0).
   * @param toCol   the column number of the position to be moved to
   *                (starts at 0).
   * @throws IllegalArgumentException if it is an invalid move
   */
  @Override
  public void move(int fromRow, int fromCol, int toRow, int toCol) throws
          IllegalArgumentException {
    if (validHelper(fromRow, fromCol, toRow, toCol)) {
      gameBoard[fromRow][fromCol] = SlotState.Empty;
      gameBoard[middleXHelper(fromRow, fromCol, toRow, toCol)]
              [middleYHelper(fromRow, fromCol, toRow, toCol)] = SlotState.Empty;
      gameBoard[toRow][toCol] = SlotState.Marble;
      this.score--;

    } else {
      throw new IllegalArgumentException("Unset");
    }
  }


  /**
   * Boolean method for determines if the is game over, by pressing Q for quite
   * or player runs out of valid plays.
   *
   * @return false, activates "GameOver"
   */
  @Override
  public boolean isGameOver() {
    int start = (armThickness - (armThickness / 2));
    int end = (armThickness + (armThickness / 2));
    int length = armThickness * 2 + 1;
    for (int r = 0; r < length; r++) {
      for (int c = 0; c < length; c++) {
        // it only checking invalied spots, and look at spots that not a marble
        if ((r < start && c < start) || (r > end && c < start) || (r < start && c > end)
                || (r > end && c > end)) {
          if ((validHelper(r, c, (r + 2), c)) || (validHelper(r, c, (r - 2), c))
                  || (validHelper(r, c, r, (c + 2))) || (validHelper(r, c, r, (c - 2)))) {
            return true;


          }


        }
      }

    }
    return false;
  }

  /**
   * Getter method for creating the board size.
   *
   * @return calculation of the BoardSize, will return 7.
   */
  @Override
  public int getBoardSize() {
    return armThickness * 2 + 1;

  }

  /**
   * Getter for the SlotState Array method.
   *
   * @param row the row of the position sought, starting at 0.
   * @param col the column of the position sought, starting at 0.
   * @return null
   * @throws IllegalArgumentException if SlotState is formatted invalidly
   */
  @Override
  public SlotState getSlotAt(int row, int col) throws IllegalArgumentException {
    return getGameBoard()[row][col];
  }

  /**
   * Setter for SlotAt.
   * @param row equals row of the board
   * @param col equals columns of the board
   * @param piece the pieces of the board using 2D array of row and column
   */
  public void setSlotAt(int row, int col, SlotState piece) {
    getGameBoard()[row][col] = piece;
  }

  /**
   * Method for getting the Score of the game.
   *
   * @return the score object of the game
   */
  @Override
  public int getScore() {
    return this.score;

  }

  /**
   * Creating the public method for fillBoard, will creat the object in the board.
   */
  public abstract void fillBoard();


  /**
   * MoveHelper Methode to help support the mover methode.
   *
   * @param x int for rows
   * @param y int for columns
   * @return true if the position is Marble or is empty
   */
  // turn back
  public boolean moveHelper(int x, int y) {
    boolean result = (getGameBoard()[x][y] == SlotState.Marble
            || getGameBoard()[x][y] == SlotState.Empty);
    return result;


  }

  public SlotState[][] getGameBoard() {
    return gameBoard;
  }


  /**
   * Boolean helper Methode for the ValidHelper in which detect if it rows and columns
   * will be valid to have marble. if not then its false.
   *
   * @param startX the starting spot for rows.
   * @param startY the starting spot for column.
   * @param endX   the ending spot of for row.
   * @param endY   the ending spot for column.
   * @return true or false boolean values.
   */
  public boolean startEndHelper(int startX, int startY, int endX, int endY) {
    return (startX == endX && gameBoard[startX][startY + 1] == SlotState.Marble
            || (startY == endY && gameBoard[startX + 1][startY] == SlotState.Marble));


  }


  /**
   * Boolean helper Methode for the ValidHelper to detect if the space is clear to play.
   *
   * @param startX the starting spot for rows.
   * @param startY the starting spot for columns.
   * @param endX   the ending spot for the rows.
   * @param endY   the ending spot for the columns.
   * @return boolean function uses to detect if the game move is valid to take action to.
   */
  public boolean detectHelper(int startX, int startY, int endX, int endY) {
    return ((startX == (endX) && Math.abs(startY - endY) == 2)
            || (startY == endY && Math.abs(startX - endX) == 2));


  }


  /**
   * This helper methode is used to detect if the middle marble between and in row is
   * filled marble chosen
   * and the empty "the player" is planning on moving to have a marble game piece in the middle.
   *
   * @param startX the starting spot for rows
   * @param startY the starting spot for column
   * @param endX   the ending spot for rows
   * @param endY   the ending spot for column
   * @return an int value which determines if there will be a marble in the middle or not in row.
   */
  public int middleXHelper(int startX, int startY, int endX, int endY) {
    if (startX == endX && gameBoard[endX][endY + 1] == SlotState.Marble) {
      return endX;

    } else if (startY == endY && gameBoard[endX + 1][endY] == SlotState.Marble) {
      return endX + 1;
    } else {
      return 0;
    }

  }

  /**
   * This helper methode is used to detect if the middle marble between and in column is
   * filled marble chosen
   *     and the empty "the player" is planning on moving to have a marble game piece in the middle.
   *
   * @param startX the starting spot for rows.
   * @param startY the starting spot for column.
   * @param endX   the ending spot for rows.
   * @param endY   the ending spot for column.
   * @return an int value which determines if there will be a marble in the middle or not
   *     in columns
   */
  public int middleYHelper(int startX, int startY, int endX, int endY) {
    if (startX == (endX) && gameBoard[endX][endY + 1] == SlotState.Marble) {
      return endY + 1;

    } else if (startY == (endY) && gameBoard[endX + 1][endY] == SlotState.Marble) {
      return endY;
    } else {
      return 0;
    }

  }


  /**
   * Helper methode used to see if the move is valid by checking the fill marble spots and empty
   * spots.
   *
   * @param startX the starting spot for rows
   * @param startY the starting spot for columns
   * @param endX   the endings spot for rows
   * @param endY   the endings spot for columns
   * @return boolean methode will find if the space on the game board is valid to make a move
   *     Rather true or false
   */
  public boolean validHelper(int startX, int startY, int endX, int endY) {
    return (moveHelper(startX, startY) && moveHelper(endX, endY)
            && gameBoard[startX][startY] == SlotState.Marble
            && gameBoard[endX][endY] == SlotState.Empty
            && startEndHelper(startX, startY, endX, endY)
            && detectHelper(startX, startY, endX, endY));


  }
}
