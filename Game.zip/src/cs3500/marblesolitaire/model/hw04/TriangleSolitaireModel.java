package cs3500.marblesolitaire.model.hw04;

import cs3500.marblesolitaire.model.hw04.MarbleSolitaireTwo;

/**
 * Class for TriangleSolitaireModel (creates a triangle game-board)
 * which indirectly implements the MarbleSolitaireModel interface.
 */
public class TriangleSolitaireModel extends MarbleSolitaireTwo {
  private int dimensions;
  private int row;
  private int col;

  /**
   * A default constructor (no parameters)
   * that creates a 5-row game with the empty slot at (0,0).
   */
  public TriangleSolitaireModel() {
    this(5, 0, 0);

  }

  /**
   * A constructor with a single parameter (dimensions) that creates a game with the specified
   * dimension (number of slots in the bottom-most row) and the empty slot at (0,0).
   * This constructor should throw the IllegalArgumentException exception if the specified
   *     dimension is invalid (non-positive).
   *
   * @param dimensions equal the dimensions on the game-board
   * @throws IllegalArgumentException if the specified dimension is  invalid
   */
  public TriangleSolitaireModel(int dimensions) throws IllegalArgumentException {
    this(dimensions, 0, 0);
    if (dimensions <= 0) {
      throw new IllegalArgumentException(" Can't have non-positive ");

    }


  }

  /**
   * A constructor with two parameters (row,col) that creates a 5-row game with the
   * empty slot at the specified position. This constructor should throw the
   * IllegalArgumentException exception if the specified position is invalid.
   *
   * @param row equals the rows in the game board
   * @param col equals the columns in the game board
   * @throws IllegalArgumentException if the position on the game board is invalid
   */
  public TriangleSolitaireModel(int row, int col) throws IllegalArgumentException {
    this(5, row, col);
    if (row < 0 || col < 0 || row > 4 || col > 4 || col > row) {
      throw new IllegalArgumentException(" specified position is invalid ");


    }


  }

  /**
   * A constructor with three parameters (dimensions,row,col) that creates a game
   * with the specified dimension and an empty slot at the specified row and column.
   * This constructor should throw the IllegalArgumentException exception.
   *
   * @param dimensions equals the dimensions in the game board
   * @param row        equals rows in the game board
   * @param col        equals columns in the game board
   * @throws IllegalArgumentException if the specified dimension
   *     is invalid (non-positive) or the specified position is invalid.
   */
  public TriangleSolitaireModel(int dimensions, int row, int col) throws IllegalArgumentException {
    super(dimensions, row, col);
    if (row < 0 || col < 0 || row >= dimensions || col >= dimensions || col > row) {
      throw new IllegalArgumentException(" specified dimension is invalid (non-positive) "
              + "or the specified position is invalid. ");
    }


  }


  /**
   * Method for creating the specific shape of the pieces on the game board.
   */
  @Override
  public void fillBoard() {
    gameBoard = new SlotState[armThickness][armThickness];
    for (int r = 0; r < gameBoard.length; r++) {
      gameBoard[r] = new SlotState[r + 1];
      for (int c = 0; c < gameBoard[r].length; c++) {
        gameBoard[r][c] = SlotState.Marble;

      }

    }
    gameBoard[emptyRow][emptyColumn] = SlotState.Empty;
  }

  /**
   * Getter for the Dimensions of the triangle game board.
   * @return the object dimensions
   */
  public int getDimensions() {
    return this.dimensions;
  }

  /**
   * Create a move method for triangle game board.
   * Methode allows player to move the game pieces forward, backwards and across.
   *    * and backwards and forwards.
   * @param fromRow the row number of the position to be moved from
   *                (starts at 0).
   * @param fromCol the column number of the position to be moved from
   *                (starts at 0).
   * @param toRow   the row number of the position to be moved to
   *                (starts at 0).
   * @param toCol   the column number of the position to be moved to
   *                (starts at 0).
   * @throws IllegalArgumentException if the move is invalid
   */
  public void move(int fromRow, int fromCol, int toRow, int toCol) throws
          IllegalArgumentException {
    if (getSlotAt(fromRow,fromCol) == SlotState.Marble && getSlotAt(toRow,toCol) == SlotState.Empty
            && isValidMove(fromRow, fromCol, toRow, toCol)) {
      setSlotAt(fromRow, fromCol,SlotState.Empty);
      setSlotAt((fromRow + toRow) / 2, (fromCol + toCol) / 2, SlotState.Empty);
      setSlotAt(toRow, toCol,SlotState.Marble);
    }
  }

  /**
   * isValidMove is a method that is used to detect if the fallowing types of moves are invalid.
   * @param startX equals the start piece for row
   * @param startY equals the start piece for column
   * @param endX equals the end piece for column
   * @param endY equals the start piece for column
   * @return boolean variables rather true or false
   */
  public boolean isValidMove(int startX, int startY, int endX, int endY) {
    if (startY < 0 || startY  > getDimensions() - 1 || startX < 0 || startX > startY ) {
      return false;
    }
    if (endY < 0 || endY  > getDimensions() - 1 || endX < 0 || endX > endY ) {
      return false;
    }
    int deltaX = Math.abs(endX - startX);
    int deltaY = Math.abs(endY - startY);
    if ( (deltaX == 0 || deltaX == 2) && (deltaY == 0 || deltaY == 2)) {
      if (deltaX == 0 && deltaY == 0 ) {
        return false;
      }
    }
    else {
      return false;
    }
    int middleX = (startX + endX) / 2;
    int middleY = (startY + endY) / 2;

    if (getSlotAt(middleX, middleY ) == SlotState.Marble) {
      return true;
    }
    return false;



  }
}