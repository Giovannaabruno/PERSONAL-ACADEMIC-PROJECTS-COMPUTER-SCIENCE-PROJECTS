package cs3500.marblesolitaire.view;

import java.io.IOException;



import cs3500.marblesolitaire.model.hw02.MarbleSolitaireModelState;


/**
 * Class MarbleSolitaireTextView implemented with its constructor
 * into the main MarbleSolitaireView class.
 */
public class MarbleSolitaireTextView implements MarbleSolitaireView {


  /**
   * MarbleSolitaireModelState equals mState.
   */
  private MarbleSolitaireModelState mState;

  // maybe take out
  /**
   * Appendable equals append.
   */
  private Appendable append;


  // making a constructor that makes it not allowed to pass null arguments

  /**
   * Constructor for MarbleSolitaireTextView takes in param MarbleSolitaireModelState and
   * Appendable. If false throw an IllegalArgumentException "null".
   * @param mState equals MarbleSolitaireModelState
   * @param append equals Appendable
   */
  public MarbleSolitaireTextView(MarbleSolitaireModelState mState, Appendable append) {
    if (mState != null || append != null) {
      this.mState = mState;
      this.append = append;
    } else {
      throw new IllegalArgumentException("null");
    }
  }




  /**
   *  Argument method which will call the object game which will provide the view of all the methods
   *  it has and needs to query the model and print the board game to create it.
   *  If it does not show it will have an illegal argument.
    * @param mState represents MarbleSolitaireModelState
   */
  public MarbleSolitaireTextView(MarbleSolitaireModelState mState) {
    //used to say game
    if (mState != null) {
      this.mState = mState;
      this.append = System.out;
    } else {
      throw new IllegalArgumentException("null");
    }


  }

  /**
   * Rewrite the code to mState instead of game.
   * String Method us to create or illiterate the symbolizes on the bored, and its arrangements.
   * add the model state to the constructor
   * @return String which may be used to print the board.
   */
  public String toString() {
    StringBuilder s = new StringBuilder("");
    for (int r = 0; r < mState.getBoardSize(); r++) {
      for (int c = 0; c <  mState.getBoardSize(); c++) {
        if ( mState.getSlotAt(r,c) == MarbleSolitaireModelState.SlotState.Empty) {
          s.append("_");
        } else if ( mState.getSlotAt(r,c) == MarbleSolitaireModelState.SlotState.Marble) {
          s.append( "0");
        } else if ( mState.getSlotAt(r,c) == MarbleSolitaireModelState.SlotState.Invalid) {
          s.append(" ");

        } else {
          break;
        }


      }
      s.append("\n");

    }
    return s.toString();
  }

  /**
   * Methode which transmits the state of the marble solitaire board to a specified destination.
   * Sends the toString in to the desired output. redder the bord.
   * @throws IOException error that happens while transmitting the input or output for renderBoard
   */
  @Override
  public void renderBoard() throws IOException {
    this.append.append(this.toString());

  }

  /**
   * Method used to show an arbitrary message by allowing this view to show messages determined
   * by whoever uses it.
   *
   * @param message the message to be transmitted
   * @throws IOException error that happens while transmitting the input or output.
   */
  @Override
  public void renderMessage(String message) throws IOException {
    this.append.append(message + "\n");

  }


}


