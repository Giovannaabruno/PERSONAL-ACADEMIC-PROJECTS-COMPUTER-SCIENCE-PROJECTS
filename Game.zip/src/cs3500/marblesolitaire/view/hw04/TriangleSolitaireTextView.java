package cs3500.marblesolitaire.view.hw04;

import java.io.IOException;


import cs3500.marblesolitaire.view.MarbleSolitaireView;

/**
 * class for TriangleSolitaireTextView implements MarbleSolitaireView
 */
public class TriangleSolitaireTextView implements MarbleSolitaireView {
  private Appendable append;


  /**
   * Methode which transmits the state of the marble solitaire board to a specified destination.
   * Sends the toString in to the desired output. redder the bord.
   * @throws IOException error that happens while transmitting the input or output for renderBoard
   */
  @Override
  public void renderBoard() throws IOException {
    this.renderBoard();

  }

  /**
   * Method used to show an arbitrary message by allowing this view to show messages determined.
   * by whoever uses it.
   * @param message the message to be transmitted
   * @throws IOException error that happens while transmitting the input or output.
   */
  @Override
  public void renderMessage(String message) throws IOException {
    this.renderMessage(message);

  }
}
