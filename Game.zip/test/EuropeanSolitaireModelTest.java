import org.junit.Before;
import org.junit.Test;

import cs3500.marblesolitaire.model.hw02.EnglishSolitaireModel;
import cs3500.marblesolitaire.model.hw02.MarbleSolitaireModelState;
import cs3500.marblesolitaire.model.hw04.EuropeanSolitaireModel;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertThrows;
import static org.junit.Assert.assertTrue;

/**
 * Testing class for EuropeanSolitaireModelTest.
 */
public class EuropeanSolitaireModelTest {
  EuropeanSolitaireModel model1;
  EuropeanSolitaireModel model2;
  EuropeanSolitaireModel model3;
  EuropeanSolitaireModel model4;
  EuropeanSolitaireModel model5;


  /**
   * The 4 model scenarios that will be used for testers in EnglishSolitaireModel.
   *
   * @throws IllegalArgumentException represents four models, throws exception
   *                                  if the default does not catch.
   */
  @Before
  public void setUp() throws IllegalArgumentException {
    model1 = new EuropeanSolitaireModel();
    model2 = new EuropeanSolitaireModel(3, 5);
    model3 = new EuropeanSolitaireModel(3);
    model4 = new EuropeanSolitaireModel(-4, 6, 6);
    model5 = new EuropeanSolitaireModel(5, 3, 3);
  }

  /**
   * Testing the getter for armThickness, to call or get the int objects data filed to see if
   * the information is valid to the board in the EnglishSolitaireModel.
   */
  @Test
  public void getArmThickness() {
    assertEquals(3, model1.getSideLength());
    assertEquals(3, model2.getSideLength());
    assertEquals(3, model3.getSideLength());
    assertThrows(IllegalArgumentException.class, () -> model4.getSideLength());
    assertEquals(5, model5.getSideLength());
  }

  /**
   * Testing the getter for EmptyRow, to call or get the objects data filed to see if
   * information for row valid to the board in the EnglishSolitaireModel.
   */
  @Test
  public void getEmptyRow() {
    assertEquals(3, model1.getEmptyRow());
    assertEquals(3, model2.getEmptyRow());
    assertEquals(3, model3.getEmptyRow());
    assertThrows(IllegalArgumentException.class, () -> model4.getEmptyRow());
    assertEquals(3, model5.getEmptyRow());
  }

  /**
   * Testing the getter for EmptyColumn, to call or get the int objects data filed to see if
   * information for column is valid to the board in the EnglishSolitaireModel.
   */
  @Test
  public void getEmptyColumn() {
    assertEquals(3, model1.getEmptyColumn());
    assertEquals(5, model2.getEmptyColumn());
    assertEquals(3, model3.getEmptyColumn());
    assertThrows(IllegalArgumentException.class, () -> model4.getEmptyColumn());
    assertEquals(3, model5.getEmptyColumn());
  }

  /**
   * Testing the getter for Score to call or get the int objects data filed to see if
   * information for the Score is valid on the game board in the EnglishSolitaireModel.
   * Score is equivalent to the game board size.
   * as the number of marbles in the top row or bottom row, or left or right columns.
   */
  @Test
  public void getScore() {
    assertEquals(32, model1.getScore());
    assertEquals(32, model2.getScore());
    assertEquals(32, model3.getScore());
    assertThrows(IllegalArgumentException.class, () -> model4.getScore());
    assertEquals(84, model5.getScore());

  }

  /**
   * Testing the getter for Score to call or get the boolean objects data filed to see if
   * information for the Score is valid on the EnglishSolitaireModel.
   */
  @Test
  public void getGameBoard() {


    MarbleSolitaireModelState.SlotState invalid = MarbleSolitaireModelState.SlotState.Invalid;
    MarbleSolitaireModelState.SlotState marble = MarbleSolitaireModelState.SlotState.Marble;
    MarbleSolitaireModelState.SlotState empty = MarbleSolitaireModelState.SlotState.Empty;
    int length = model1.getSideLength() * 2 + 1;
    MarbleSolitaireModelState.SlotState[][] playerGameBoard =
            new MarbleSolitaireModelState.SlotState[length][length];
    int start = (model1.getSideLength() - (model1.getSideLength() / 2));
    int end = (model1.getSideLength() + (model1.getSideLength() / 2));
    for (int r = 0; r <= length; r++) {
      for (int c = 0; c <= length; c++) {
        if ((r < start && c < start) || (r > end && c < start) || (r < start && c > end)
                || (r > end && c > end)) {

          playerGameBoard[r][c] = invalid;

        } else {

          playerGameBoard[r][c] = marble;

        }
      }

    }

    playerGameBoard[model1.getEmptyRow()][model1.getEmptyColumn()] = empty;


    int length2 = model2.getSideLength() * 2 + 1;
    MarbleSolitaireModelState.SlotState[][] player2GameBoard
            = new MarbleSolitaireModelState.SlotState[length2][length2];
    int start2 = (model2.getSideLength() - (model2.getSideLength() / 2));
    int end2 = (model2.getSideLength() + (model2.getSideLength() / 2));
    for (int r2 = 0; r2 <= length2; r2++) {
      for (int c2 = 0; c2 <= length2; c2++) {
        if ((r2 < start && c2 < start) || (r2 > end2 && c2 < start2) || (r2 < start2 && c2 > end2)
                || (r2 > end && c2 > end)) {

          playerGameBoard[r2][c2] = invalid;

        } else {

          player2GameBoard[r2][c2] = marble;

        }
      }

    }

    playerGameBoard[model2.getEmptyRow()][model2.getEmptyColumn()] = empty;

    //model3
    int length3 = model3.getSideLength() * 2 + 1;
    MarbleSolitaireModelState.SlotState[][] player3GameBoard =
            new MarbleSolitaireModelState.SlotState[length3][length3];
    int start3 = (model3.getSideLength() - (model3.getSideLength() / 2));
    int end3 = (model3.getSideLength() + (model3.getSideLength() / 2));
    for (int r3 = 0; r3 <= length3; r3++) {
      for (int c3 = 0; c3 <= length3; c3++) {
        if ((r3 < start && c3 < start) || (r3 > end3 && c3 < start3) || (r3 < start3 && c3 > end3)
                || (r3 > end && c3 > end)) {

          player3GameBoard[r3][c3] = invalid;

        } else {

          player3GameBoard[r3][c3] = marble;

        }
      }

    }

    player3GameBoard[model3.getEmptyRow()][model3.getEmptyColumn()] = empty;


    //model5
    int length5 = model5.getSideLength() * 2 + 1;
    MarbleSolitaireModelState.SlotState[][] player5GameBoard
            = new MarbleSolitaireModelState.SlotState[length5][length5];
    int start5 = (model5.getSideLength() - (model5.getSideLength() / 2));
    int end5 = (model5.getSideLength() + (model5.getSideLength() / 2));
    for (int r5 = 0; r5 <= length5; r5++) {
      for (int c5 = 0; c5 <= length5; c5++) {
        if ((r5 < start && c5 < start) || (r5 > end5 && c5 < start5) || (r5 < start5 && c5 > end5)
                || (r5 > end && c5 > end)) {

          player5GameBoard[r5][c5] = invalid;

        } else {

          player5GameBoard[r5][c5] = marble;


        }


      }
    }
    player5GameBoard[model5.getEmptyRow()][model5.getEmptyColumn()] = empty;

    assertArrayEquals(playerGameBoard, model1.getGameBoard());
    assertArrayEquals(player2GameBoard, model2.getGameBoard());
    assertArrayEquals(player3GameBoard, model3.getGameBoard());
    assertThrows(IllegalArgumentException.class, () -> model4.getGameBoard());
    assertArrayEquals(player5GameBoard, model5.getGameBoard());
  }


  /**
   * Tester for the main move method, checking to see if it's the correct slot order of
   * blanks and marbles to see if the move is possibly a valid move.
   */
  @Test

  public void move() {
    MarbleSolitaireModelState.SlotState invalid = MarbleSolitaireModelState.SlotState.Invalid;
    MarbleSolitaireModelState.SlotState marble = MarbleSolitaireModelState.SlotState.Marble;
    MarbleSolitaireModelState.SlotState empty = MarbleSolitaireModelState.SlotState.Empty;
    model1.move(3, 5, 3, 3);
    assertEquals(empty, model1.getGameBoard()[3][5]);
    assertEquals(empty, model1.getGameBoard()[3][4]);
    assertEquals(marble, model1.getGameBoard()[3][2]);
    assertEquals(31, model1.getScore());

    model2.move(3, 3, 5, 5);
    assertEquals(empty, model2.getGameBoard()[3][3]);
    assertEquals(empty, model2.getGameBoard()[3][4]);
    assertEquals(marble, model2.getGameBoard()[3][5]);
    assertEquals(31, model2.getScore());

    model3.move(3, 1, 3, 3);
    assertEquals(empty, model3.getGameBoard()[3][1]);
    assertEquals(empty, model3.getGameBoard()[3][2]);
    assertEquals(marble, model3.getGameBoard()[3][3]);
    assertEquals(31, model3.getScore());

    assertThrows(IllegalArgumentException.class
            , () -> model4.move(4, 6, 6, 6));


    assertThrows(IllegalArgumentException.class
            , () -> model5.move(4, 2, 3, 3));
  }


  /**
   * Tester for the moveHelper boolean method that is uses to give support to the move method to
   * see if the slots of the game board will be blank or have a game pieces.
   */
  @Test
  public void moveHelper() {
    assertFalse(model1.moveHelper(6, 6));
    assertTrue(model1.moveHelper(3, 3));
    assertFalse(model2.moveHelper(1, 1));
    assertTrue(model2.moveHelper(3, 3));
    assertFalse(model3.moveHelper(5, 6));
    assertTrue(model3.moveHelper(5, 4));
    assertThrows(IllegalArgumentException.class, () -> model4.moveHelper(4, 6));
    assertFalse(model5.moveHelper(1, 0));
    assertTrue(model5.moveHelper(3, 5));
  }

  /**
   * Tester for startEndHelper.
   */
  @Test
  public void startEndHelper() {
    assertEquals(false, model1.startEndHelper(3, 6, 2, 5));
    assertEquals(true, model1.startEndHelper(3, 2, 3, 4));
    assertEquals(false, model2.startEndHelper(4, 3, 3, 4));
    assertEquals(true, model2.startEndHelper(3, 4, 3, 5));
    assertEquals(false, model3.startEndHelper(2, 3, 5, 4));
    assertEquals(true, model3.startEndHelper(3, 2, 3, 4));
    assertThrows(IllegalArgumentException.class
            , () -> model4.startEndHelper(1, 3, 2, 4));
    assertEquals(false, model5.startEndHelper(5, 3, 2, 4));
    assertEquals(true, model5.startEndHelper(3, 3, 4, 3));
  }


  /**
   * Tester for that gives support to the  move method, checking to see if it's the correct
   * slot order of blanks and marbles to see if the move is possibly a valid move.
   */
  @Test
  public void detectHelper() {
    assertTrue(model1.detectHelper(3, 5, 3, 3));
    assertFalse(model1.detectHelper(3, 6, 3, 3));

    assertTrue(model2.detectHelper(4, 2, 4, 4));
    assertFalse(model2.detectHelper(3, 6, 3, 3));

    assertTrue(model3.detectHelper(4, 2, 4, 4));
    assertFalse(model3.detectHelper(3, 3, 6, 6));

    assertThrows(IllegalArgumentException.class
            , () -> model4.detectHelper(4, 5, 4, 6));

    assertTrue(model5.detectHelper(2, 2, 2, 4));
    assertFalse(model5.detectHelper(3, 1, 3, 4));
  }

  /**
   * Tester for middle helper for X method that helps gives support to the move method,
   * by checking to see in the Coordinates of the rows on the game board are correct or valid to
   * move.
   */
  @Test
  //be careful with calculations
  public void middleXHelper() {
    assertEquals(3, model1.middleXHelper(3, 2, 3, 4));
    assertEquals(4, model2.middleXHelper(3, 2, 3, 4));
    assertEquals(4, model3.middleXHelper(4, 3, 4, 5));
    assertThrows(IllegalArgumentException.class
            , () -> model4.middleXHelper(3, 4, 3, 2));
    assertEquals(4, model5.middleXHelper(2, 3, 2, 5));
  }

  /**
   * Tester for middle helper for Y method that helps gives support to the move method,
   * by checking to see in the Coordinates of the columns on the game board are correct or valid
   * to move.
   */
  @Test
  public void middleYHelper() {
    assertEquals(3, model1.middleYHelper(1, 3, 3, 3));
    assertEquals(4, model2.middleYHelper(2, 4, 4, 4));
    assertEquals(4, model3.middleYHelper(1, 4, 3, 4));
    assertThrows(IllegalArgumentException.class
            , () -> model4.middleXHelper(3, 4, 1, 4));
    assertEquals(4, model5.middleYHelper(5, 4, 3, 4));

  }


  /**
   * Tester for the main method isGameOver, if there is anymore moves to play. It will
   * keep going until there are no more pieces left to play.
   */
  @Test
  public void isGameOver() {
    EnglishSolitaireModel game1 = new EnglishSolitaireModel();
    MarbleSolitaireModelState.SlotState empty = MarbleSolitaireModelState.SlotState.Empty;
    MarbleSolitaireModelState.SlotState marble = MarbleSolitaireModelState.SlotState.Marble;
    MarbleSolitaireModelState.SlotState invalid = MarbleSolitaireModelState.SlotState.Invalid;

    assertEquals(false, game1.isGameOver());


    game1.setGameBoard(new MarbleSolitaireModelState.SlotState[][]{
            {invalid, invalid, empty, empty, marble, invalid, invalid},
            {invalid, invalid, empty, empty, empty, invalid, invalid},
            {empty, empty, empty, empty, marble, empty, empty},
            {empty, empty, marble, empty, empty, empty, empty},
            {empty, empty, empty, empty, empty, marble, empty},
            {invalid, invalid, marble, empty, marble, invalid, invalid},
            {invalid, invalid, empty, empty, empty, invalid, invalid}
    });
    assertEquals(true, game1.isGameOver());
  }


  /**
   * Tester for helper method validHelper in which supports the move class. checks to see
   * if the move is valid by checking the fill with a marble or is an empty spot. Overall checks is
   * valid if the start for rows and columns, but both ends are blank.
   */
  @Test
  public void validHelper() {
    assertTrue(model1.validHelper(3, 4, 3, 2));
    assertFalse(model1.validHelper(3, 4, 3, 1));

    assertTrue(model2.validHelper(3, 1, 3, 3));
    assertFalse(model2.validHelper(4, 3, 4, 5));

    assertTrue(model3.validHelper(3, 4, 3, 2));
    assertFalse(model3.validHelper(1, 2, 1, 4));

    assertThrows(IllegalArgumentException.class
            , () -> model4.validHelper(2, 5, 2, 3));

    assertTrue(model5.validHelper(1, 3, 3, 3));
    assertFalse(model5.validHelper(2, 2, 2, 5));
  }

  /**
   * This Tester will help generate the object on the board.
   */
  @Test
  public void fillBoard() {
    model1.fillBoard();
    assertNotEquals(model1.getGameBoard(), null);

    model2.fillBoard();
    assertEquals(model2.getSlotAt(3, 3), MarbleSolitaireModelState.SlotState.Empty);

    model3.fillBoard();
    assertEquals(model3.getSlotAt(3, 1), MarbleSolitaireModelState.SlotState.Marble);

    model4.fillBoard();
    assertNull(model4.getGameBoard());

    model5.fillBoard();
    assertEquals(model5.getSlotAt(3, 3), MarbleSolitaireModelState.SlotState.Marble);

  }
}




