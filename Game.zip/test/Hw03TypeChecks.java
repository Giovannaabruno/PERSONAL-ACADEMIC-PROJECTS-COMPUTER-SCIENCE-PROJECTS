import java.io.IOException;

import cs3500.marblesolitaire.model.hw02.EnglishSolitaireModel;
import cs3500.marblesolitaire.model.hw02.MarbleSolitaireModel;

/**
 * Do not modify this file. This file should compile correctly with your code!
 */
public class Hw03TypeChecks {

  /**
   * constructor for main.
   * @param args is the array list object
   * @throws IOException if the input or output has an error
   */
  public static void main(String[] args) throws IOException {
    Readable rd = null;
    Appendable ap = null;
    helper(new EnglishSolitaireModel(),
            rd, ap);
    helper(new EnglishSolitaireModel(3, 3),
            rd, ap);
  }

  /**
   * Helper methode.
   * @param model equals model.
   * @param rd equals Readable.
   * @param ap equals Appendable.
   * @throws IOException if there is an error in the input or output
   */
  private static void helper(MarbleSolitaireModel model,
                             Readable rd, Appendable ap) throws IOException {
    new cs3500.marblesolitaire.controller.MarbleSolitaireControllerImpl(model,
            new cs3500.marblesolitaire.view.MarbleSolitaireTextView(model,ap),rd);
  }

}
