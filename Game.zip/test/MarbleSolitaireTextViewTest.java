import org.junit.Test;

import cs3500.marblesolitaire.model.hw04.EuropeanSolitaireModel;
import cs3500.marblesolitaire.model.hw04.TriangleSolitaireModelTest;
import cs3500.marblesolitaire.view.MarbleSolitaireTextView;

import cs3500.marblesolitaire.model.hw02.EnglishSolitaireModel;
import cs3500.marblesolitaire.model.hw02.MarbleSolitaireModel;

import static org.junit.Assert.assertEquals;


/**
 * Class for MarbleSolitaireTextViewTest.
 */
public class MarbleSolitaireTextViewTest {
  MarbleSolitaireModel game1 = new EnglishSolitaireModel();
  MarbleSolitaireTextView view1 = new MarbleSolitaireTextView(game1);

  MarbleSolitaireModel game2 = new EuropeanSolitaireModel();
  MarbleSolitaireTextView view2 = new EuropeanSolitaireModel(game2);

  MarbleSolitaireModel game3 = new TriangleSolitaireModelTest();
  MarbleSolitaireTextView view3 = new TriangleSolitaireModelTest(game3);


  /**
   * Tester for The ToString method for EnglishSolitaireModel game board.
   */
  @Test
  public void testToString() {
    String emptyBoard =
            "  0 0 0\n"
                    +
                    "    0 0 0\n"
                    +
                    "0 0 0 0 0 0 0\n"
                    +
                    "0 0 0 _ 0 0 0\n"
                    +
                    "0 0 0 0 0 0 0\n"
                    +
                    "    0 0 0\n"
                    +
                    "    0 0 0";
    assertEquals(view1.toString().equals(emptyBoard));

  }

  /**
   * Tester for The ToString method for EnglishSolitaireModel game board..
   */
  @Test
  public void testToString() {
    String emptyBoard = "    O O O\n" +
            "  O O O O O\n" +
            "O O O O O O O\n" +
            "O O O _ O O O\n" +
            "O O O O O O O\n" +
            "  O O O O O\n" +
            "    O O O";
    assertEquals(view2.toString().equals(emptyBoard));

  }

  /**
   * Tester for The ToString method for EnglishSolitaireModel game board..
   */
  @Test
  public void testToString() {
    String emptyBoard = "      O\n" +
            "     O O\n" +
            "    O O _\n" +
            "   O O O O\n" +
            "  O O O O O\n" +
            " O O O O O O\n" +
            "O O O O O O O ";
    assertEquals(String().view.ToString);

  }
}