package cs3500.marblesolitaire.model.hw04;

import org.junit.Before;
import org.junit.Test;

import cs3500.marblesolitaire.model.hw02.MarbleSolitaireModelState;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertThrows;
import static org.junit.Assert.assertTrue;

/**
 * Tester for TriangleSolitaireModelTest.
 */
public class TriangleSolitaireModelTest {
  TriangleSolitaireModel model1;
  TriangleSolitaireModel model2;
  TriangleSolitaireModel model3;
  TriangleSolitaireModel model4;
  TriangleSolitaireModel model5;

  /**
   * The 4 model scenarios that will be used for testers in EnglishSolitaireModel.
   *
   * @throws IllegalArgumentException represents four models, throws exception
   *     if the default does not catch.
   */
  @Before
  public void setUp() throws IllegalArgumentException {
    model1 = new TriangleSolitaireModel();
    model2 = new TriangleSolitaireModel(3, 1);
    model3 = new TriangleSolitaireModel(3);
    model4 = new TriangleSolitaireModel(-4, 6, 6);
    model5 = new TriangleSolitaireModel(5, 3, 3);
  }

  /**
   * Tester for Getter method for Dimensions.
   */
  @Test
  public void getDimensions() {
    assertEquals(5, model1.getDimensions());
    assertEquals(5, model2.getDimensions());
    assertEquals(3, model3.getDimensions());
    assertThrows(IllegalArgumentException.class, () -> model4.getDimensions());
    assertEquals(5, model5.getDimensions());
  }

  /**
   * tester for Move method for the triangle game board will the valued and Invalid moves.
   */
  @Test
  public void move() {
    MarbleSolitaireModelState.SlotState invalid = MarbleSolitaireModelState.SlotState.Invalid;
    MarbleSolitaireModelState.SlotState marble = MarbleSolitaireModelState.SlotState.Marble;
    MarbleSolitaireModelState.SlotState empty = MarbleSolitaireModelState.SlotState.Empty;
    model1.move(2, 0, 0, 0);
    assertEquals(empty, model1.getGameBoard()[2][0]);
    assertEquals(empty, model1.getGameBoard()[1][0]);
    assertEquals(marble, model1.getGameBoard()[0][0]);
    assertEquals(13, model1.getScore());

    model2.move(1, 1, 3, 1);
    assertEquals(empty, model2.getGameBoard()[1][1]);
    assertEquals(empty, model2.getGameBoard()[2][1]);
    assertEquals(marble, model2.getGameBoard()[3][1]);
    assertEquals(13, model2.getScore());

    model3.move(2, 2, 0, 0);
    assertEquals(empty, model3.getGameBoard()[2][2]);
    assertEquals(empty, model3.getGameBoard()[1][1]);
    assertEquals(marble, model3.getGameBoard()[0][0]);
    assertEquals(4, model3.getScore());

    assertThrows(IllegalArgumentException.class
            , () -> model4.move(4, 6, 6, 6));


    assertThrows(IllegalArgumentException.class
            , () -> model5.move(-1, -1, 0, 0));
  }

  /**
   * tester for isValidMove.
   */
  @Test
  // test 6 directions for move, test moving off the board, false (test moving a empty spot)
  public void  isValidMove() {
    assertTrue(model1.isValidMove(2, 2, 0, 0));
    assertTrue(model2.isValidMove(2, 2, 0, 0));
    assertTrue(model3.isValidMove(2, 0, 0, 0));
    assertFalse(model4.isValidMove(2, 0, 0, 0));
    assertTrue(model5.isValidMove(4, 4, 2, 2));


  }


  /**
   * Tester for method fillBoard.
   */
  @Test
  public void fillBoard() {
    model1.fillBoard();
    assertNotEquals(model1.getGameBoard(),null);

    model2.fillBoard();
    assertEquals(model2.getSlotAt(3,1), MarbleSolitaireModelState.SlotState.Empty);

    model3.fillBoard();
    assertEquals(model3.getSlotAt( 2,2), MarbleSolitaireModelState.SlotState.Marble);

    model4.fillBoard();
    assertNull(model4.getGameBoard());

    model5.fillBoard();
    assertEquals(model5.getSlotAt(3,3), MarbleSolitaireModelState.SlotState.Marble);





  }
}