package cs3500.marblesolitaire.view.hw04;




/**
 * Class for TriangleSolitaireTextViewTest
 * will test the renderBoard and renderMessage.
 */
//public class TriangleSolitaireTextViewTest {

  //@Test
  /*
   * Tester for renderBoard
   */
  //public void renderBoard() {
 // }


 // @Test
  /*
   * Tester for renderMessage
   */
  //public void renderMessage() {
 // }
//}