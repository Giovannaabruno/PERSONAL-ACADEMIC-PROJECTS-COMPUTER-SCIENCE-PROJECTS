package testt;

import org.junit.Before;
import org.junit.Test;

import java.io.IOException;
import java.io.StringReader;


import cs3500.marblesolitaire.controller.MarbleSolitaireControllerImpl;
import cs3500.marblesolitaire.model.hw02.EnglishSolitaireModel;
import cs3500.marblesolitaire.view.MarbleSolitaireTextView;
import static org.junit.Assert.assertTrue;


/**
 * Testing class for MarbleSolitaireControllerImplTest create case that the controller controls.
 */
public class MarbleSolitaireControllerImplTest {
  EnglishSolitaireModel model1;
  MarbleSolitaireTextView view1;
  StringBuilder append1;
  StringReader reader1;

  MarbleSolitaireControllerImpl controller1;

  EnglishSolitaireModel model2;
  MarbleSolitaireTextView view2;
  StringBuilder append2;
  StringReader reader2;

  MarbleSolitaireControllerImpl controller2;

  EnglishSolitaireModel model3;
  MarbleSolitaireTextView view3;
  StringBuilder append3;
  StringReader reader3;

  MarbleSolitaireControllerImpl controller3;

  EnglishSolitaireModel model4;
  MarbleSolitaireTextView view4;
  StringBuilder append4;
  StringReader reader4;

  MarbleSolitaireControllerImpl controller4;


  EnglishSolitaireModel model5;
  MarbleSolitaireTextView view5;
  StringBuilder append5;
  StringReader reader5;

  MarbleSolitaireControllerImpl controller5;

  EnglishSolitaireModel model6;
  MarbleSolitaireTextView view6;
  StringBuilder append6;
  StringReader reader6;

  MarbleSolitaireControllerImpl controller6;

  EnglishSolitaireModel model7;
  MarbleSolitaireTextView view7;
  StringBuilder append7;
  StringReader reader7;

  MarbleSolitaireControllerImpl controller7;

  EnglishSolitaireModel model8;
  MarbleSolitaireTextView view8;
  StringBuilder append8;
  StringReader reader8;

  MarbleSolitaireControllerImpl controller8;

  EnglishSolitaireModel model9;
  MarbleSolitaireTextView view9;
  StringBuilder append9;
  StringReader reader9;

  MarbleSolitaireControllerImpl controller9;







  /**
   * The 4 model scenarios that will be used for testers in EnglishSolitaireModel.
   *
   * @throws Exception represents four models if the default does not catch.
   */
  @Before
  public void setUp() throws IllegalArgumentException, IOException {
    // testing armThickness 1
    model1 = new EnglishSolitaireModel(1);
    append1 = new StringBuilder();
    view1 = new MarbleSolitaireTextView(model1, append1);
    reader1 = new StringReader("");
    controller1 = new MarbleSolitaireControllerImpl(model1, view1, reader1);

    model2 = new EnglishSolitaireModel(3);
    append2 = new StringBuilder();
    view2 = new MarbleSolitaireTextView(model2, append2);
    reader2 = new StringReader("4 1 4 4");
    controller2 = new MarbleSolitaireControllerImpl(model2, view2, reader2);

    model3 = new EnglishSolitaireModel(3);
    append3 = new StringBuilder();
    view3 = new MarbleSolitaireTextView(model3, append3);
    reader3 = new StringReader("3 1 3 3");
    controller3 = new MarbleSolitaireControllerImpl(model3, view3, reader3);

    model4 = new EnglishSolitaireModel(3);
    append4 = new StringBuilder();
    view4 = new MarbleSolitaireTextView(model4, append4);
    reader4 = new StringReader("1 3 3 3");
    controller4 = new MarbleSolitaireControllerImpl(model4, view4, reader4);

    model5 = new EnglishSolitaireModel(5);
    append5 = new StringBuilder();
    view5 = new MarbleSolitaireTextView(model5, append5);
    reader5 = new StringReader(" 3 2 3 4");
    controller5 = new MarbleSolitaireControllerImpl(model5, view5, reader5);

    model6 = new EnglishSolitaireModel(3);
    append6 = new StringBuilder();
    view6 = new MarbleSolitaireTextView(model6, append6);
    reader6 = new StringReader("5 4 3 4");
    controller6 = new MarbleSolitaireControllerImpl(model6, view6, reader6);

    model7 = new EnglishSolitaireModel(3);
    append7 = new StringBuilder();
    view7 = new MarbleSolitaireTextView(model7, append7);
    reader7 = new StringReader("3 6 3 4");
    controller7 = new MarbleSolitaireControllerImpl(model7, view7, reader7);

    model8 = new EnglishSolitaireModel(3);
    append8 = new StringBuilder();
    view8 = new MarbleSolitaireTextView(model8, append8);
    reader8 = new StringReader("2 2 2 4");
    controller8 = new MarbleSolitaireControllerImpl(model8, view8, reader8);

    model9 = new EnglishSolitaireModel(3);
    append9 = new StringBuilder();
    view9 = new MarbleSolitaireTextView(model9, append9);
    reader9 = new StringReader("4 2 4 4");
    controller9 = new MarbleSolitaireControllerImpl(model9, view9, reader9);
  }


  /**
   * Tester for playGame for controller1 and 2.
   * @throws IOException error that happens while transmitting the input or output.
   */
  @Test
  public void playGame() throws IOException {
    controller1.playGame();
    String result = "Game over!\n" +
            "    0 0 0\n" +
            "    0 0 0\n" +
            "0 0 0 0 0 0 0 0\n" +
            "0 0 0 _ 0 0 0\n" +
            "0 0 0 0 0 0 0\n" +
            "    0 0 0\n" +
            "    0 0 0\n" +
            "Score: 32";

    assertTrue(append1.toString().equals(result));


    controller2.playGame();
    String result2 = "Game over!\n" +
            "  0\n" +
            "0 _ 0\n" +
            "  0\n" +
            "Score: 4";

    assertTrue(append2.toString().equals(result2));




    controller3.playGame();
    String result3 = "Game over!\n" +
            "    0 0 0\n" +
            "    0 0 0\n" +
            "0 0 0 0 0 0 0\n" +
            "0 0 0 _ 0 0 0\n" +
            "0 0 0 0 0 0 0\n" +
            "    0 0 0\n" +
            "    0 0 0 \n" +
            "Score: 32";

    assertTrue(append3.toString().equals(result3));



    controller4.playGame();
    String result4 = "Game over!\n" +
            "    0 0 0\n" +
            "    0 0 0\n" +
            "0 0 0 0 0 0 0\n" +
            "0 0 0 _ 0 0 0\n" +
            "0 0 0 0 0 0 0\n" +
            "    0 0 0\n" +
            "    0 0 \n" +
            "Score: 32";

    assertTrue(append4.toString().equals(result4));


    controller5.playGame();
    String result5 = "Game over!\n" +
            "      0 0 0 0 0 \n" +
            "      0 0 0 0 0 \n" +
            "      0 0 0 0 0 \n" +
            "0 0 0 0 0 0 0 0 0 0 0\n" +
            "0 0 0 0 0 0 0 0 0 0 0\n" +
            "0 0 0 0 0 - 0 0 0 0 0\n" +
            "0 0 0 0 0 0 0 0 0 0 0\n" +
            "0 0 0 0 0 0 0 0 0 0 0\n" +
            "      0 0 0 0 0\n" +
            "      0 0 0 0 0\n" +
            "      0 0 0 0 0\n" +
            "Score: 84";

    assertTrue(append5.toString().equals(result5));



    controller6.playGame();
    String result6 = "Game over!\n" +
            "    0 0 0\n" +
            "    0 0 0\n" +
            "0 0 0 0 0 0 0\n" +
            "0 0 0 _ 0 0 0\n" +
            "0 0 0 0 0 0 0\n" +
            "    0 0 0\n" +
            "    0 0 \n" +
            "Score: 32";

    assertTrue(append6.toString().equals(result6));


    controller7.playGame();
    String result7 = "Game over!\n" +
            "    0 0 0\n" +
            "    0 0 0\n" +
            "0 0 0 0 0 0 0\n" +
            "0 0 0 _ 0 0 0\n" +
            "0 0 0 0 0 0 0\n" +
            "    0 0 0\n" +
            "    0 0 \n" +
            "Score: 32";

    assertTrue(append7.toString().equals(result7));




    controller8.playGame();
    String result8 = "Game over!\n" +
            "    0 0 0\n" +
            "    0 0 0\n" +
            "0 0 0 0 0 0 0\n" +
            "0 0 0 _ 0 0 0\n" +
            "0 0 0 0 0 0 0\n" +
            "    0 0 0\n" +
            "    0 0 \n" +
            "Score: 32";

    assertTrue(append8.toString().equals(result8));

    controller9.playGame();
    String result9 = "Game over!\n" +
            "    0 0 0\n" +
            "    0 0 0\n" +
            "0 0 0 0 0 0 0\n" +
            "0 0 0 _ 0 0 0\n" +
            "0 0 0 0 0 0 0\n" +
            "    0 0 0\n" +
            "    0 0 \n" +
            "Score: 32";

    assertTrue(append9.toString().equals(result9));
  }
}