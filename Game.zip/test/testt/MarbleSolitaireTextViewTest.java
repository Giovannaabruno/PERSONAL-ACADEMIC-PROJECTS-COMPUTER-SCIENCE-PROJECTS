package testt;

import org.junit.Before;
import org.junit.Test;

import java.io.IOException;

import cs3500.marblesolitaire.model.hw02.EnglishSolitaireModel;
import cs3500.marblesolitaire.view.MarbleSolitaireTextView;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;


/**
 * Tester for class MarbleSolitaireTextView, contains the objects that will be used for testing.
 */
public class MarbleSolitaireTextViewTest {
  StringBuilder append1;

  EnglishSolitaireModel model1;

  MarbleSolitaireTextView view1;

  StringBuilder append2;

  EnglishSolitaireModel model2;

  MarbleSolitaireTextView view2;

  /**
   * The setup for the  MarbleSolitaireTextViewTest.
   */
  @Before
  public void setUp() {
    append1 = new StringBuilder();
    model1 = new EnglishSolitaireModel();
    view1 = new MarbleSolitaireTextView(model1, append1);

    append2 = new StringBuilder();
    model2 = new EnglishSolitaireModel();
    view2 = new MarbleSolitaireTextView(model2, append2);

  }


  /**
   * Tester for ToString.
   */
  @Test
  public void testToString()  {
    assertFalse(" Board did not illustrate", toString().equals(""));
    assertFalse(" Board has new line character at the end",
            toString().substring(toString().length() - 1).equals("\n"));


  }

  /**
   * Testing renderBoard to create board.
   * Methode which transmits the state of the marble solitaire board to a specified destination.
   */
  @Test
  public void renderBoard() throws IOException {
    String result =
            "    0 0 0\n" +
            "    0 0 0\n" +
            "0 0 0 0 0 0 0\n" +
            "0 0 0 _ 0 0 0\n" +
            "0 0 0 0 0 0 0\n" +
            "    0 0 0\n" +
            "    0 0 0";
    view1.renderBoard();
    assertEquals(append1.toString(), result);



  }

  /**
   * Testing renderMessage to create message.
   */
  @Test
  public void renderMessage() throws IOException {
    view1.renderMessage("Test message");
    assertEquals(append1.toString(),"Test message" );
  }
}