package ImageMosaickFeature;

import java.util.ArrayList;

import java.util.List;
import java.util.Random;

import hw4.model.IPixel;
import hw4.model.RGBPixel;

/**
 * Class Mosaick will creat the seeds that make a mosaick image.
 */
public class Mosaick implements MosaickFeatures {


  private static Random rng = new Random();

  /**
   * Sub-Class  Seed, will contain the average red, green, and blue value.
   */
  public static class Seed {
    int x;
    int y;
    int red;
    int green;
    int blue;
    int total;

    /**
     * Constructor for Seed.
     *
     * @param x represents row
     * @param y represents column
     */
    public Seed(int x, int y) {
      this.x = x;
      this.y = y;
      this.red = 0;
      this.green = 0;
      this.blue = 0;
      total = 0;
    }

    /**
     * Method addPixel, will find the total of pixels that has red green and blue values.
     *
     * @param pixel represents red, green, and blue values in a single cell
     */
    public void addPixel(IPixel pixel) {
      red += pixel.getRed();
      green += pixel.getGreen();
      blue += pixel.getBlue();
      total++;
    }

    /**
     * Method getFinalPixel, will find the average for red, green,
     * and blue values at the nears seed.
     *
     * @return The total average for red, green, and blue values.
     */
    public RGBPixel getFinalPixel() {

      return new RGBPixel(red / total, green / total, blue / total);
    }
  }


  /**
   * Method seed sets up the number of seeds.
   *
   * @param seed represents a random chosen set of points in the image.
   */
  public static void setSeed(long seed) {
    rng.setSeed(seed);
  }

  /**
   * Method mosaickPixel, will creat the list of randomly placed number of seeds on a image.
   *
   * @param rgb red, green, blue values
   * @param num num = number of seeds
   * @return the finish mosaick image
   */
  public static List<List<IPixel>> mosaickPixel(List<List<IPixel>> rgb, int num) {
    //this seed array exactly matches the rgb parameter:
    //the seed at a given row and column is the closest seed
    //to the pixel at row, column of rgb
    Seed[][] closestSeeds = new Seed[rgb.size()][rgb.get(0).size()];


    //create a list of randomly placed seeds
    ArrayList<Seed> seeds = new ArrayList<>();
    for (int n = 0; n < num; n++) {
      int x = (int) (rng.nextFloat() * rgb.size());
      int y = (int) (rng.nextFloat() * rgb.get(0).size());
      Seed s = new Seed(x, y);
      seeds.add(s);
    }

    //for every pixel, store in the matching row, column of closestSeess
    //the closestSeed to that pixel
    for (int r = 0; r < rgb.size(); r++) {
      for (int c = 0; c < rgb.get(0).size(); c++) {
        Seed closest = getClosestSeed(r, c, seeds);
        closest.addPixel(rgb.get(r).get(c));
        closestSeeds[r][c] = closest;
      }
    }

    //for every pixel, return the avergae color of the pixels assigned to the
    //closest seed
    List<List<IPixel>> result = new ArrayList<>();
    for (int r = 0; r < rgb.size(); r++) {
      result.add(new ArrayList<IPixel>());
      for (int c = 0; c < rgb.get(0).size(); c++) {
        result.get(r).add(closestSeeds[r][c].getFinalPixel());
      }
    }

    return result;
  }

  //returns the closest seed to a given row and column

  /**
   * Method getClosestSeed, find the closes seed for the pixel to turn towards,
   * it will turn towards the seed that has the smallest distant or ( x and y value).
   *
   * @param row   equals rows of the image
   * @param col   equals column of the image
   * @param seeds equals the seeds in the image
   * @return the effect of the pixels turning towards their closes seeds
   */
  private static Seed getClosestSeed(int row, int col, ArrayList<Seed> seeds) {
    double minDistance = Double.MAX_VALUE;
    Seed closestSeed = null;
    for (int i = 0; i < seeds.size(); i++) {
      Seed current = seeds.get(i);
      int difX = Math.abs(current.x - row);
      int difY = Math.abs(current.y - col);
      double distance = Math.hypot(difX, difY);
      if (distance < minDistance) {
        minDistance = distance;
        closestSeed = current;
      }
    }
    return closestSeed;
  }


}

