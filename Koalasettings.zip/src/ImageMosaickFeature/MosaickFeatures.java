package ImageMosaickFeature;


/**
 * public interface MosaickFeatures for the Mosaick class;
 */
public interface MosaickFeatures {


}