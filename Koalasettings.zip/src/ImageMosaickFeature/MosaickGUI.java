package ImageMosaickFeature;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;

import hw4.ImageUtil;
import hw4.model.IImage;
import hw4.model.IPixel;
import hw4.model.PPMImage;

/**
 * public class MosaickGUI which extends JFrame.
 */
public class MosaickGUI extends JFrame {
  private IImage image;

  /**
   * constructor for MosaickGUI.
   */
  public MosaickGUI() {
    super("MosaickGUI");
    setSize(640, 480);
    JFrame frame = this;
    setLayout(new BoxLayout(this.getContentPane(), BoxLayout.PAGE_AXIS));
    JButton openFileButton = new JButton("Open File");
    JLabel openFileLabel = new JLabel("");
    openFileButton.addActionListener(new ActionListener() {

      /**
       *  Listener that takes in the action command, for OpenFile.
        * @param e the event to be processed
       */
      @Override
      public void actionPerformed(ActionEvent e) {
        final JFileChooser fchooser = new JFileChooser(".");
        FileNameExtensionFilter filter = new FileNameExtensionFilter(
                "JPG, GIF, PPM & BMP Images", "jpg", "gif", "bmp", "ppm");
        fchooser.setFileFilter(filter);
        File f;
        int retvalue = fchooser.showOpenDialog( frame);
        if (retvalue == JFileChooser.APPROVE_OPTION) {
          f = fchooser.getSelectedFile();
          openFileLabel.setText(f.getAbsolutePath());
          handleOpenFile(f.getAbsolutePath());
        }
      }
    });
    this.add(openFileButton);
    this.add(openFileLabel);
    JTextField numSeedField = new JTextField();
    this.add(numSeedField);
    JButton saveFileButton = new JButton("Save File");
    saveFileButton.addActionListener(new ActionListener() {
      /**
       * Listener that takes in the action command, for saveFile.
        * @param e the event to be processed
       */
      @Override
      public void actionPerformed(ActionEvent e) {
        final JFileChooser fchooser = new JFileChooser(".");
        FileNameExtensionFilter filter = new FileNameExtensionFilter(
                "JPG, GIF, PPM & BMP Images", "jpg", "gif", "bmp", "ppm");
        fchooser.setFileFilter(filter);
        File f;
        int retvalue = fchooser.showSaveDialog( frame);

        if (retvalue == JFileChooser.APPROVE_OPTION) {
          f = fchooser.getSelectedFile();
          int numSeeds = Integer.parseInt(numSeedField.getText());

          handleSaveFile(f.getAbsolutePath(), numSeeds);
        }
      }
    });
    this.add(saveFileButton);

  }

  /**
   * This methode creates the open file button.
   * @param path file
   */
  protected void handleOpenFile(String path) {
    IImage image = ImageUtil.readImage(path);
    this.image = image;

  }

  /**
   * this methode creates the save file button.
   * @param path  file
   * @param numSeeds number of seeds
   */
  protected void handleSaveFile(String path, int numSeeds) {
    IImage image = ImageUtil.readImage("res/koala.ppm");

    List<List<IPixel>> pixels = new ArrayList<>();
    for (int r = 0; r < image.getHeight(); r++) {
      pixels.add(new ArrayList<>());
      for (int c = 0; c < image.getWidth(); c++) {
        pixels.get(r).add(image.getPixelAt(r, c));
      }
    }

    List<List<IPixel>> mosaic = Mosaick.mosaickPixel(pixels, numSeeds);
    IImage result = new PPMImage(mosaic);
    ImageUtil.saveImage(result, path);

  }

  /**
   * main Method
   * @param args represents arguments
   */
  public static void main(String [] args){
    JFrame window = new MosaickGUI();
    window.setVisible(true);


  }


}
