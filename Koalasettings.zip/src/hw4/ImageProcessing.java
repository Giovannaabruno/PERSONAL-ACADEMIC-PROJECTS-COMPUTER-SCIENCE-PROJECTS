package hw4;

import java.io.InputStreamReader;

import hw4.controller.IImageController;
import hw4.controller.ImageControllerImpl;
import hw4.model.IModel;
import hw4.model.ModelImpl;
import hw4.view.IView;
import hw4.view.ViewImpl;

/**
 * The class for our main() method to run the program.
 */
public class ImageProcessing {

  /**
   * The main() method to run our program.
   *
   * @param args the command line arguments (we do NOT use this personally)
   */
  static public void main(String[] args) {
    IModel model = new ModelImpl();
    IView view = new ViewImpl(System.out);
    IImageController controller =  new ImageControllerImpl(model,
            new InputStreamReader(System.in), view);

    controller.run();
  }
}
