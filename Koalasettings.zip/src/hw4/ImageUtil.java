package hw4;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.io.FileNotFoundException;
import java.io.FileInputStream;

import hw4.model.IImage;
import hw4.model.IPixel;
import hw4.model.PPMImage;
import hw4.model.RGBPixel;

// TODO: change documentation

/**
 * This class contains utility methods to read a PPM image from file and simply print its contents.
 * Feel free to change this method as required.
 */
public class ImageUtil {
  private static FileWriter writer;
  /*
   * TODO: Ask if we should have a switch here when we're only handling one case rn
   * Add image which has too many pixels to fit in rectangle
   * Add image with not enough pixels for rectangle
   */

  /**
   * Read an image file in the PPM format and use it to instantiate an IImage.
   *
   * @param filepath the path leading to the file
   * @return the new IImage image as specified by the file
   * @throws IllegalStateException if the file cannot be found
   */
  public static IImage readImage(String filepath)
          throws IllegalStateException, IllegalArgumentException {
    if (getFileExtension(filepath).equals("ppm")) {
      return readPPM(filepath);
    } else {
      throw new IllegalArgumentException("Invalid file format!");
    }
  }

  /**
   * Loads a PPM file as a new IImage.
   *
   * @param filepath the path leading to the file
   * @return the new loaded PPM image
   * @throws IllegalStateException if there are any errors reading the file
   */
  private static IImage readPPM(String filepath)
          throws IllegalStateException {

    Scanner sc;
    try {
      sc = new Scanner(new FileInputStream(filepath));
    } catch (FileNotFoundException e) {
      throw new IllegalStateException("File " + filepath + " not found!");
    }
    StringBuilder builder = new StringBuilder();
    //read the file line by line, and populate a string. This will throw away any comment lines
    while (sc.hasNextLine()) {
      String s = sc.nextLine();
      if (s.charAt(0) != '#') {
        builder.append(s + System.lineSeparator());
      }
    }

    //now set up the scanner to read from the string we just built
    sc = new Scanner(builder.toString());

    String token;

    token = sc.next();
    if (!token.equals("P3")) {
      throw new IllegalStateException("Invalid PPM file: plain RAW file should begin with P3");
    }
    int width = readInt(sc);
    int height = readInt(sc);
    int maxValue = readInt(sc);

    List<List<IPixel>> pixels = new ArrayList<>(0);
    for (int row = 0; row < height; row += 1) {
      pixels.add(row, new ArrayList<>(0));
      for (int col = 0; col < width; col += 1) {
        pixels.get(row).add(new RGBPixel(readInt(sc), readInt(sc), readInt(sc)));
      }
    }
    if (sc.hasNextInt()) {
      throw new IllegalStateException("Invalid PPM file! More pixels than dimensions specify!");
    }
    return new PPMImage(maxValue, pixels);
  }

  /**
   * Helper method which scans for the next integer, if there is any.
   *
   * @param sc the scanner to use
   * @return the integer to scan
   * @throws IllegalStateException if the next token is not an int
   */
  private static int readInt(Scanner sc) throws IllegalStateException {
    if (sc.hasNextInt()) {
      return sc.nextInt();
    } else if (sc.hasNext()) {
      throw new IllegalStateException("Integer expected!");
    } else {
      throw new IllegalStateException("Invalid PPM file! "
              + "Not enough pixels as specified by dimensions of image!");
    }
  }

  /**
   * Gets the file extension from the passed filename without the leading period.
   * @param filename the filename to pull the extension from
   * @return the file extension
   * @throws IllegalArgumentException if no file extension can be found
   */
  private static String getFileExtension(String filename) throws IllegalArgumentException {
    if (!filename.contains(".")) {
      throw new IllegalArgumentException("No extension found!");
    } else {
      return filename.substring(filename.lastIndexOf(".") + 1);
    }
  }

  /**
   * Saves the given image as a file at the given filepath.
   *
   * @param image the image to save
   * @param filepath the path where the file should be saved to
   * @throws IllegalStateException if there are any errors writing to the file
   */
  public static void saveImage(IImage image, String filepath)
          throws IllegalStateException {
    File file = new File(filepath);
    String sep = System.lineSeparator();
    try {
      writer = new FileWriter(filepath);
    } catch (IOException e) {
      throw new IllegalStateException("An error occurred in opening the file writer.");
    }
    writeLine("P3");
    writeLine(String.format("%d %d", image.getWidth(), image.getHeight()));
    writeLine(Integer.toString(image.getMaxChannelDepth()));
    for (int row = 0; row < image.getHeight(); row += 1) {
      for (int col = 0; col < image.getWidth(); col += 1) {
        IPixel p = image.getPixelAt(row, col);
        writeLine(Integer.toString(p.getRed()));
        writeLine(Integer.toString(p.getGreen()));
        writeLine(Integer.toString(p.getBlue()));
      }
    }
    try {
      writer.close();
    } catch (IOException e) {
      throw new IllegalStateException("An error occurred in closing the file writer.");
    }

  }

  /**
   * Helper method which writes a single line of content to the file specified by the FileWriter.
   * @param input  the input desired to be written to the file
   * @throws IllegalStateException if there are any errors writing to the file
   */
  private static void writeLine(String input) throws IllegalStateException {
    try {
      writer.write(input + System.lineSeparator());
    } catch (IOException e) {
      throw new IllegalStateException("An error occurred writing to the file.");
    }
  }
}

