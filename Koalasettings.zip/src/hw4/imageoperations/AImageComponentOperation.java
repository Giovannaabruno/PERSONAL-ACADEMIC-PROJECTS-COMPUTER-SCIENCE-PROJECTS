package hw4.imageoperations;

import hw4.model.IImage;
import hw4.model.IPixel;
import hw4.model.RGBPixel;

/**
 * Represents the abstraction for all "component" operations. These are the operations which
 * create a grayscale from a certain type of component value or component-based calculation
 * (like Red, Luma, etc.).
 */
public abstract class AImageComponentOperation extends AImageOperation {

  @Override
  protected IPixel operateOnPixel(IImage image, int row, int col) throws IllegalArgumentException {
    if (image == null) {
      throw new IllegalArgumentException("The given image cannot be null.");
    }

    int desiredComponentValue = this.getDesiredComponentValue(image, row, col);

    IPixel pixel = new RGBPixel(desiredComponentValue, desiredComponentValue,
            desiredComponentValue);

    return pixel;
  }

  /**
   * Returns the integer value of the desired component of a pixel at the given (row, col) position
   * in the given IImage's pixels. Whether the type of component is red, luma, etc. depends on
   * where this abstract method is being implemented. Dynamics!
   *
   * @param image the given IImage to source pixel information from.
   * @param row the given row index to look through image's pixels with.
   * @param col the given col index to look through image's pixels with.
   * @return the integer value of the desired component.
   * @throws IllegalArgumentException if the given IImage is null.
   */
  abstract protected int getDesiredComponentValue(IImage image, int row, int col)
          throws IllegalArgumentException;
}
