package hw4.imageoperations;

import hw4.model.IImage;

/**
 * Represents a function object for getting a grayscale of the blue component of the pixels in
 * an image. For example, if a pixel in the original image was (250, 24, 22), the corresponding
 * pixel in the resulting pixels would be (22, 22, 22).
 */
public class BlueComponentOperation extends AImageComponentOperation {
  @Override
  protected int getDesiredComponentValue(IImage image, int row, int col)
          throws IllegalArgumentException {
    if (image == null) {
      throw new IllegalArgumentException("The given image cannot be null.");
    }

    return image.getPixelAt(row, col).getBlue();
  }
}
