package hw4.imageoperations;

import hw4.model.IImage;
import hw4.model.IPixel;
import hw4.model.RGBPixel;

/**
 * Represents a function object for brightening pixels by the given
 * increment (or darkening them if the increment is negative). Works using the concept of brightness
 * intensity: the increment is added to each of the relevant channels all the same
 * (i.e. not weighted like Luma).
 *
 * <p>Also note that entering an increment that would bring a pixel channel
 * below the minimum or above the maximum simply results in the channel value getting clamped to
 * the minimum or clamped to the maximum, respectively. For example: an increment of -200 for
 * a pixel with RGB values (200, 220, 40) and max channel depth of 255 results in a pixel
 * with RGB values (0, 20, 0) for, say, a pixel in a PPMImage's pixels. Similarly, an
 * increment of 200 would result in (255, 255, 240) for that same original pixel.
 */
public class BrightenOperation extends AImageOperation {
  private final int increment;

  public BrightenOperation(int increment) {
    this.increment = increment;
  }

  /**
   * Clamps an integer to 0 if it is negative or to the given clamp (upper limit) if it is
   * greater than the clamp. Otherwise, the integer is left unchanged.
   * Returns the resulting integer.
   *
   * @param value the value to clamp, if out of bounds
   * @param clamp the upper limit to clamp greater values to
   * @return the clamped (if necessary) integer
   */
  private int clamp(int value, int clamp) {
    if (value < 0) {
      return 0;
    } else {
      return Math.min(value, clamp);
    }
  }

  @Override
  protected IPixel operateOnPixel(IImage image, int row, int col) {
    if (image == null) {
      throw new IllegalArgumentException("The given image cannot be null.");
    }

    int depth = image.getMaxChannelDepth();
    int originalRed = image.getPixelAt(row, col).getRed();
    int originalGreen = image.getPixelAt(row, col).getGreen();
    int originalBlue = image.getPixelAt(row, col).getBlue();

    int newRed = this.clamp(originalRed + this.increment,
            depth);

    int newGreen = this.clamp(originalGreen + this.increment,
            depth);

    int newBlue = this.clamp(originalBlue + this.increment,
            depth);

    IPixel pixel = new RGBPixel(newRed, newGreen, newBlue);

    return pixel;
  }
}
