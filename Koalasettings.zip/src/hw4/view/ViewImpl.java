package hw4.view;

import java.io.IOException;

/**
 * View implementation which stores an Appendable for rendering messages.
 */
public class ViewImpl implements IView {
  private final Appendable out;


  public ViewImpl(Appendable out) {
    this.out = out;
  }

  @Override
  public void renderMessage(String message) throws IOException {
    this.out.append(message);
  }
}
