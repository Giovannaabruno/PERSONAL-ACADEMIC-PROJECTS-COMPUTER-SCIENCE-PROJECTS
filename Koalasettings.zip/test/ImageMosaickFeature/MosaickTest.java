package ImageMosaickFeature;


import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import hw4.ImageUtil;
import hw4.model.IImage;
import hw4.model.IPixel;
import hw4.model.PPMImage;

import static org.junit.Assert.assertEquals;


/**
 * Tester for  Mosaick.
 */
public class MosaickTest {


  /**
   * Method mosaickPixel, will creat the list of randomly placed number of seeds on a image.
   */
  @Test
  public void mosaickPixel() {
    // example 1
    Mosaick.setSeed(1);
    IImage image = ImageUtil.readImage("res/koala.ppm");
    int numSeeds = 300;

    List<List<IPixel>> pixels = new ArrayList<>();
    for (int r = 0; r < image.getHeight(); r++) {
      pixels.add(new ArrayList<>());
      for (int c = 0; c < image.getWidth(); c++) {
        pixels.get(r).add(image.getPixelAt(r, c));
      }
    }

    List<List<IPixel>> mosaic = Mosaick.mosaickPixel(pixels, numSeeds);
    IImage result = new PPMImage(mosaic);
    ImageUtil.saveImage(result, "res/koalaMosaicTest.ppm");
    IPixel topLeft = result.getPixelAt(0, 0);
    assertEquals(topLeft.getRed(), 107);
    assertEquals(topLeft.getGreen(), 90);
    assertEquals(topLeft.getBlue(), 64);
  }

  /**
   * tester mosaickPixelTwo, find the end.
   */
  @Test
  public void mosaickPixelTwo() {
    // example 2
    Mosaick.setSeed(2);
    IImage image = ImageUtil.readImage("res/koala.ppm");
    int numSeeds = 300;

    List<List<IPixel>> pixels = new ArrayList<>();
    for (int r = 0; r < image.getHeight(); r++) {
      pixels.add(new ArrayList<>());
      for (int c = 0; c < image.getWidth(); c++) {
        pixels.get(r).add(image.getPixelAt(r, c));
      }
    }

    List<List<IPixel>> mosaic = Mosaick.mosaickPixel(pixels, numSeeds);
    IImage result = new PPMImage(mosaic);
    ImageUtil.saveImage(result, "res/koalaMosaicTest.ppm");
    IPixel end = result.getPixelAt(result.getHeight() - 1, result.getWidth() - 1);
    assertEquals(end.getRed(), 144);
    assertEquals(end.getGreen(), 122);
    assertEquals(end.getBlue(), 95);
  }

  /**
   * tester mosaickPixelThree, find the middle .
   */
  @Test
  public void mosaickPixelThree() {
    // example 3
    Mosaick.setSeed(3);
    IImage image = ImageUtil.readImage("res/koala.ppm");
    int numSeeds = 300;

    List<List<IPixel>> pixels = new ArrayList<>();
    for (int r = 0; r < image.getHeight(); r++) {
      pixels.add(new ArrayList<>());
      for (int c = 0; c < image.getWidth(); c++) {
        pixels.get(r).add(image.getPixelAt(r, c));
      }
    }

    List<List<IPixel>> mosaic = Mosaick.mosaickPixel(pixels, numSeeds);
    IImage result = new PPMImage(mosaic);
    ImageUtil.saveImage(result, "res/koalaMosaicTest.ppm");
    IPixel middle = result.getPixelAt(383, 511);
    assertEquals(middle.getRed(), 183);
    assertEquals(middle.getGreen(), 172);
    assertEquals(middle.getBlue(), 165);
  }


}