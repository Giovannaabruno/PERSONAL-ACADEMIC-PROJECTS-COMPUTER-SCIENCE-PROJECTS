package hw4;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import hw4.model.IImage;
import hw4.model.IPixel;
import hw4.model.PPMImage;
import hw4.model.RGBPixel;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;


/**
 * Test class for the ImageUtil class.
 */
public class ImageUtilTest {

  private IImage twoByTwo;

  /**
   * Configures the right two by two image for testing.
   */
  @Before
  public void init() {
    List<List<IPixel>> pixels = new ArrayList<>();
    pixels.add(new ArrayList<>());
    pixels.add(new ArrayList<>());
    pixels.get(0).add(new RGBPixel(0, 0, 0));
    pixels.get(0).add(new RGBPixel(115, 100, 5));
    pixels.get(1).add(new RGBPixel(255, 255, 255));
    pixels.get(1).add(new RGBPixel(24, 110, 236));

    twoByTwo = new PPMImage(pixels);
  }

  @Rule
  public ExpectedException exceptionRule = ExpectedException.none();

  @Test
  public void fileNotFound() {
    exceptionRule.expect(IllegalStateException.class);
    exceptionRule.expectMessage("File dir" + File.separator + "asdf.ppm not found!");
    ImageUtil.readImage("dir" + File.separator + "asdf.ppm");
  }

  /**
   * Test that reading an image file produces the correct file.
   */
  @Test
  public void testReadImage() {
    IImage model = ImageUtil.readImage("res" + File.separator + "test-image.ppm");

    // making an empty scanner just so it's global outside the try statement
    Scanner sc = new Scanner("");
    try {
      sc = new Scanner(new FileInputStream("res" + File.separator + "test-image.ppm"));
    } catch (IOException e) {
      fail("There was an issue with the scanner.");
    }

    // Going through our test-image.ppm file line by line (just to be sure!)
    assertEquals("P3", sc.next());
    // Skipping the two comment lines in our test-image.ppm file
    sc.nextLine();
    sc.nextLine();
    sc.nextLine();
    assertEquals(model.getWidth(), sc.nextInt());
    assertEquals(model.getHeight(), sc.nextInt());
    sc.next();
    for (int row = 0; row < model.getHeight(); row += 1) {
      for (int col = 0; col < model.getWidth(); col += 1) {
        IPixel pixel = model.getPixelAt(row, col);
        assertEquals(pixel.getRed(), sc.nextInt());
        assertEquals(pixel.getGreen(), sc.nextInt());
        assertEquals(pixel.getBlue(), sc.nextInt());
      }
    }
  }

  /**
   * Tests that saving an image produces the correct file.
   */
  @Test
  public void testSaveImage() {
    ImageUtil.saveImage(this.twoByTwo, "temp.ppm");

    // making an empty scanner just so it's global outside the try statement
    Scanner sc = new Scanner("");
    try {
      sc = new Scanner(new FileInputStream("temp.ppm"));
    } catch (IOException e) {
      fail();
    }
    assertEquals("P3", sc.next());
    assertEquals(2, sc.nextInt());
    assertEquals(2, sc.nextInt());
    assertEquals(255, sc.nextInt());
    for (int row = 0; row < this.twoByTwo.getHeight(); row += 1) {
      for (int col = 0; col < this.twoByTwo.getWidth(); col += 1) {
        IPixel pixel = this.twoByTwo.getPixelAt(row, col);
        assertEquals(pixel.getRed(), sc.nextInt());
        assertEquals(pixel.getGreen(), sc.nextInt());
        assertEquals(pixel.getBlue(), sc.nextInt());
      }
    }
    new File("temp.ppm").delete();
  }

  /**
   * Ensures that reading an image, saving it, and loading that save produces the same image.
   */
  @Test
  public void readWriteRead() {
    IImage model = ImageUtil.readImage("res" + File.separator +
            "test-image.ppm");
    ImageUtil.saveImage(model, "temp.ppm");
    IImage sameModel = ImageUtil.readImage("temp.ppm");
    assertTrue(model.samePixels(sameModel));
    new File("temp.ppm").delete();
  }

  /**
   * Ensures that saving an image, loading, and then saving that image produces the same file.
   */
  @Test
  public void writeReadWrite() {
    ImageUtil.saveImage(this.twoByTwo, "temp.ppm");
    IImage sameModel = ImageUtil.readImage("temp.ppm");
    ImageUtil.saveImage(sameModel, "same.ppm");
    Scanner one = new Scanner("");
    Scanner two = new Scanner("");
    try {
      one = new Scanner(new FileInputStream("temp.ppm"));
      two = new Scanner(new FileInputStream("same.ppm"));
    } catch (IOException e) {
      throw new IllegalStateException("The test threw an exception.");
    }
    while (one.hasNext()) {
      assertEquals(one.next(), two.next());
    }

    new File("temp.ppm").delete();
    new File("same.ppm").delete();
  }

  /**
   * Tests that the proper exception is thrown when the ImageUtil tries to read in a file with
   * more pixels than fit in the dimensions of the image.
   */
  @Test
  public void tooManyPixels() {
    try {
      ImageUtil.readImage("res" + File.separator +
              "test-image-5-by-2-labelled-3-by-3.ppm");
      fail();
    } catch (IllegalStateException e) {
      assertEquals("Invalid PPM file! "
              + "More pixels than dimensions specify!", e.getMessage());
    }
  }

  /**
   * Tests that the proper exception is thrown when the ImageUtil tries to read in a file
   * with not enough pixels to fill the dimensions of the image.
   */
  @Test
  public void notEnoughPixels() {
    try {
      ImageUtil.readImage("res" + File.separator +
              "test-image-5-by-2-labelled-6-by-2.ppm");
      fail();
    } catch (IllegalStateException e) {
      assertEquals("Invalid PPM file! Not enough "
              + "pixels as specified by dimensions of image!", e.getMessage());
    }
  }

  /**
   * Tests that the proper exception is thrown
   * when an invalid file format is passed to the ImageUtil.
   */
  @Test
  public void invalidFileFormat() {
    try {
      ImageUtil.readImage("res" + File.separator +
              "test-image.mp3");
      fail();
    } catch (IllegalArgumentException e) {
      assertEquals("Invalid file format!", e.getMessage());
    }
  }

  /**
   * Tests that the proper exception is thrown when the ImageUtil cannot get a file format
   * from the file.
   * Note: cannot test for exceptions when file ends in '.', since Windows does not accept
   * files ending in '.' as valid
   */
  @Test
  public void noFileFormat() {
    try {
      ImageUtil.readImage("res" + File.separator +
              "no-extension");
      fail();
    } catch (IllegalArgumentException e) {
      assertEquals("No extension found!", e.getMessage());
    }


  }

  /**
   * Tests that the proper exception is thrown when the ImageUtil tries to read in a file
   * without the proper P3 header.
   */
  @Test
  public void noP3PPM() {
    try {
      ImageUtil.readImage("res" + File.separator +
              "no-header.ppm");
      fail();
    } catch (IllegalStateException e) {
      assertEquals("Invalid PPM file: plain RAW file " +
              "should begin with P3", e.getMessage());
    }
  }

  /**
   * Tests that the proper exception is thrown when the ImageUtil tries to read in a file
   * which contains text where ints are expected.
   */
  @Test
  public void noIntPPM() {
    try {
      ImageUtil.readImage("res" + File.separator +
              "words.ppm");
      fail();
    } catch (IllegalStateException e) {
      assertEquals("Integer expected!", e.getMessage());
    }
  }


}