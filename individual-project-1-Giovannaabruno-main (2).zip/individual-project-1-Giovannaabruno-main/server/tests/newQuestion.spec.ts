import mongoose from 'mongoose';
import supertest from 'supertest';
import { app, server } from '../server';
import * as util from '../models/application';
import { Question, Tag } from '../types';
/**
 * Tag 1 info
 */
const tag1: Tag = {
  _id: new mongoose.Types.ObjectId('507f191e810c19729de860ea'),
  name: 'tag1',
};
/**
 * Tag 2 info
 */
const tag2: Tag = {
  _id: new mongoose.Types.ObjectId('65e9a5c2b26199dbcc3e6dc8'),
  name: 'tag2',
};
/**
 * mockQuestion info
 */
const mockQuestion: Question = {
  _id: new mongoose.Types.ObjectId('65e9b58910afe6e94fc6e6fe'),
  title: 'New Question Title',
  text: 'New Question Text',
  tags: [tag1, tag2],
  answers: [],
  asked_by: 'question3_user',
  ask_date_time: new Date('2024-06-06'),
  views: 0,
};

/**
 * mockQuestion info (missing title)
 */
const mockQuestionMissingTitle: Question = {
  _id: new mongoose.Types.ObjectId('65e9b58910afe6e94fc6e6fe'),
  title: '',
  text: 'New Question Text',
  tags: [tag1, tag2],
  answers: [],
  asked_by: 'question3_user',
  ask_date_time: new Date('2024-06-06'),
  views: 0,
};
/**
 * mockQuestion info (missing text)
 */
const mockQuestionMissingText: Question = {
  _id: new mongoose.Types.ObjectId('65e9b58910afe6e94fc6e6fe'),
  title: 'New Question Title',
  text: '',
  tags: [tag1, tag2],
  answers: [],
  asked_by: 'question3_user',
  ask_date_time: new Date('2024-06-06'),
  views: 0,
};

/**
 * mockQuestion info (missing tags)
 */
const mockQuestionMissingTags: Question = {
  _id: new mongoose.Types.ObjectId('65e9b58910afe6e94fc6e6fe'),
  title: 'New Question Title',
  text: 'New Question Text',
  tags: [],
  answers: [],
  asked_by: 'question3_user',
  ask_date_time: new Date('2024-06-06'),
  views: 0,
};

/**
 * mockQuestion info (missing ask_by)
 */
const mockQuestionMissingAskedBy: Question = {
  _id: new mongoose.Types.ObjectId('65e9b58910afe6e94fc6e6fe'),
  title: 'New Question Title',
  text: 'New Question Text',
  tags: [tag1, tag2],
  answers: [],
  asked_by: '',
  ask_date_time: new Date('2024-06-06'),
  views: 0,
};
/**
 *  FILL THIS IN!
 * @param question
 * @returns
 */
const simplifyQuestion = (question: Question) => ({
  ...question,
  /**
   * Converting ObjectId to string
   */
  _id: question._id?.toString(),
  /**
   * Converting tag ObjectId
   */
  tags: question.tags.map(tag => ({ ...tag, _id: tag._id?.toString() })),
  answers: question.answers.map(answer => ({
    ...answer,
    _id: answer._id?.toString(),
    ans_date_time: answer.ans_date_time.toISOString(),
  })),
  /**
   * Converting answer ObjectId
   */
  ask_date_time: question.ask_date_time.toISOString(),
});
/**
 * Testing addQuestion
 */
describe('POST /addQuestion', () => {
  afterEach(async () => {
    await mongoose.connection.close(); // Ensure the connection is properly closed
  });

  afterAll(async () => {
    await mongoose.disconnect(); // Ensure mongoose is disconnected after all tests
    server.close();
  });
  /**
   * This test checks that addQuestion, can add a new question successfully
   */
  it('should add a new question', async () => {
    jest.spyOn(util, 'getTags').mockResolvedValue([tag1, tag2] as Tag[]);
    jest.spyOn(util, 'saveQuestion').mockResolvedValueOnce(mockQuestion as Question);

    /**
     * Making the request
     */
    const response = await supertest(app).post('/question/addQuestion').send(mockQuestion);

    /**
     * Asserting the response
     */
    expect(response.status).toBe(200);
    expect(response.body).toEqual(simplifyQuestion(mockQuestion));
  });
  /**
   * This test checks if error occurs while adding a new question, it should return 500
   */
  it('should return 500 if error occurs while adding a new question', async () => {
    jest.spyOn(util, 'getTags').mockResolvedValue([tag1, tag2] as Tag[]);
    jest
      .spyOn(util, 'saveQuestion')
      .mockResolvedValueOnce({ error: 'Error while saving question' });

    /**
     * Making the request
     */
    const response = await supertest(app).post('/question/addQuestion').send(mockQuestion);

    /**
     *  Asserting the response
     */
    expect(response.status).toBe(500);
  });
  /**
   * This test checks if tag ids could not be retrieved, it should return 500
   */
  it('should return 500 if tag ids could not be retrieved', async () => {
    jest.spyOn(util, 'getTags').mockResolvedValue([]);

    /**
     * Making the request
     */
    const response = await supertest(app).post('/question/addQuestion').send(mockQuestion);
    /**
     * Asserting the response
     */
    expect(response.status).toBe(500);
  });
  /**
   * This test checks if question title is empty string, it should return a bad request
   */
  it('should return bad request if question title is empty string', async () => {
    /**
     *  Making the request
     */
    const response = await supertest(app)
      .post('/question/addQuestion')
      .send(mockQuestionMissingTitle);

    /**
     * Asserting the response
     */
    expect(response.status).toBe(400);
    expect(response.text).toBe('Invalid question body');
  });
  /**
   * This test checks if question text is a empty string, it should return a bad request
   */
  it('should return bad request if question text is empty string', async () => {
    /**
     * Making the request
     */
    const response = await supertest(app)
      .post('/question/addQuestion')
      .send(mockQuestionMissingText);

    /**
     * Asserting the response
     */
    expect(response.status).toBe(400);
    expect(response.text).toBe('Invalid question body');
  });
  /**
   * This test checks if tags are empty, it should return a bad request
   */
  it('should return bad request if tags are empty', async () => {
    /**
     *  Making the request
     */
    const response = await supertest(app)
      .post('/question/addQuestion')
      .send(mockQuestionMissingTags);

    /**
     * Asserting the response
     */
    expect(response.status).toBe(400);
    expect(response.text).toBe('Invalid question body');
  });
  /**
   * This test checks if asked_by is empty string, it should return a bad request
   */
  it('should return bad request if asked_by is empty string', async () => {
    /**
     *  Making the request
     */
    const response = await supertest(app)
      .post('/question/addQuestion')
      .send(mockQuestionMissingAskedBy);

    /**
     * Asserting the response
     */
    expect(response.status).toBe(400);
    expect(response.text).toBe('Invalid question body');
  });
  /**
   * This test checks that only unique tags are added
   */
  it('should ensure only unique tags are added', async () => {
    const result: Question = {
      _id: new mongoose.Types.ObjectId('65e9b58910afe6e94fc6e6fe'),
      title: 'New Question Title',
      text: 'New Question Text',
      tags: [tag1, tag2], // Duplicate tags
      answers: [],
      asked_by: 'question3_user',
      ask_date_time: new Date('2024-06-06'),
      views: 0,
    };

    /**
     * Set up the mock to resolve with unique tags
     */
    jest.spyOn(util, 'getTags').mockResolvedValue([tag1, tag2] as Tag[]);
    jest.spyOn(util, 'saveQuestion').mockResolvedValueOnce({
      ...mockQuestion,
      /**
       * Ensure only unique tags are saved
       */
      tags: [tag1, tag2],
    });

    /**
     * Making the request
     */
    const response = await supertest(app).post('/question/addQuestion').send(mockQuestion);
    /**
     * Asserting the response
     */
    expect(response.status).toBe(200);
    /**
     * Expect only unique tags
     */
    expect(response.body).toEqual(simplifyQuestion(result));
  });
});
