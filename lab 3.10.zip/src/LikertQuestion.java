

/**
 * Represents the LikertQuestion class which extend QUESTION.
 * this class represents a 5-scale likert question.
 * the scales are strongly agree, agree, neither agree nor
 * disagree, disagree and strongly disagree.
 */
public class LikertQuestion extends Question {


  /**
   * Constructor for LikertQuestion, a valid question must have text.
   *
   * @param text questionText
   * @throws IllegalArgumentException  invalided text for LikertQuestion
   */
  public LikertQuestion(String text) throws IllegalArgumentException {
    super(text);
  }

  /**
   * String methode for getType.
   *
   * @return "Likert", the LikertQuestion
   */
  @Override
  public String getType() {
    return "Likert";
  }


  /**
   * Method that reprints all correct answers/responds for LikertQuestion.
   * Valid answer must be one of the 5 options, in a case-insensitive manner.
   *
   * @param enteredAnswer the answer entered for this question by a student
   */
  @Override
  public void answer(String enteredAnswer) {
    String[] options = {"strongly agree", "agree", "neither agree nor disagree", "disagree",
                        "strongly disagree"};

    for (String option : options) {
      if (enteredAnswer.toLowerCase().equals(option)) {
        this.enteredAnswer = enteredAnswer.toLowerCase();
        return;
      }
    }

    throw new IllegalArgumentException("Invalid answer");
  }

  /**
   * Boolean method for hasBeenAnswered, collects the correct input, fails the false one.
   *
   * @return true or false, if the input is correct
   */
  @Override
  public boolean hasBeenAnswered() {
    String[] options = {"strongly agree", "agree", "neither agree nor disagree", "disagree",
                        "strongly disagree"};

    for (String option : options) {
      if (enteredAnswer.toLowerCase().equals(option)) {
        return true;
      }
    }
    return false;
  }

}
