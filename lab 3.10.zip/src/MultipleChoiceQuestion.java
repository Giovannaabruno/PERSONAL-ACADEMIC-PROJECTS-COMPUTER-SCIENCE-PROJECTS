/**
 * class MultipleChoiceQuestion which extends to Question class.
 */
public class MultipleChoiceQuestion extends Question {
  private String[] answers;

  /**
   * Constructor for MultipleChoiceQuestion class,takes in arguments String text, String array
   * answers.
   * @param text questionText
   * @param answers enteredAnswer
   * @throws IllegalArgumentException if there is an invalided input
   */
  public MultipleChoiceQuestion(String text, String[] answers) throws IllegalArgumentException {
    super(text);
    if (answers == null || answers.length == 0) {
      throw new IllegalArgumentException();
    }
    this.answers = answers;
  }

  /**
   * String methode for Multiple Choice.
    * @return "Multiple Choice"
   */
  @Override
  String getType() {
    return "Multiple Choice";
  }

  /**
   * Method for answer, creates the input of the answer for the Multiple Choice.
   * @param enteredAnswer the answer entered for this question by a student
   */
  @Override
  void answer(String enteredAnswer) {
    for (String option : answers) {
      if (option.equals(enteredAnswer.toLowerCase())) {
        this.enteredAnswer = enteredAnswer.toLowerCase();
        return;
      }

    }
    throw new IllegalArgumentException();

  }

  /**
   * Method for hasBeenAnswered.
   * @return true or false, if the input is correct
   */
  @Override
  boolean hasBeenAnswered() {
    for (String option : answers) {
      if (enteredAnswer.toLowerCase().equals(option)) {
        return true;
      }
    }
    return false;
  }
}
