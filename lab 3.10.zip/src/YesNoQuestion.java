
/**
 * This class represents a yes/no question.
 */
public class YesNoQuestion extends Question {


  /**
   *  Constructor for YesNoQuestion, question must be non-empty and should end with a question mark.
   *
   * @param text questionText
   * @throws IllegalArgumentException if given an input of Invalid question text or no ?.
   */
  public YesNoQuestion(String text) throws IllegalArgumentException {
    super(text);
    if (text.charAt(text.length() - 1) != '?') {
      throw new IllegalArgumentException("Invalid question text");
    }
  }

  /**
   * String methode for getType.
   *
   * @return "YesNo"
   */
  @Override
  public String getType() {
    return "YesNo";
  }


  /**
   * Method for answer, a valid answer must be a yes or no.
   *
   * @param enteredAnswer the answer entered for this question by a student
   */
  @Override
  public void answer(String enteredAnswer) {
    if ((enteredAnswer.toLowerCase().equals("yes")) || (enteredAnswer.toLowerCase().equals("no"))) {
      this.enteredAnswer = enteredAnswer.toLowerCase();
    } else {
      throw new IllegalArgumentException("Invalid answer: " + enteredAnswer);
    }
  }

  /**
   * Method for hasBeenAnswered.
   *
   * @return enteredAnswer of yes or no
   */
  @Override
  public boolean hasBeenAnswered() {
    return enteredAnswer.equals("yes") || enteredAnswer.equals("no");
  }
}
