import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;


/**
 * Represents tester class for MultipleChoiceQuestion.
 */
public class MultipleChoiceQuestionTest {

  /**
   * Represents tester for getType, represents a Correctly type of Multiple Choice question.
   * and string array of answers.
   */
  @Test
  public void getType() {
    String[] answer = {"a", "b", "c"};
    MultipleChoiceQuestion m1 = new MultipleChoiceQuestion("Do you Like dog", answer);
    assertEquals(m1.getType(), ("Multiple Choice"));

    MultipleChoiceQuestion m2 = new MultipleChoiceQuestion("Is that yellow cake?", answer);
    assertEquals(m2.getType(), ("Multiple Choice"));

    MultipleChoiceQuestion m3 = new MultipleChoiceQuestion("Are you happy?", answer);
    assertEquals(m3.getType(), ("Multiple Choice"));

    MultipleChoiceQuestion m4 = new MultipleChoiceQuestion("Is that good?", answer);
    assertEquals(m4.getType(), ("Multiple Choice"));

    MultipleChoiceQuestion m5 = new MultipleChoiceQuestion("that sammy's cat", answer);
    assertEquals(m5.getType(), ("Multiple Choice"));


  }

  /**
   * Tester that test correct and incorrect inputted answers for the MultipleChoiceQuestion
   * example question.
   */
  @Test
  public void answer() {
    try {
      String[] answer = {"a", "b", "c"};
      MultipleChoiceQuestion answer1 = new MultipleChoiceQuestion("Do you a dog", answer);
      // will throw a error bc it is a invalided answer.
      answer1.answer("x");
      fail();
    } catch (IllegalArgumentException e) {
      //assertTrue(true);
    }
    String[] answer = {"a", "b", "c"};
    MultipleChoiceQuestion answer2 = new MultipleChoiceQuestion("Do you like dog", answer);
    answer2.answer("a");

    MultipleChoiceQuestion answer3 = new MultipleChoiceQuestion("Do you like dog", answer);
    answer3.answer("b");

    MultipleChoiceQuestion answer4 = new MultipleChoiceQuestion("Do you like dog", answer);
    answer4.answer("c");
  }

  /**
   * Tester that test hasBeenAnswered, test correct and incorrect answers or inputs with
   * MultipleChoiceQuestion.
   */
  @Test
  public void hasBeenAnswered() {
    String[] answer = {"a", "b", "c"};
    MultipleChoiceQuestion answer1 = new MultipleChoiceQuestion("Do you like dog", answer);
    try {
      // will throw a error bc it is a invalided answer.
      answer1.answer("x");
      fail();
    } catch (IllegalArgumentException e) {
      //assertTrue(true);

    }
    assertFalse(answer1.hasBeenAnswered());
    MultipleChoiceQuestion hasBeenAnswer1 = new MultipleChoiceQuestion("Do you like dog", answer);
    hasBeenAnswer1.answer("a");
    assertTrue(hasBeenAnswer1.hasBeenAnswered());
    MultipleChoiceQuestion hasBeenAnswer2 = new MultipleChoiceQuestion("Do you like dog", answer);
    hasBeenAnswer2.answer("b");
    assertTrue(hasBeenAnswer2.hasBeenAnswered());
    MultipleChoiceQuestion hasBeenAnswer3 = new MultipleChoiceQuestion("Do you like dog", answer);
    hasBeenAnswer3.answer("c");
    assertTrue(hasBeenAnswer3.hasBeenAnswered());

  }

}