/**
 * public interface  for Fraction.
 */
public interface Fraction {

  /**
   * Add the whole fractions together to create a new function.
   *
   * @param other represents other fraction
   * @return new added function
   */
  Fraction add(Fraction other);

  /**
   * Method adds num and dem with other num and dem to create a function.
   *
   * @param numerator   represents the numerator
   * @param denominator represents the denominator
   * @return new added function
   * @throws IllegalArgumentException negative function
   */
  Fraction add(int numerator, int denominator) throws IllegalArgumentException;

  /**
   * A method that returns the decimal value of a fraction, rounded to the
   * given number of places.
   *
   * @param places number of decimal places
   * @return number of decimal places
   */
  double getDecimalValue(int places);


  //EXPERIMENTAl

  /**
   * getter method for numerator.
   *
   * @return numerator
   */
  int getNumerator();

  /**
   * getter method for Denominator.
   *
   * @return denominator
   */
  int getDenominator();
}
