/**
 * class for SimpleFraction that implements interface Fraction.
 */
public class SimpleFraction implements Fraction {
  private int numerator;
  private int denominator;

  /**
   * Constructor for SimpleFraction, setting up the rules that numerator and denominator can only
   * develop a positive fraction, but numerator and denominator can be negative separately.
   *
   * @param numerator   represent the numerator(top part) a function
   * @param denominator represent the denominator(bottom part) a function
   * @throws IllegalArgumentException if the numerator and denominator develops a negative fraction
   */
  public SimpleFraction(int numerator, int denominator) throws IllegalArgumentException {
    if (numerator < 0 && denominator < 0) {
      numerator *= -1;
      denominator *= -1;
    }
    if (denominator == 0) {
      throw new IllegalArgumentException(" cant have 0 denominator: ERROR");
    }
    if (numerator < 0 || denominator < 0) {
      throw new IllegalArgumentException(" cant have a negative fraction");
    }
    this.numerator = numerator;
    this.denominator = denominator;
  }

  /**
   * Getter method for getting the int numerator object.
   *
   * @return int object numerator.
   */
  @Override
  public int getNumerator() {
    return numerator;
  }

  /**
   * Getter method for getting the int denominator object.
   *
   * @return int object denominator.
   */
  @Override
  public int getDenominator() {
    return denominator;
  }

  /**
   * Method that adds completed whole fraction together.
   *
   * @param other represents other fraction
   * @return new added fraction
   */
  @Override
  public Fraction add(Fraction other) {
    int numerator = other.getNumerator();
    int denominator = other.getDenominator();
    int denom = this.denominator * denominator;
    int num = this.numerator * denominator + numerator * this.denominator;
    return new SimpleFraction(num, denom);
  }


  /**
   * numerator and denominator  added to and other numerator and denominator to create a function.
   *
   * @param numerator   represent numerator.
   * @param denominator represent denominator.
   * @return new added fraction
   * @throws IllegalArgumentException function is negative
   */
  @Override
  public Fraction add(int numerator, int denominator) throws IllegalArgumentException {
    if (numerator < 0 || denominator < 0) {
      throw new IllegalArgumentException(" cant have a negative fraction");
    }
    int denom = this.denominator * denominator;
    int num = this.numerator * denominator + numerator * this.denominator;
    return new SimpleFraction(num, denom);
  }

  /**
   * Getter method that sets the number of decimal places that the fraction will represent.
   *
   * @param places represent number of decimal places
   * @return the result 2 place value
   */
  @Override
  public double getDecimalValue(int places) {
    // fraction = 0.333... places =  2
    //  10^2 = 100
    // .3333... * 100 = 33.333
    //33.333 rounded -> 33
    // 33 / 100 = 0.33
    // return .33
    double val = (1.0 * numerator / denominator) * Math.pow(10, places);
    //System.out.println(val);
    double result = Math.round(val);
    //System.out.println(result);
    result /= Math.pow(10, places);
    //System.out.println(result);
    return result;
  }

  /**
   * ToString method that creates the formatting for the numerator and denominator
   * to create the function.
   *
   * @return numerator/denominator
   */
  @Override
  public String toString() {
    return numerator + "/" + denominator;
  }
}
