import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

/**
 * public tester class that test SimpleFractionTest.
 */
public class SimpleFractionTest {


  /**
   * tester for add which  add the whole fraction.
   */
  @Test
  public void add() {
    SimpleFraction addF1 = new SimpleFraction(2, 3);
    SimpleFraction addF2 = new SimpleFraction(1, 6);
    Fraction addF3 = addF1.add(addF2);
    assertEquals(addF3.toString(), "15/18");


    SimpleFraction addF4 = new SimpleFraction(1, 2);
    SimpleFraction addF5 = new SimpleFraction(1, 3);
    Fraction addF6 = addF4.add(addF5);
    assertEquals(addF6.toString(), "5/6");

    try {
      SimpleFraction addF7 = new SimpleFraction(-2, 6);
      SimpleFraction addF8 = new SimpleFraction(-2, 6);
      Fraction addF9 = addF7.add(addF8);
    } catch (IllegalArgumentException e) {
      //throws the IllegalArgumentException
    }
    try {
      SimpleFraction addF10 = new SimpleFraction(1, 4);
      SimpleFraction addF11 = new SimpleFraction(-3, 4);
      Fraction addF12 = addF10.add(addF11);
    } catch (IllegalArgumentException e) {
      //throws the IllegalArgumentException
    }


  }

  /**
   * tester for Add which  add num and dem.
   */
  @Test
  public void testAdd() {
    SimpleFraction addND1 = new SimpleFraction(2, 3);
    Fraction addND2 = addND1.add(1, 6);
    assertEquals(addND2.toString(), "15/18");

    SimpleFraction addND4 = new SimpleFraction(1, 4);
    Fraction addND5 = addND4.add(1, 2);
    assertEquals(addND5.toString(), "6/8");

    try {
      SimpleFraction addND6 = new SimpleFraction(-1, 4);
      Fraction addND7 = addND6.add(-1, 4);
    } catch (IllegalArgumentException e) {
      //throws the IllegalArgumentException
    }
    try {
      SimpleFraction addND6 = new SimpleFraction(1, 4);
      Fraction addND7 = addND6.add(-3, 4);
    } catch (IllegalArgumentException e) {
      //throws the IllegalArgumentException
    }

  }

  /**
   * tester for getDecimalValue, test the amount of decimal places for a function.
   */
  @Test
  public void getDecimalValue() {
    SimpleFraction getDV1 = new SimpleFraction(1, 3);
    assertEquals(getDV1.getDecimalValue(2), 0.33, 0.01);
    SimpleFraction getDV2 = new SimpleFraction(1, 4);
    assertEquals(getDV2.getDecimalValue(3), 0.25, 0.01);
    SimpleFraction getDV3 = new SimpleFraction(2, 1);
    assertEquals(getDV3.getDecimalValue(1), 2, 0.01);

  }

  /**
   * tester for ToString methode which test, the formatting of the equations to get a function.
   */
  @Test
  public void testToString() {
    SimpleFraction sf1 = new SimpleFraction(1, 2);
    assertEquals(sf1.toString(), "1/2");
    SimpleFraction sf2 = new SimpleFraction(-1, -2);
    assertEquals(sf2.toString(), "1/2");
  }

  /**
   * tester for the constructor.
   */
  @Test
  public void testConstructor() throws IllegalArgumentException {
    try {
      SimpleFraction f1 = new SimpleFraction(-1, 2);
      fail();

    } catch (IllegalArgumentException e) {
      //throws the IllegalArgumentException

    }
    try {
      SimpleFraction f2 = new SimpleFraction(1, -2);
      fail();
    } catch (IllegalArgumentException e) {
      //throws the IllegalArgumentException

    }
    //New TO DO part 1: create a scenario where the numerator is
    // divided by denominator with the value of 0.
    // possible ideas: make having an "error" an illegal IllegalArgumentException.

    try {
      SimpleFraction f3 = new SimpleFraction(6, 0);
      fail();
    } catch (IllegalArgumentException e) {
      //throws the IllegalArgumentException

    }

    // TO DO part 2: look on bottle nose for the other example
    // possible ideas: relook at the add methods
    //old
    SimpleFraction f4 = new SimpleFraction(-1, -2);
    SimpleFraction f5 = new SimpleFraction(1, 2);


  }
}